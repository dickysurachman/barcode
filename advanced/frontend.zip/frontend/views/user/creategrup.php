<?php

use yii\helpers\Html;


/* @var $this yii\web\View */
/* @var $model app\models\Grup */

?>
<div class="grup-create">
    <?= $this->render('_formg', [
        'model' => $model,
    ]) ?>
</div>
