<?php

use yii\helpers\Html;


/* @var $this yii\web\View */
/* @var $model app\models\Kurir */

?>
<div class="kurir-create">
    <?= $this->render('_form', [
        'model' => $model,
    ]) ?>
</div>
