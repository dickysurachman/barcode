<aside class="main-sidebar">

    <section class="sidebar">

        <!-- Sidebar user panel -->
        <div class="user-panel">
            <div class="pull-left image">
                <img src="images/<?php echo Yii::$app->user->identity->foto?>" class="img-circle" alt="User Image"/>
            </div>
            <div class="pull-left info">
                <p><?php echo Yii::$app->user->identity->username; ?></p>

                <a href="#"><i class="fa fa-circle text-success"></i> Online</a>
            </div>
        </div>

        <!-- search form -->

        <!-- /.search form -->
        <?php 
        if(Yii::$app->user->identity->tipe_user==0){
        ?>
        <?= dmstr\widgets\Menu::widget(
            [
                'options' => ['class' => 'sidebar-menu tree', 'data-widget'=> 'tree'],
                'items' => [
                    //['label' => 'Menu Yii2', 'options' => ['class' => 'header']],
                    ['label' => 'User', 'icon' => 'file-code-o', 'url' => ['/user']],
                    ['label' => 'Rubah Password', 'icon' => 'user', 'url' => ['/site/password']],
                    ['label' => 'Data Master', 'icon' => 'copy', 'url' => '#',
                        'items'=>[
                                ['label' => 'Outlet', 'icon' => 'file-code-o', 'url' => ['/profile']],
                                ['label' => 'Jenis Barang Outlet', 'icon' => 'file-code-o', 'url' => ['/masterb']],
                                ['label' => 'Jenis identitas', 'icon' => 'copy', 'url' => ['/identitas']],
                                ['label' => 'Jenis Kamar', 'icon' => 'copy', 'url' => ['/kamar1']],
                                ['label' => 'Inventory Kamar', 'icon' => 'copy', 'url' => ['/tipekamar']],
                                ['label' => 'Jenis Penerimaan', 'icon' => 'copy', 'url' => ['/terima']],
                                ['label' => 'Tamu', 'icon' => 'copy', 'url' => ['/guest']],
                                ['label' => 'Market Segment', 'icon' => 'copy', 'url' => ['/market']],
                                ['label' => 'Perusahaan', 'icon' => 'copy', 'url' => ['/company']],
                                ['label' => 'Rate', 'icon' => 'copy', 'url' => ['/rate']],
                                ['label' => 'Tambahan Service', 'icon' => 'copy', 'url' => ['/charge']],
                                ['label' => 'Night Audit Replace', 'icon' => 'copy', 'url' => ['/report/createulang']],
                        ],
                    ],
                     ['label' => 'Front Office', 'icon' => 'copy', 'url' => '#',
                        'items'=>[
                                ['label' => 'Status Kamar', 'icon' => 'copy', 'url' => ['/tipekamar/lihat']],
                                ['label' => 'Floor Kamar', 'icon' => 'copy', 'url' => ['/tipekamar/map']],
                                ['label' => 'Deposit', 'icon' => 'user', 'url' => ['/deposit']],
                                ['label' => 'Reservasi', 'icon' => 'user', 'url' => ['/reservasi']],
                                ['label' => 'Check In', 'icon' => 'user', 'url' => ['/nobon']],
                                ['label' => 'Pembayaran Folio', 'icon' => 'user', 'url' => ['/bayarbon']],
                                ['label' => 'Compliment', 'icon' => 'user', 'url' => ['/compli']],
                                ['label' => 'Pergantian Room', 'icon' => 'copy', 'url' => '#',
                        'items'=>[
                                ['label' => 'Proses Pergantian Room', 'icon' => 'user', 'url' => ['/nobon/change']],
                                ['label' => 'Data Pergantian Room', 'icon' => 'user', 'url' => ['/nobon/change1']],
                        ],
                        ],
                                ['label' => 'Upgrade Room', 'icon' => 'copy', 'url' => '#',
                        'items'=>[
                                ['label' => 'Proses Upgrade Room', 'icon' => 'user', 'url' => ['/nobon/upgrade']],
                                ['label' => 'Data Upgrade Room', 'icon' => 'user', 'url' => ['/nobon/upgrade1']],
                        ],
                        ],
                                ['label' => 'Tambahan Charge', 'icon' => 'copy', 'url' => ['/nobon/charge']],
                                ['label' => 'Check Out Hari Ini', 'icon' => 'user', 'url' => ['/nobon/cekout']],
                                ['label' => 'Check Out Hari Sebelumnya', 'icon' => 'user', 'url' => ['/nobon/cekoutlalu']],
                                ['label' => 'Proses Night Audit', 'icon' => 'user', 'url' => ['/report/create']],
                                ['label' => 'Report', 'icon' => 'copy', 'url' => '#',
                                'items'=>[
                                        ['label' => 'Cashier', 'icon' => 'user', 'url' => ['/report/cashier']],
                                        ['label' => 'Cashier Detail', 'icon' => 'user', 'url' => ['/report/cashierdet']],
                                        ['label' => 'Balance Dept', 'icon' => 'user', 'url' => ['/report/departemen']],
                                        ['label' => 'Revenue Daily', 'icon' => 'user', 'url' => ['/report/revdaily']],
                                        ['label' => 'AR Report', 'icon' => 'user', 'url' => ['/report/arpot']],
                                        ['label' => 'AR Guest Ledger', 'icon' => 'user', 'url' => ['/report/arguest']],
                                        ['label' => 'Folio Master', 'icon' => 'user', 'url' => ['/masterbon/index1']],
                                        ['label' => 'Reservasi', 'icon' => 'user', 'url' => ['/reservasi/indexx']],
                                        ['label' => 'Forecast', 'icon' => 'user', 'url' => ['/reservasi/cari']],
                                        ['label' => 'Compliment', 'icon' => 'user', 'url' => ['/report/comp']],
                                        ['label' => 'Guest In House', 'icon' => 'user', 'url' => ['/nobon/guestin']],
                                        ['label' => 'Check in', 'icon' => 'user', 'url' => ['/nobon/report']],
                                        ['label' => 'Jurnal', 'icon' => 'user', 'url' => ['/report']],
                                        ['label' => 'CDR', 'icon' => 'user', 'url' => ['/report/cdr']],
                                        ['label' => 'Market Segment', 'icon' => 'user', 'url' => ['/report/market']],
                                        ['label' => 'Summary', 'icon' => 'user', 'url' => ['/report/sumary']],
                                        ]
                                ],

                        ],
                    ],

                     ['label' => 'Housekeeping', 'icon' => 'copy', 'url' => '#',
                        'items'=>[
                            ['label' => 'Status Kamar', 'icon' => 'copy', 'url' => ['/tipekamar/house']],
                        ],
                        ],
                     ['label' => 'Outlet', 'icon' => 'copy', 'url' => '#',
                        'items'=>[                    
                    ['label' => 'Transaksi', 'icon' => 'user', 'url' => ['/outlet/tot']],
                    ['label' => 'Transaksi Detail', 'icon' => 'user', 'url' => ['/outlet/detailnyatot']],
                    ['label' => 'Officer Check', 'icon' => 'user', 'url' => ['/outletp/tot']],
                    ['label' => 'Officer Check Detail', 'icon' => 'user', 'url' => ['/outletp/detailnyatot']],
                        ],
                        ],
                    //['label' => 'Debug', 'icon' => 'dashboard', 'url' => ['/debug']],
                    //['label' => 'Logout', 'icon' => 'dashboard', 'url' => ['/site/logout'],'data-method'=>['post']],
                    //['label' => 'Login', 'url' => ['site/login'], 'visible' => Yii::$app->user->isGuest],
                   
                ],
            ]
        ) ?>

        <?php }
         elseif(Yii::$app->user->identity->tipe_user==1){
            ?>
        <?= dmstr\widgets\Menu::widget(
            [
                'options' => ['class' => 'sidebar-menu tree', 'data-widget'=> 'tree'],
                'items' => [
                    //['label' => 'Menu Yii2', 'options' => ['class' => 'header']],
                    
                    ['label' => 'Rubah Password', 'icon' => 'user', 'url' => ['/site/password']],
                   
                   
                     //['label' => 'Front Office', 'icon' => 'copy', 'url' => '#',
                     //   'items'=>[
                        ['label' => 'Status Kamar', 'icon' => 'copy', 'url' => ['/tipekamar/lihat']],
                        ['label' => 'Floor Kamar', 'icon' => 'copy', 'url' => ['/tipekamar/map']],
                        //['label' => 'Status Kamar', 'icon' => 'copy', 'url' => ['/tipekamar/lihat']],
                        ['label' => 'Deposit', 'icon' => 'copy', 'url' => ['/deposit']],
                                ['label' => 'Reservasi', 'icon' => 'user', 'url' => ['/reservasi']],
                                ['label' => 'Check In', 'icon' => 'user', 'url' => ['/nobon']],
                                ['label' => 'Create Master Folio', 'icon' => 'user', 'url' => ['/nobon/createmaster']],
                                ['label' => 'Pembayaran Folio', 'icon' => 'user', 'url' => ['/bayarbon']],
                                ['label' => 'Compliment', 'icon' => 'user', 'url' => ['/compli']],
                                ['label' => 'Pergantian Room', 'icon' => 'copy', 'url' => '#',
                        'items'=>[
                                ['label' => 'Proses Pergantian Room', 'icon' => 'user', 'url' => ['/nobon/change']],
                                ['label' => 'Data Pergantian Room', 'icon' => 'user', 'url' => ['/nobon/change1']],
                        ],
                        ],
                                ['label' => 'Upgrade Room', 'icon' => 'copy', 'url' => '#',
                        'items'=>[
                                ['label' => 'Proses Upgrade Room', 'icon' => 'user', 'url' => ['/nobon/upgrade']],
                                ['label' => 'Data Upgrade Room', 'icon' => 'user', 'url' => ['/nobon/upgrade1']],
                        ],
                        ],
                                ['label' => 'Tambahan Charge', 'icon' => 'copy', 'url' => ['/nobon/charge']],
                                ['label' => 'Outlet by Folio', 'icon' => 'copy', 'url' => ['/outlet/indexfol']],
                                //['label' => 'Check Out', 'icon' => 'user', 'url' => ['/nobon/cekout']],
                                ['label' => 'Check Out Hari Ini', 'icon' => 'user', 'url' => ['/nobon/cekout']],
                                ['label' => 'Check Out Hari Sebelumnya', 'icon' => 'user', 'url' => ['/nobon/cekoutlalu']],
                                ['label' => 'Proses Night Audit', 'icon' => 'user', 'url' => ['/report/create']],
                                ['label' => 'Outlet', 'icon' => 'copy', 'url' => '#',
                                'items'=>[
                                ['label' => 'Master Barang', 'icon' => 'user', 'url' => ['/barang']],
                                ['label' => 'Transaksi', 'icon' => 'user', 'url' => ['/outlet']],
                                ['label' => 'Transaksi Detail', 'icon' => 'user', 'url' => ['/outlet/detailnya']],
                                ]],
                                ['label' => 'Report', 'icon' => 'copy', 'url' => '#',
                                'items'=>[
                                        ['label' => 'Cashier', 'icon' => 'user', 'url' => ['/report/cashier']],
                                        ['label' => 'Cashier Detail', 'icon' => 'user', 'url' => ['/report/cashierdet']],
                                        ['label' => 'Balance Dept', 'icon' => 'user', 'url' => ['/report/departemen']],
                                        ['label' => 'AR Report', 'icon' => 'user', 'url' => ['/report/arpot']],
                                        ['label' => 'AR Guest Ledger', 'icon' => 'user', 'url' => ['/report/arguest']],
                                        ['label' => 'Revenue Daily', 'icon' => 'user', 'url' => ['/report/revdaily']],
                                        ['label' => 'Folio Master', 'icon' => 'user', 'url' => ['/masterbon/index1']],
                                        ['label' => 'Compliment', 'icon' => 'user', 'url' => ['/report/comp']],
                                        ['label' => 'Reservasi', 'icon' => 'user', 'url' => ['/reservasi/indexx']],
                                        ['label' => 'Forecast', 'icon' => 'user', 'url' => ['/reservasi/cari']],
                                        ['label' => 'Guest In House', 'icon' => 'user', 'url' => ['/nobon/guestin']],
                                        ['label' => 'Check in', 'icon' => 'user', 'url' => ['/nobon/report']],
                                        ['label' => 'Jurnal', 'icon' => 'user', 'url' => ['/report']],
                                        ['label' => 'CDR', 'icon' => 'user', 'url' => ['/report/cdr']],
                                        ['label' => 'Market Segment', 'icon' => 'user', 'url' => ['/report/market']],
                                        ['label' => 'Summary', 'icon' => 'user', 'url' => ['/report/sumary']],
                                        ]
                                ],
                        //],
                        //],
                    //['label' => 'Debug', 'icon' => 'dashboard', 'url' => ['/debug']],
                    //['label' => 'Logout', 'icon' => 'dashboard', 'url' => ['/site/logout'],'data-method'=>['post']],
                    //['label' => 'Login', 'url' => ['site/login'], 'visible' => Yii::$app->user->isGuest],
                   
                ],
            ]
        ) ?>
        <?php }
        elseif(Yii::$app->user->identity->tipe_user==2){ ?>
        <?= dmstr\widgets\Menu::widget(
            [
                'options' => ['class' => 'sidebar-menu tree', 'data-widget'=> 'tree'],
                'items' => [
                    //['label' => 'Menu Yii2', 'options' => ['class' => 'header']],
                    
                    ['label' => 'Rubah Password', 'icon' => 'user', 'url' => ['/site/password']],
                    ['label' => 'Housekeeping', 'icon' => 'copy', 'url' => '#',
                        'items'=>[
                            ['label' => 'Status Kamar', 'icon' => 'copy', 'url' => ['/tipekamar/house']],
                        ],
                        ],
                    //['label' => 'Debug', 'icon' => 'dashboard', 'url' => ['/debug']],
                    //['label' => 'Logout', 'icon' => 'dashboard', 'url' => ['/site/logout'],'data-method'=>['post']],
                    //['label' => 'Login', 'url' => ['site/login'], 'visible' => Yii::$app->user->isGuest],
                   
                ],
            ]
        ) ?>
        <?php }
         elseif(Yii::$app->user->identity->tipe_user==3){ 
        ?>
        <?= dmstr\widgets\Menu::widget(
            [
                'options' => ['class' => 'sidebar-menu tree', 'data-widget'=> 'tree'],
                'items' => [
                    //['label' => 'Menu Yii2', 'options' => ['class' => 'header']],
                    
                    ['label' => 'Rubah Password', 'icon' => 'user', 'url' => ['/site/password']],
                    ['label' => 'Master Barang', 'icon' => 'user', 'url' => ['/barang']],
                    ['label' => 'Transaksi', 'icon' => 'user', 'url' => ['/outlet']],
                    ['label' => 'Transaksi Detail', 'icon' => 'user', 'url' => ['/outlet/detailnya']],
                    ['label' => 'Officer Check / Entertain', 'icon' => 'user', 'url' => ['/outletp']],
                    ['label' => 'Officer Check Detail', 'icon' => 'user', 'url' => ['/outletp/detailnya']],
                    
                    //['label' => 'Debug', 'icon' => 'dashboard', 'url' => ['/debug']],
                    //['label' => 'Logout', 'icon' => 'dashboard', 'url' => ['/site/logout'],'data-method'=>['post']],
                    //['label' => 'Login', 'url' => ['site/login'], 'visible' => Yii::$app->user->isGuest],
                   
                ],
            ]
        ) ?>
        <?php } 
         elseif(Yii::$app->user->identity->tipe_user==4){
            ?>

        <?= dmstr\widgets\Menu::widget(
            [
                'options' => ['class' => 'sidebar-menu tree', 'data-widget'=> 'tree'],
                'items' => [
                    //['label' => 'Menu Yii2', 'options' => ['class' => 'header']],
                    
                    ['label' => 'Rubah Password', 'icon' => 'user', 'url' => ['/site/password']],
                    ['label' => 'Perusahaan', 'icon' => 'user', 'url' => ['/company']],
                    ['label' => 'Deposit', 'icon' => 'user', 'url' => ['/report/deposit']],
                    ['label' => 'Transaksi FO', 'icon' => 'user', 'url' => ['/nobon/report']],
                    ['label' => 'Folio Master', 'icon' => 'user', 'url' => ['/masterbon/index1']],
                    ['label' => 'Compliment', 'icon' => 'user', 'url' => ['/report/comp']],
                    ['label' => 'AR Report', 'icon' => 'user', 'url' => ['/report/arpot']],
                    ['label' => 'AR Guest Ledger', 'icon' => 'user', 'url' => ['/report/arguest']],
                    ['label' => 'Transaksi Outlet', 'icon' => 'user', 'url' => ['/outlet/tot']],
                    ['label' => 'Transaksi Outlet Detail', 'icon' => 'user', 'url' => ['/outlet/detailnyatot']],
                    ['label' => 'Officer Check', 'icon' => 'user', 'url' => ['/outletp/tot']],
                    ['label' => 'Officer Check Detail', 'icon' => 'user', 'url' => ['/outletp/detailnyatot']],
                    ['label' => 'Cashier', 'icon' => 'user', 'url' => ['/report/cashier']],
                    ['label' => 'Cashier Detail', 'icon' => 'user', 'url' => ['/report/cashierdet']],
                    ['label' => 'Balance Dept', 'icon' => 'user', 'url' => ['/report/departemen']],
                    ['label' => 'Revenue Daily', 'icon' => 'user', 'url' => ['/report/revdaily']],             
                    ['label' => 'Jurnal', 'icon' => 'user', 'url' => ['/report']],
                    ['label' => 'CDR', 'icon' => 'user', 'url' => ['/report/cdr']],
                    ['label' => 'Market Segment', 'icon' => 'user', 'url' => ['/report/market']],
                    ['label' => 'Summary', 'icon' => 'user', 'url' => ['/report/sumary']],
                    //['label' => 'Debug', 'icon' => 'dashboard', 'url' => ['/debug']],
                    //['label' => 'Logout', 'icon' => 'dashboard', 'url' => ['/site/logout'],'data-method'=>['post']],
                    //['label' => 'Login', 'url' => ['site/login'], 'visible' => Yii::$app->user->isGuest],
                   
                ],
            ]
        ) ?>

        <?php 
        }
        ?>        
    </section>

</aside>
