<?php

use yii\helpers\Html;


/* @var $this yii\web\View */
/* @var $model app\models\Barcodeinput */

?>
<div class="barcodeinput-create">
    <?= $this->render('_form', [
        'model' => $model,
    ]) ?>
</div>
