<?php

use yii\helpers\Html;


/* @var $this yii\web\View */
/* @var $model app\models\Bondmaster */

?>
<div class="bondmaster-create">
    <?= $this->render('_form', [
        'model' => $model,
    ]) ?>
</div>
