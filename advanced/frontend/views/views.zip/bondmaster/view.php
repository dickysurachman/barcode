<?php

use yii\widgets\DetailView;

/* @var $this yii\web\View */
/* @var $model app\models\Bondmaster */
?>
<div class="bondmaster-view">
 
    <?= DetailView::widget([
        'model' => $model,
        'attributes' => [
            'id',
            'id_master',
            'id_bon',
        ],
    ]) ?>

</div>
