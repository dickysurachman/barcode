<?php

use yii\widgets\DetailView;

/* @var $this yii\web\View */
/* @var $model app\models\Arrinci */
?>
<div class="arrinci-view">
 
    <?= DetailView::widget([
        'model' => $model,
        'attributes' => [
            'id',
            'tgl',
            'jenis',
            'nama',
            'kode',
            'perusahaan',
            'jumlah',
            'status',
            'add_who',
            'add_date',
            'edit_who',
            'edit_date',
        ],
    ]) ?>

</div>
