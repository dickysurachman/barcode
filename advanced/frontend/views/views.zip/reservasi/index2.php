<?php

use yii\helpers\Html;
use yii\grid\GridView;
use kartik\export\ExportMenu;


//use kartik\grid\GridView;
/* @var $this yii\web\View */
/* @var $searchModel app\models\ReservasiSearch */
/* @var $dataProvider yii\data\ActiveDataProvider */

$this->title = 'Data Reservasi';
$this->params['breadcrumbs'][] = $this->title;

$amount = 0;
$amountrns = 0;
    //if (!isset($dataProvider->getModels())) {
    if (isset($dataProvider)) {
        foreach ($dataProvider->getModels() as $key => $val) {
            //$amount += $val->total;
            $amountrns += $val->jumlah;
        }
    }

?>
<div class="reservasi-index">

    <h1><?= Html::encode($this->title) ?></h1>
    <p>

<?php 

$gridColumns = [
    ['class' => 'yii\grid\SerialColumn'],
    'namatamu',
            'nohp',
            'jumlah',
            'tgl_cekin',
            'tgl_cekout',
            'ket',
            'namakamar'
];

// Renders a export dropdown menu
echo ExportMenu::widget([
    'dataProvider' => $dataProvider,
    'columns' => $gridColumns
]);

// You can choose to render your own GridView separately
/*echo \kartik\grid\GridView::widget([
    'dataProvider' => $dataProvider,
    'filterModel' => $searchModel,
    'columns' => $gridColumns,
     'toolbar' =>  [
            '{export}',
            '{toggleData}',
        ]                      
]);*/
?>
        <?php //= Html::a('Create Reservasi', ['create'], ['class' => 'btn btn-success']) ?>

    <?php  echo $this->render('_search', ['model' => $searchModel]); ?>


    </p>
    <div class="table-responsive">
    <?= GridView::widget([
        'dataProvider' => $dataProvider,
        'filterModel' => $searchModel,
        'showFooter'=>TRUE,
        'columns' => [
            ['class' => 'yii\grid\SerialColumn'],

            //'id',
            'namatamu',
            'nohp',
            //'jumlah',
            [
                'attribute' => 'jumlah',
               'value'=>function($data) {
                            //$total =$total+$data->total;
                            return number_format($data->jumlah);
                            },
            'footer'=>number_format($amountrns),
            ],
            'tgl_cekin',
            'tgl_cekout',
            'ket',
            // 'no_kamar',
            // 'ket',
            // 'tgl_booking',
            // 'tgl_cekin',
            // 'tgl_cekout',
            // 'dp',
            // 'bayar',
            // 'status',
            /*[
                //'class' => 'yii\grid\ActionColumn',
                'header'=>'Check In',
                'attribute' => 'img',
                'format' => 'raw',
                'label' => 'Status',
                'value'=>function ($data) {
                                return Html::a('<span class="glyphicon glyphicon-share" style="font-size:14pt;" title="Ganti Room"></span>',['nobon/createcek', 'id' => $data->id]);
                                },
            ],*/
            //['class' => 'yii\grid\ActionColumn'],
        ],
    ]); ?>
</div>
</div>
