<?php

use yii\helpers\Html;
use yii\widgets\ActiveForm;

use kartik\select2\Select2;
$url = \yii\helpers\Url::to(['guest']);
use yii\web\JsExpression;
//use app\models\Guest;
use yii\jui\DatePicker;
use yii\web\View;
use app\models\Guest;
 use app\models\Market;
use app\models\Company;
use app\models\Rate;
use app\models\Penerimaan;
use app\models\Tipekamar;
use yii\helpers\ArrayHelper;
// Get the initial city description
$cityDesc =empty($model->id_guest) ? '' : Guest::findOne($model->id_guest)->nama;
//$cityDesc = "Ketikkan Nama";//empty($model->city) ? '' : City::findOne($model->city)->description;
$script = <<< JS
$("#reservasi-tgl_cekin").datepicker({
    changeMonth: true, 
    changeYear: true, 
    dateFormat:'yy-mm-dd',
});
$("#reservasi-tgl_cekout").datepicker({
    changeMonth: true, 
    changeYear: true, 
    dateFormat:'yy-mm-dd',
});
 
JS;
$position= View::POS_END;
$this->registerJs($script,$position);


/* @var $this yii\web\View */
/* @var $model app\models\Reservasi */
/* @var $form yii\widgets\ActiveForm */
?>

<div class="reservasi-form">

<?= Html::a('Create Tamu', ['/guest/create'], ['class' => 'btn btn-success','target'=>'_blank']) ?>

<?php $form = ActiveForm::begin(); ?> 
    <?php 
    echo $form->field($model, 'id_guest')->widget(Select2::classname(), [
        'initValueText' => $cityDesc, 
        'options' => ['placeholder' => 'Search for Guest ...'],
        'pluginOptions' => [
            'allowClear' => true,
            'minimumInputLength' => 3,
            'language' => [
                'errorLoading' => new JsExpression("function () { return 'Waiting for results...'; }"),
            ],
            'ajax' => [
                'url' => $url,
                'dataType' => 'json',
                'data' => new JsExpression('function(params) { return {q:params.term}; }')
            ],
            'escapeMarkup' => new JsExpression('function (markup) { return markup; }'),
            'templateResult' => new JsExpression('function(id_guest) { return id_guest.text; }'),
            'templateSelection' => new JsExpression('function (id_guest) { return id_guest.text; }'),
        ],
    ]);
    ?>
      <div class="col-md-6" style="padding-left: 0px;"> <label class="control-label" for="semen-tgl"><?php echo "Tanggal Check In" ?> </label>
    <?php
    echo DatePicker::widget([
    'model'  => $model,
    'attribute'=>'tgl_cekin',
    //'language' => 'en',
    'dateFormat' => 'yyyy-MM-dd',
    'options'=>['class'=>'form-control','autocomplete'=>'off']
]);?></div>
<div class="col-md-6" style="padding-right: 0px">
   <label class="control-label" for="semen-tgl"><?php echo "Tanggal Check Out" ?> </label>
    <?php
    echo DatePicker::widget([
    'model'  => $model,
    'attribute'=>'tgl_cekout',
    //'language' => 'en',
    'dateFormat' => 'yyyy-MM-dd',
    'options'=>['class'=>'form-control','autocomplete'=>'off']
]);?></div>
    <div class="col-md-6" style="padding-left: 0px;">
    <?php
    echo $form->field($model, 'id_market')->widget(Select2::classname(), [
    'data' => ArrayHelper::map(Market::find()->where(['id_perusahaan'=>Yii::$app->user->identity->id_perusahaan])->all(), 'kode', 'nama'),
    'options' => ['placeholder' => 'Select '],
    'pluginOptions' => [
        'allowClear' => true
    ],
    ]);
    ?></div>
     
    <div class="col-md-6" style="padding-right: 0px;">
         <?php
    echo $form->field($model, 'id_company')->widget(Select2::classname(), [
    'data' => ArrayHelper::map(Company::find()->where(['id_perusahaan'=>Yii::$app->user->identity->id_perusahaan])->all(), 'kode', 'nama'),
    'options' => ['placeholder' => 'Select '],
    'pluginOptions' => [
        'allowClear' => true
    ],
    ]);
    ?>

    </div>

    <div class="col-md-6" style="padding-left: 0px;">
      <?php
        echo $form->field($model, 'id_rate')->widget(Select2::classname(), [
        'data' => ArrayHelper::map(Rate::find()->where(['id_perusahaan'=>Yii::$app->user->identity->id_perusahaan])->all(), 'kode', 'nama'),
        'options' => ['placeholder' => 'Select '],
        'pluginOptions' => [
            'allowClear' => true
        ],
        ]);
    ?>
    </div>
    <div class="col-md-6" style="padding-right: 0px;">
        
      <?php
        echo $form->field($model, 'id_kamar')->widget(Select2::classname(), [
        'data' => ArrayHelper::map(Tipekamar::find()->where(['status'=>'VC','id_perusahaan'=>Yii::$app->user->identity->id_perusahaan])->all(), 'id', 'nama_kamar'),
        'options' => ['placeholder' => 'Select '],
        'pluginOptions' => [
            'allowClear' => true
        ],
        ]);
    ?>


    </div>
    <div class="col-md-6" style="padding-left: 0px;">
    <?= $form->field($model, 'no_ext')->textInput(['maxlength' => true]) ?> 
    </div>    
    <div class="col-md-6" style="padding-right: 0px">
    <?= $form->field($model, 'ket')->textInput(['maxlength' => true]) ?> 
    </div>
    <div class="col-md-6" style="padding-left: 0px;"><?= $form->field($model, 'nohp')->textInput() ?></div>
    <div class="col-md-6" style="padding-right: 0px"><?= $form->field($model, 'jumlah')->textInput() ?></div>

    <?php \yii\bootstrap\Modal::begin([
        'id' => 'popup-window'
    ]);?>

        <h1>Hello</h1>
        <p>Modal body</p>

    <?php \yii\bootstrap\Modal::end();?>

    <div class="form-group">
        <?= Html::submitButton($model->isNewRecord ? 'Create' : 'Update', ['class' => $model->isNewRecord ? 'btn btn-success' : 'btn btn-primary']) ?>
    </div>

    <?php ActiveForm::end(); ?>

</div>
