<?php

use yii\helpers\Html;
use yii\widgets\DetailView;

/* @var $this yii\web\View */
/* @var $model app\models\Reservasi */

$this->title = 'Report Forecast';//$model->id;
$this->params['breadcrumbs'][] = ['label' => 'Reservasi', 'url' => ['index']];
$this->params['breadcrumbs'][] = $this->title;
?>
<div class="reservasi-view">

    <h1><?= Html::encode($this->title) ?></h1>

    <table class="table table-striped table-hover">
    <thead>
        <th>Tanggal</th>
        <th>Jumlah Kamar</th>
        <th>Keterangan</th>
    </thead>
<?php
        $jumlahhari=(strtotime($tgl_b)-strtotime($tgl_a))/86400;
        for($i=0;$i<=$jumlahhari;$i++){
            $tgljn=date('Y-m-d',strtotime($tgl_a)+(86400*$i));
            $detail=Yii::$app->db->createCommand("select sum(jumlah) as jml from reservasi where tgl_cekin='".$tgljn."' or (tgl_cekout>".$tgljn." and tgl_cekin <".$tgljn.") and id_perusahaan=".Yii::$app->user->identity->id_perusahaan)->queryScalar();
            if($detail==0 or $detail==""){
                $sumary1= '0';
            }else{
                $sumary1=$detail;
            }
            $detail=Yii::$app->db->createCommand("select GROUP_CONCAT(DISTINCT(ket)) as jml from reservasi where tgl_cekin='".$tgljn."'  or (tgl_cekout>".$tgljn." and tgl_cekin <".$tgljn.") and id_perusahaan=".Yii::$app->user->identity->id_perusahaan)->queryScalar();
            if($detail==""){
                $sumary2= '';
            }else{
                $sumary2=$detail;
            }


            echo "<tr><td>".$tgljn."</td><td>".$sumary1."</td><td>".$sumary2."</td></tr>";

        }


?>
    </table>


</div>
