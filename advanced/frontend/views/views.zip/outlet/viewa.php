<?php

use yii\helpers\Html;
use yii\widgets\DetailView;
use yii\widgets\ActiveForm;
use yii\helpers\Url;
use yii\bootstrap\Modal;
use kartik\grid\GridView;
use johnitvn\ajaxcrud\CrudAsset; 

use johnitvn\ajaxcrud\BulkButtonWidget;
/* @var $this yii\web\View */
/* @var $model app\models\Outlet */

$this->title = $model->id;
$this->params['breadcrumbs'][] = ['label' => 'Outlets', 'url' => ['index']];
$this->params['breadcrumbs'][] = $this->title;
CrudAsset::register($this);
?>
<div class="outlet-view">

   
    <h3><?php echo "Tanggal : ". date('d-M-Y',time());?></h3>

    <?= DetailView::widget([
        'model' => $model,
        'attributes' => [
            'no_bon',
            'bon',
        ],
    ]) ?>
      <div class="outletdet-index">
        <div id="ajaxCrudDatatable">
            <?=GridView::widget([
                'id'=>'crud-datatable',
                'dataProvider' => $dataProvider,
                'filterModel' => $searchModel,
                'pjax'=>true,
                'columns' => require(__DIR__.'/_columns.php'),
                'toolbar'=> [
                    ['content'=>
                        Html::a('<i class="glyphicon glyphicon-plus"></i>', ['createdet','id'=>$model->id],
                        ['role'=>'modal-remote','title'=> 'Create Detail Transaksi','class'=>'btn btn-default']).
                        Html::a('<i class="glyphicon glyphicon-repeat"></i>', [''],
                        ['data-pjax'=>1, 'class'=>'btn btn-default', 'title'=>'Reset Grid']).
                        '{toggleData}'.
                        '{export}'
                    ],
                ],          
                'striped' => true,
                'condensed' => true,
                'responsive' => true,          
                'panel' => [
                    'type' => 'primary', 
                    'heading' => '<i class="glyphicon glyphicon-list"></i> Detail Transaksi',
                    'before'=>'<em>* Resize table columns just like a spreadsheet by dragging the column edges.</em>',
                    'after'=>BulkButtonWidget::widget([
                                'buttons'=>Html::a('<i class="glyphicon glyphicon-trash"></i>&nbsp; Delete All',
                                    ["bulk-deletedet"] ,
                                    [
                                        "class"=>"btn btn-danger btn-xs",
                                        'role'=>'modal-remote-bulk',
                                        'data-confirm'=>false, 'data-method'=>false,// for overide yii data api
                                        'data-request-method'=>'post',
                                        'data-confirm-title'=>'Are you sure?',
                                        'data-confirm-message'=>'Are you sure want to delete this item'
                                    ]),
                            ]).                        
                            '<div class="clearfix"></div>',
                ]
            ])?>
        </div>
    </div>
    <?php Modal::begin([
        "id"=>"ajaxCrudModal",
        'options' => [
    'tabindex' => false, // important for Select2 to work properly
    ],
        "footer"=>"",// always need it for jquery plugin
    ])?>
    <?php Modal::end(); ?>
    <p>
        <?= Html::a('Pembayaran', ['totala', 'id' => $model->id], ['class' => 'btn btn-danger']) ?>
        <?= Html::a('Batal', ['batal', 'id' => $model->id], ['class' => 'btn btn-danger']) ?>
    </p>
</div>
