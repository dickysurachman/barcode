<?php

use yii\helpers\Html;


/* @var $this yii\web\View */
/* @var $model app\models\Outletdet */

?>
<div class="outletdet-create">
    <?= $this->render('_formdet', [
        'model' => $model,
    ]) ?>
</div>
