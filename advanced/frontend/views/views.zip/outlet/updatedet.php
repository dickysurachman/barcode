<?php

use yii\helpers\Html;

/* @var $this yii\web\View */
/* @var $model app\models\Outletdet */
?>
<div class="outletdet-update">

    <?= $this->render('_formdet', [
        'model' => $model,
    ]) ?>

</div>
