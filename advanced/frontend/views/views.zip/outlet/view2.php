<?php

use yii\helpers\Html;
use yii\widgets\DetailView;
use yii\widgets\ActiveForm;
use yii\helpers\Url;
use yii\bootstrap\Modal;
use kartik\grid\GridView;
use app\models\Outletdet;
use johnitvn\ajaxcrud\CrudAsset; 

use johnitvn\ajaxcrud\BulkButtonWidget;
/* @var $this yii\web\View */
/* @var $model app\models\Outlet */

$this->title = $model->id;
$this->params['breadcrumbs'][] = ['label' => 'Outlets', 'url' => ['index']];
$this->params['breadcrumbs'][] = $this->title;
CrudAsset::register($this);
?>
<div class="outlet-view">

   <?php 
$detail=Outletdet::find()->where(['id_bon'=>$model->id])->All();
?>
<table id="w0" class="table table-striped table-bordered detail-view">
<tbody>
<tr>
<th>Nama Item</th>
<th>Harga</th>
<th>Qty</th>
<th>Total</th>
</tr>
<?php
foreach ($detail as $key) {
?>
<tr>
<td><?php echo $key->barang ?></td>
<td><?php echo $key->hrg_satuan ?></td>
<td><?php echo $key->jumlah ?></td>
<td><?php echo $key->grandtotal ?></td>
</tr>
<?php }
?>
</tbody>
</table>

<?= DetailView::widget([
        'model' => $model,
        'attributes' => [
            'grandtotal',
        ],
    ]) ?>
    <p>
    
        <?= Html::a('Print', ['voucher', 'id' => $model->id], ['class' => 'btn btn-danger','target'=>'_blank']) ?>
    </p>
</div>
