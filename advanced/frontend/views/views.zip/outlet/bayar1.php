<?php

use yii\helpers\Html;
use yii\widgets\ActiveForm;
use app\models\Penerimaan;
use yii\helpers\ArrayHelper;
use kartik\select2\Select2;
use app\models\Masterb;
use app\models\Company;
/* @var $this yii\web\View */
/* @var $model app\models\Outlet */
/* @var $form yii\widgets\ActiveForm */
use yii\widgets\DetailView;
use app\models\Outletdet;
?>

<div class="outlet-form">
    <?php $form = ActiveForm::begin(); ?>

    <?php
    echo $form->field($model, 'id_company')->widget(Select2::classname(), [
    'data' => ArrayHelper::map(Company::find()->where(['id_perusahaan'=>Yii::$app->user->identity->id_perusahaan])->all(), 'kode', 'nama'),
    'options' => ['placeholder' => 'Select '],
    'pluginOptions' => [
        'allowClear' => true
    ],
    ]); ?>
  
    <div class="form-group">
        <?= Html::submitButton($model->isNewRecord ? 'Create' : 'Update', ['class' => $model->isNewRecord ? 'btn btn-success' : 'btn btn-primary']) ?>
    </div>

    <?php ActiveForm::end(); ?>

</div>
