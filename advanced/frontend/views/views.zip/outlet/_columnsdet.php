<?php
use yii\helpers\Url;

return [
    [
        'class' => 'kartik\grid\SerialColumn',
        'width' => '30px',
    ],
   
        // [
        // 'class'=>'\kartik\grid\DataColumn',
        // 'attribute'=>'id',
    // ],
    [
        'class'=>'\kartik\grid\DataColumn',
        'attribute'=>'bon',
        'value'=>'nobon'
    ],
    [
        'class'=>'\kartik\grid\DataColumn',
        'attribute'=>'tgl',
        'value'=>'tanggal',
    ], 
    [
        'class'=>'\kartik\grid\DataColumn',
        'attribute'=>'nama',
        'value'=>'barang',
    ],
    [
        'class'=>'\kartik\grid\DataColumn',
        'attribute'=>'hrg_satuan',
    ],
    [
        'class'=>'\kartik\grid\DataColumn',
        'attribute'=>'jumlah',
    ],
    [
        'class'=>'\kartik\grid\DataColumn',
        'attribute'=>'grandtotal',
    ],
    // [
        // 'class'=>'\kartik\grid\DataColumn',
        // 'attribute'=>'add_who',
    // ],
    // [
        // 'class'=>'\kartik\grid\DataColumn',
        // 'attribute'=>'add_date',
    // ],
    // [
        // 'class'=>'\kartik\grid\DataColumn',
        // 'attribute'=>'edit_who',
    // ],
    // [
        // 'class'=>'\kartik\grid\DataColumn',
        // 'attribute'=>'edit_date',
    // ],
   

];   