<?php 

use app\models\Perusahaan;
$haha=Perusahaan::findOne(1);

?>
<html xmlns:v="urn:schemas-microsoft-com:vml"
xmlns:o="urn:schemas-microsoft-com:office:office"
xmlns:x="urn:schemas-microsoft-com:office:excel"
xmlns="http://www.w3.org/TR/REC-html40">

<head>
<meta http-equiv=Content-Type content="text/html; charset=windows-1252">
<meta name=ProgId content=Excel.Sheet>
<meta name=Generator content="Microsoft Excel 15">
<link id=Main-File rel=Main-File href="../bon.htm">
<link rel=File-List href=filelist.xml>
<link rel=Stylesheet href=st.css>
<style>
<!--table
	{mso-displayed-decimal-separator:"\.";
	mso-displayed-thousand-separator:"\,";}
@page
	{margin:.75in .7in .75in .7in;
	mso-header-margin:.3in;
	mso-footer-margin:.3in;}
-->
tr
	{mso-height-source:auto;}
col
	{mso-width-source:auto;}
br
	{mso-data-placement:same-cell;}
.style0
	{mso-number-format:General;
	text-align:general;
	vertical-align:bottom;
	white-space:nowrap;
	mso-rotate:0;
	mso-background-source:auto;
	mso-pattern:auto;
	color:black;
	font-size:11.0pt;
	font-weight:400;
	font-style:normal;
	text-decoration:none;
	font-family:Calibri, sans-serif;
	mso-font-charset:0;
	border:none;
	mso-protection:locked visible;
	mso-style-name:Normal;
	mso-style-id:0;}
td
	{mso-style-parent:style0;
	padding-top:1px;
	padding-right:1px;
	padding-left:1px;
	mso-ignore:padding;
	color:black;
	font-size:11.0pt;
	font-weight:400;
	font-style:normal;
	text-decoration:none;
	font-family:Calibri, sans-serif;
	mso-font-charset:0;
	mso-number-format:General;
	text-align:general;
	vertical-align:bottom;
	border:none;
	mso-background-source:auto;
	mso-pattern:auto;
	mso-protection:locked visible;
	mso-rotate:0;}
.xl65
	{mso-style-parent:style0;
	font-weight:700;}
.xl66
	{mso-style-parent:style0;
	text-align:right;}
.xl67
	{mso-style-parent:style0;
	text-align:center;}
.xl68
	{mso-style-parent:style0;
	font-weight:700;
	text-align:center;}
.xl69
	{mso-style-parent:style0;
	text-align:left;}
.xl70
	{mso-style-parent:style0;
	mso-number-format:"\#\,\#\#0";
	text-align:center;}
.xl71
	{mso-style-parent:style0;
	color:#333333;
	font-family:"Source Sans Pro", sans-serif;
	mso-font-charset:0;
	text-align:center;
	vertical-align:top;}
.xl72
	{mso-style-parent:style0;
	font-size:10.0pt;
	font-weight:700;
	text-align:center;
	border-top:none;
	border-right:none;
	border-bottom:.5pt solid windowtext;
	border-left:none;}
.xl73
	{mso-style-parent:style0;
	font-size:12.0pt;
	font-weight:700;
	text-align:center;}
.xl74
	{mso-style-parent:style0;
	font-size:14.0pt;
	font-weight:700;
	text-align:center;}

</style>

</head>

<body link="#0563C1" vlink="#954F72">

<table border=0 cellpadding=0 cellspacing=0 width=370 style='border-collapse:
 collapse;table-layout:fixed;width:277pt'>
 <col width=151 style='mso-width-source:userset;mso-width-alt:5522;width:113pt'>
 <col width=91 style='mso-width-source:userset;mso-width-alt:3328;width:68pt'>
 <col width=64 span=2 style='width:48pt'>
 <tr height=25 style='height:18.75pt'>
  <td colspan=4 height=25 class=xl74 width=370 style='height:18.75pt;
  width:277pt'><?php echo $haha->nama ?></td>
 </tr>
 <tr height=21 style='height:15.75pt'>
  <td colspan=4 height=21 class=xl73 style='height:15.75pt'><?php echo $haha->alamat?></td>
 </tr>
 <tr height=20 style='height:15.0pt'>
  <td colspan=4 height=20 class=xl72 style='height:15.0pt'>Telp. <?php echo $haha->telp ?>, Fax. <?php echo $haha->fax ?></td>
 </tr>
 <tr height=20 style='height:15.0pt'>
  <td height=20 colspan=4 style='height:15.0pt;mso-ignore:colspan'></td>
 </tr>
 <tr height=20 style='height:15.0pt'>
  <td height=20 class=xl65 style='height:15.0pt'>Nama Outlet</td>
  <td><?php echo $nama?></td>
  <td colspan=2 style='mso-ignore:colspan'></td>
 </tr>
 <tr height=20 style='height:15.0pt'>
  <td height=20 class=xl65 style='height:15.0pt'>No. Transaksi</td>
  <td class=xl69><?php echo $model->no_bon ?></td>
  <td colspan=2 style='mso-ignore:colspan'></td>
 </tr>
 <tr height=20 style='height:15.0pt'>
  <td height=20 class=xl65 style='height:15.0pt'></td>
  <td class=xl66></td>
  <td colspan=2 style='mso-ignore:colspan'></td>
 </tr>
 <tr height=20 style='height:15.0pt'>
  <td height=20 class=xl68 style='height:15.0pt'>Nama Item</td>
  <td class=xl68>Harga</td>
  <td class=xl68>Satuan</td>
  <td class=xl68>Total</td>
 </tr>
 <?php 
 foreach ($detail as $key){
 ?>
 <tr height=20 style='height:15.0pt'>
  <td height=20 class=xl65 style='height:15.0pt'><?php echo $key->barang ?></td>
  <td class=xl67><?php echo number_format($key->hrg_satuan) ?></td>
  <td class=xl67><?php echo $key->jumlah?></td>
  <td class=xl70><?php echo $key->grandtotal?></td>
 </tr>
 <?php 

 }?>
 <tr height=20 style='height:15.0pt'>
  <td height=20 class=xl65 style='height:15.0pt'></td>
  <td class=xl66></td>
  <td colspan=2 style='mso-ignore:colspan'></td>
 </tr>
 <tr height=20 style='height:15.0pt'>
  <td height=20 class=xl65 style='height:15.0pt'><u>Grand Total</u></td>
  <td class=xl66></td>
  <td></td>
  <td><?php echo number_format($model->total) ?></td>
 </tr>
 <tr height=20 style='height:15.0pt'>
  <td height=20 class=xl65 style='height:15.0pt'  colspan="4">Payment by <?php echo $model->penerimaan ?></td>
 </tr>
 <tr height=20 style='height:15.0pt'>
  <td height=20 class=xl65 style='height:15.0pt' colspan="4">Time Closed By <?php echo $model->add_who;?> <?php echo $model->jam?></td>
 </tr>
 <tr height=20 style='height:15.0pt'>
  <td height=20 class=xl65 style='height:15.0pt'></td>
  <td class=xl66></td>
  <td colspan=1 style='mso-ignore:colspan'></td>
 </tr>
 <tr height=20 style='height:15.0pt'>
  <td height=20 colspan=1 style='height:15.0pt;mso-ignore:colspan'></td>
  <td colspan=3 class=xl67><?php echo $haha->kota ?>, <?php echo $model->tanggal ?></td>
 </tr>
 <tr height=20 style='height:15.0pt'>
  <td height=20 colspan=2 style='height:15.0pt;mso-ignore:colspan'></td>
  <td colspan=2 class=xl67>Cashier</td>
 </tr>
 <tr height=20 style='height:15.0pt'>
  <td height=20 colspan=2 style='height:15.0pt;mso-ignore:colspan'></td>
  <td class=xl67></td>
  <td></td>
 </tr>
 <tr height=20 style='height:15.0pt'>
  <td height=20 colspan=2 style='height:15.0pt;mso-ignore:colspan'></td>
  <td class=xl67></td>
  <td></td>
 </tr>
 <tr height=20 style='height:15.0pt'>
  <td height=20 colspan=2 style='height:15.0pt;mso-ignore:colspan'></td>
  <td colspan=2 class=xl67><?php echo $model->add_who ?></td>
 </tr>
 <![if supportMisalignedColumns]>
 <tr height=0 style='display:none'>
  <td width=151 style='width:113pt'></td>
  <td width=91 style='width:68pt'></td>
  <td width=64 style='width:48pt'></td>
  <td width=64 style='width:48pt'></td>
 </tr>
 <![endif]>
</table>

</body>

</html>