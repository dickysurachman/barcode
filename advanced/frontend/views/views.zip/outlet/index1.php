<?php
use app\models\Profile;
use yii\helpers\Html;
use yii\grid\GridView;
use yii\widgets\ActiveForm;
use app\models\Penerimaan;
use yii\helpers\ArrayHelper;
use kartik\export\ExportMenu;
/* @var $this yii\web\View */
/* @var $searchModel app\models\OutletSearch */
/* @var $dataProvider yii\data\ActiveDataProvider */

$this->title = 'Transaksi Outlet by Folio';
$this->params['breadcrumbs'][] = $this->title;
?>
<div class="outlet-index">

    <h1><?= Html::encode($this->title) ?></h1>
    <?php // echo $this->render('_search', ['model' => $searchModel]); ?>

    <p>

        <?= Html::a('Data Pembayaran', ['bayarout/index'], ['class' => 'btn btn-success']) ?>

<?php 

$gridColumns = [
    ['class' => 'yii\grid\SerialColumn'],
     'no_bon',
            'tgl',
            'no_bon',
            'bon',
            //'id_profile',
            'total',
            'penerimaan',
            //'id_terima',
            'uraian',
            'add_who',
            'edit_who',
];

// Renders a export dropdown menu
echo ExportMenu::widget([
    'dataProvider' => $dataProvider,
    'columns' => $gridColumns
]);
?>
      
    </p>
    <div class="table-responsive">
    <?= GridView::widget([
        'dataProvider' => $dataProvider,
        'filterModel' => $searchModel,
        'columns' => [
            ['class' => 'yii\grid\SerialColumn'],
            ['attribute'=>'id_profile',
            'value'=>'outlet',
            'filter'=>ArrayHelper::map(Profile::find()->where(['id_perusahaan'=>Yii::$app->user->identity->id_perusahaan])->all(), 'id', 'nama'),
            //'filter'
            ],
            //'id',
            'tgl',
            'no_bon',
            [
            'attribute'=>'bon1',
            'value'=>'bon',
            ],
            //'id_profile',
            'total',
            [
            'attribute'=>'id_terima',
            'value'=>'penerimaan',
            'filter'=>ArrayHelper::map(Penerimaan::find()->where(['id_perusahaan'=>Yii::$app->user->identity->id_perusahaan])->orderBy('jenis')->asArray()->all(), 'id', 'jenis'), 
            ],
            //'id_terima',
            'uraian',
            'add_who',
            'edit_who',
            // 'status',
            // 'id_terima',
            // 'total',
            // 'diskon',
            // 'pajak',
            // 'service',
            // 'add_who',
            // 'add_date',
            // 'edit_who',
            // 'edit_date',
            [
                //'class' => 'yii\grid\ActionColumn',
                'header'=>'Print',
                'attribute' => 'img',
                'format' => 'raw',
                'label' => 'Status',
                'value'=>function ($data) {
                                return Html::a('<span class="glyphicon glyphicon-print" style="font-size:14pt;" title="Print"></span>',['voucher', 'id' => $data->id],
                                    ['target'=>'_blank', 'class' => 'linksWithTarget']);
                                },
            ],
                        [
                //'class' => 'yii\grid\ActionColumn',
                'header'=>'Bayar',
                'attribute' => 'img',
                'format' => 'raw',
                'label' => 'Bayar',
                'value'=>function ($data) {
                                if($data->getLunas()==false) {                                   
                                return Html::a('<span class="glyphicon glyphicon-usd" style="color:red;font-size:14pt;" title="Print"></span>',['update2', 'id' => $data->id],
                                ['class' => 'linksWithTarget']);
                                }
                                },
            ],

/*            [
            'class' => 'yii\grid\ActionColumn',
            'template'=>'{update}',
            ],*/
        ],
    ]); ?>
    </div>
</div>
