<?php
use yii\helpers\Html;
use yii\widgets\ActiveForm;
use yii\helpers\ArrayHelper;
/* @var $this yii\web\View */
/* @var $model app\models\Outletdet */
/* @var $form yii\widgets\ActiveForm */
use kartik\select2\Select2;
use app\models\Barang;
use yii\helpers\Url;
use yii\helpers\Json;
use yii\web\View;
use kartik\money\MaskMoney;
?>

<div class="outletdet-form">

    <?php $form = ActiveForm::begin(); ?>

    <?php
    echo $form->field($model, 'id_barang')->widget(Select2::classname(), [
    'data' => ArrayHelper::map(Barang::find()->where(['id_profile'=>Yii::$app->user->identity->id_profile,'status'=>0,'id_perusahaan'=>Yii::$app->user->identity->id_perusahaan])->all(), 'id', 'nama'),
    'options' => ['placeholder' => 'Select item '
    ],
    'pluginOptions' => [
        'allowClear' => true
    ],
    'pluginEvents' => [
       "select2:select" => "function(e) { populateClientCode(e.params.data.id); }",
    ]
    ]);
    ?>
    <?= $form->field($model, 'jumlah')->textInput() ?>
    <?php   
        //echo $form->field($model, 'hrg_satuan')->widget(MaskMoney::classname());
    ?>  
    <div id="hasil1">

    </div>
	<?php if (!Yii::$app->request->isAjax){ ?>
	  	<div class="form-group">
	        <?= Html::submitButton($model->isNewRecord ? 'Create' : 'Update', ['class' => $model->isNewRecord ? 'btn btn-success' : 'btn btn-primary']) ?>
	    </div>
	<?php } ?>

    <?php ActiveForm::end(); ?>
    
     <?php ob_start(); ?>
        <script>
            function populateClientCode(client_id) {
                var url = '<?= Url::to(['site/list4', 'id' => '-id-']) ?>';
                $.ajax({
                    url: url.replace('-id-', client_id),
                    success: function (data) {$( "#hasil1" ).html( data );
                    }
                });
            }
        </script>
        <?php $this->registerJs(str_replace(['<script>', '</script>'], '', ob_get_clean()), View::POS_END); ?>
</div>
