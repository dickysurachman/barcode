<?php

use yii\widgets\DetailView;

/* @var $this yii\web\View */
/* @var $model app\models\Kamar */
?>
<div class="kamar-view">
 
    <?= DetailView::widget([
        'model' => $model,
        'attributes' => [
            'id',
            'tipe_kamar',
            'single',
            'dobel',
            'extra',
            'fasilitas',
        ],
    ]) ?>

</div>
