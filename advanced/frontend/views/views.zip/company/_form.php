<?php
use yii\helpers\Html;
use yii\widgets\ActiveForm;

/* @var $this yii\web\View */
/* @var $model app\models\Company */
/* @var $form yii\widgets\ActiveForm */
$tipe=[
"AR Guest Ledger"=>"AR Guest Ledger",
"AR City Government Ledger"=>"AR City Government Ledger",
"AR City Corporate Ledger"=>"AR City Corporate Ledger",
"AR City TA Ledger"=>"AR City TA Ledger",
];
$tipe1=[
'Yes','No'];
?>

<div class="company-form">

    <?php $form = ActiveForm::begin(); ?>

    <div class="col-md-6" style="padding-left: 0px;"><?= $form->field($model, 'kode')->textInput(['maxlength' => true]) ?></div>

    <div class="col-md-6" style="padding-right: 0px"><?= $form->field($model, 'nama')->textInput(['maxlength' => true]) ?></div>

    <?= $form->field($model, 'alamat')->textInput(['maxlength' => true]) ?>

    <?= $form->field($model, 'telp')->dropDownList($tipe,['prompt'=>'Choose']) ?>

    <?= $form->field($model, 'kode_akun')->textInput(['maxlength' => true]) ?>

    <?= $form->field($model, 'payment')->dropDownList($tipe1,['prompt'=>'Choose']) ?>

  
	<?php if (!Yii::$app->request->isAjax){ ?>
	  	<div class="form-group">
	        <?= Html::submitButton($model->isNewRecord ? 'Create' : 'Update', ['class' => $model->isNewRecord ? 'btn btn-success' : 'btn btn-primary']) ?>
	    </div>
	<?php } ?>

    <?php ActiveForm::end(); ?>
    
</div>
