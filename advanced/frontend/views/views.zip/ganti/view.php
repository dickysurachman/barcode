<?php

use yii\widgets\DetailView;

/* @var $this yii\web\View */
/* @var $model app\models\Roomchange */
?>
<div class="roomchange-view">
 
    <?= DetailView::widget([
        'model' => $model,
        'attributes' => [
            'id',
            'id_bon',
            'cekin',
            'from_kamar',
            'to_kamar',
            'add_who',
            'add_date',
            'edit_who',
            'edit_date',
        ],
    ]) ?>

</div>
