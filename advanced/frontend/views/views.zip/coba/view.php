<?php

use yii\widgets\DetailView;

/* @var $this yii\web\View */
/* @var $model app\models\Pp */
?>
<div class="pp-view">
 
    <?= DetailView::widget([
        'model' => $model,
        'attributes' => [
            'id',
            'nama',
            'alamat:ntext',
            'telp',
            'fax',
            'shelter',
            'map:ntext',
            'sdm',
            'sdl',
            'map_bib:ntext',
            'jml_shelter',
            'luas_shelter',
            'dt_shelter',
            'map_bet:ntext',
            'id_perusahaan',
        ],
    ]) ?>

</div>
