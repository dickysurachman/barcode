<?php

use yii\helpers\Html;


/* @var $this yii\web\View */
/* @var $model app\models\Pp */

?>
<div class="pp-create">
    <?= $this->render('_form', [
        'model' => $model,
    ]) ?>
</div>
