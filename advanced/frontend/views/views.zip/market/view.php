<?php

use yii\widgets\DetailView;

/* @var $this yii\web\View */
/* @var $model app\models\Market */
?>
<div class="market-view">
 
    <?= DetailView::widget([
        'model' => $model,
        'attributes' => [
            'kode',
            'nama',
            'keterangan',
        ],
    ]) ?>

</div>
