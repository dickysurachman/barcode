<?php

use yii\helpers\Html;
use yii\widgets\ActiveForm;
use kartik\money\MaskMoney;
use kartik\select2\Select2;
$url = \yii\helpers\Url::to(['reservasi/guest']);
use yii\web\JsExpression;
//use app\models\Guest;
use yii\jui\DatePicker;
use yii\web\View;
use app\models\Guest;
use app\models\Market;
use app\models\Company;
use app\models\Rate;
use app\models\Penerimaan;
use app\models\Tipekamar;
use yii\helpers\ArrayHelper;
// Get the initial city description
$cityDesc =empty($model->id_guest) ? '' : Guest::findOne($model->id_guest)->nama;
//$cityDesc = "Ketikkan Nama";//empty($model->city) ? '' : City::findOne($model->city)->description;
$script = <<< JS
$("#nobon-cout").datepicker({
    changeMonth: true, 
    changeYear: true, 
    dateFormat:'yy-mm-dd',
    'minDate':'today',
    'maxDate':'2017-12-21',
JS;
$script .="'maxDate':'".date('Y-m-d',strtotime($model->cout))."'});";
 
$position= View::POS_END;
$this->registerJs($script,$position);

/* @var $this yii\web\View */
/* @var $model app\models\Nobon */
/* @var $form yii\widgets\ActiveForm */
?>

<div class="nobon-form">



    <?php $form = ActiveForm::begin(); ?>


   
       <label class="control-label" for="semen-tgl"><?php echo "Tanggal Check Out" ?> </label>
        <?php
        echo DatePicker::widget([
        'model'  => $model,
        'attribute'=>'cout',
        'dateFormat' => 'yyyy-MM-dd',
        'options'=>['class'=>'form-control','autocomplete'=>'off','readonly'=>'readonly']
    ]);?>
   
    <?= $form->field($model, 'keterangan')->textInput(['maxlength' => true]) ?>
    
   
    <div class="form-group">
        <?= Html::submitButton($model->isNewRecord ? 'Create' : 'Update', ['class' => $model->isNewRecord ? 'btn btn-success' : 'btn btn-primary']) ?>
    </div>

    <?php ActiveForm::end(); ?>

</div>
