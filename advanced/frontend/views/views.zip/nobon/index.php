
<?php

use yii\helpers\Html;
use yii\grid\GridView;
use yii\helpers\ArrayHelper;
//use app\models\Tipekamar;
//use yii\grid\GridView;
use kartik\export\ExportMenu;
use kartik\select2\Select2;
//use kartik\grid\GridView;
use yii\web\JsExpression;
use yii\web\View;
use app\models\Guest;
use app\models\Market;
use app\models\Company;
use app\models\Rate;
use app\models\Penerimaan;
use app\models\Tipekamar;
/* @var $this yii\web\View */
/* @var $searchModel app\models\NobonSearch */
/* @var $dataProvider yii\data\ActiveDataProvider */
$url = \yii\helpers\Url::to(['reservasi/guest']);
$this->title = 'Checkin';
$this->params['breadcrumbs'][] = $this->title;


 
// Register the formatting script
//$this->registerJs($formatJs, \yii\web\View::POS_HEAD);
//$cityDesc=empty($searchModel->id_guest) ? '' : Guest::findOne($searchModel->id_guest)->nama;
if(isset($searchModel->id_guest)){
    $tamu=Guest::findOne($searchModel->id_guest);
    if(isset($tamu)) {

    $cityDesc=$tamu->nama;
    } else {
    $cityDesc="";
        
    }
}else {
    $cityDesc="";

}

/*$amount = 0;
$amountrns = 0;
    //if (!isset($dataProvider->getModels())) {
    if (isset($dataProvider)) {
        foreach ($dataProvider->getModels() as $key => $val) {
            $amount += $val->diskon;
            //$amountrns += $val->rns;
        }
    }
*/
?>
<div class="nobon-index">

    <h1><?= Html::encode($this->title) ?></h1>
    <?php // echo $this->render('_search', ['model' => $searchModel]); ?>

    <p>
        


<?php 
$gridColumns = [
    ['class' => 'yii\grid\SerialColumn'],
     'no_bon',
            'namatamu',
            'tiba',
            'cout',
            'namakamar',
            'malam',
            'diskon',
            'hargatot',
            'aditional',
            'totalall',
];

// Renders a export dropdown menu
echo ExportMenu::widget([
    'dataProvider' => $dataProvider,
    'columns' => $gridColumns,
    'batchSize'=>0,

]);
?>
        <?= Html::a('Create Check In', ['create'], ['class' => 'btn btn-success']) ?>

    </p>
    <div class="table-responsive">
    <?= GridView::widget([
        'dataProvider' => $dataProvider,
        'filterModel' => $searchModel,
        //'showFooter'=>TRUE,
        'columns' => [
            ['class' => 'yii\grid\SerialColumn'],

           // 'id',
            'no_bon',
        [
             'attribute'=>'id_guest',
             'value'=>'namatamu',
             'filter'=> Select2::widget([
                            'name' => 'NobonSearch[id_guest]',
                            'theme' => Select2::THEME_BOOTSTRAP,
                            'value' => $cityDesc,//$nomeescola,
                            //'hideSearch' => true,
                            'options' => [
                                'initValueText' => $cityDesc, 
                                'placeholder' => 'Search',
                            ],
                            'pluginOptions' => [
                                'allowClear' => true,
                                'minimumInputLength' => 3,
                            'ajax' => [
                                'url' => $url,
                                'dataType' => 'json',
                                'data' => new JsExpression('function(params) { return {q:params.term}; }')
                            ],
                            'escapeMarkup' => new JsExpression('function (markup) { return markup; }'),
                            'templateResult' => new JsExpression('function(id_guest) { return id_guest.text; }'),
                            'templateSelection' => new JsExpression('function (id_guest) { return id_guest.text; }'),
                            ],
                        ]),
            ],
            //[
            //'attribute'=>'id_guest',
            //'value'=>'namatamu',
            //],
            //'id_guest',
            'tiba',
            'cout',
            [
            'attribute'=>'id_kamar',
            'filter'=>ArrayHelper::map(Tipekamar::find()->where(['id_perusahaan'=>Yii::$app->user->identity->id_perusahaan])->all(), 'id', 'nama_kamar'),
            'value'=>'namakamar',
            ],
            //'namakamar',
            'malam',
            [
            'attribute'=>'diskon',
            //'footer'=>number_format($amount),
            ],
            //'diskon',
            'hargatot',
            'aditional',
            //'total',
            [
            'attribute'=>'total',
            'value'=>'totalall'
            ],
            [
                'header'=>'Shorten',
                'attribute' => 'img',
                'format' => 'raw',
                'label' => 'Status',
                'value'=>function ($data) {
                                return Html::a('<span class="glyphicon glyphicon-minus" style="font-size:14pt;" title="Shorten"></span>',['shorten', 'id' => $data->id]);
                                },
            ],[
                'header'=>'Extend',
                'attribute' => 'img',
                'format' => 'raw',
                'label' => 'Status',
                'value'=>function ($data) {
                                return Html::a('<span class="glyphicon glyphicon-plus" style="font-size:14pt;" title="Extend"></span>',['extend', 'id' => $data->id]);
                                },
            ],
            [
                //'class' => 'yii\grid\ActionColumn',
                'header'=>'Print',
                'attribute' => 'img',
                'format' => 'raw',
                'label' => 'Status',
                'value'=>function ($data) {
                                return Html::a('<span class="glyphicon glyphicon-print" style="font-size:14pt;" title="Print"></span>',['cetak', 'id' => $data->id],
                                    ['target'=>'_blank', 'class' => 'linksWithTarget']) .' '. Html::a('<span class="glyphicon glyphicon-file" style="font-size:14pt;" title="Print"></span>',['cetak1', 'id' => $data->id],
                                    ['target'=>'_blank', 'class' => 'linksWithTarget']) ;
                                },
            ],  
            [
                //'class' => 'yii\grid\ActionColumn',
                'header'=>'RC',
                'attribute' => 'img',
                'format' => 'raw',
                'label' => 'Status',
                'value'=>function ($data) {
                                return Html::a('<span class="glyphicon glyphicon-print" style="font-size:14pt;" title="Print"></span>',['rc', 'id' => $data->id],
                                    ['target'=>'_blank', 'class' => 'linksWithTarget']);
                                },
            ],  
            [
                //'class' => 'yii\grid\ActionColumn',
                'header'=>'Bayar',
                'attribute' => 'img',
                'format' => 'raw',
                'label' => 'Bayar',
                'value'=>function ($data) {
                                return Html::a('<span class="glyphicon glyphicon-usd" style="font-size:14pt;" title="Print"></span>',['bayardet', 'id' => $data->id],
                                ['class' => 'linksWithTarget']);
                                },
            ],
            ['class' => 'yii\grid\ActionColumn'],
        ],
    ]); ?>
    </div>
</div>
