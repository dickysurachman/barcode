<?php
use yii\helpers\Html;
use yii\widgets\ActiveForm;
use app\models\Tipekamar;
use yii\helpers\ArrayHelper;


//$countries=Tipekamar::findOne($model->from_kamar);
$countries=Tipekamar::find()->where(['id'=>$model->from_kamar])->All();
$dataPost=ArrayHelper::map($countries,'id','nama_kamar');
$countries2=Tipekamar::find()->where(['status'=>'VC','id_perusahaan'=>Yii::$app->user->identity->id_perusahaan])->All();
$dataPost2=ArrayHelper::map($countries2,'id','nama_kamar');
/* @var $this yii\web\View */
/* @var $model app\models\Roomchange */
/* @var $form yii\widgets\ActiveForm */
//echo   $model->from_kamar;
?>

<div class="roomchange-form">

    <?php $form = ActiveForm::begin(); ?>

    <?= $form->field($model, 'from_kamar')->dropDownlist($dataPost) ?>

    <?= $form->field($model, 'to_kamar')->dropDownlist($dataPost2) ?>

    
    <?= $form->field($model, 'keterangan')->textInput() ?>


  
	<?php if (!Yii::$app->request->isAjax){ ?>
	  	<div class="form-group">
	        <?= Html::submitButton($model->isNewRecord ? 'Create' : 'Update', ['class' => $model->isNewRecord ? 'btn btn-success' : 'btn btn-primary']) ?>
	    </div>
	<?php } ?>

    <?php ActiveForm::end(); ?>
    
</div>
