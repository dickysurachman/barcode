<?php

use yii\helpers\Html;
use yii\grid\GridView;
use app\models\Tipekamar;
use yii\helpers\ArrayHelper;
/* @var $this yii\web\View */
/* @var $searchModel app\models\NobonSearch */
/* @var $dataProvider yii\data\ActiveDataProvider */

$this->title = 'Upgrade Room';
$this->params['breadcrumbs'][] = $this->title;
?>
<div class="nobon-index">

    <h1><?= Html::encode($this->title) ?></h1>
    <?php // echo $this->render('_search', ['model' => $searchModel]); ?>

    <p>
       
    </p>
    <div class="table-responsive">
    <?= GridView::widget([
        'dataProvider' => $dataProvider,
        'filterModel' => $searchModel,
        'columns' => [
            ['class' => 'yii\grid\SerialColumn'],

           // 'id',
            'no_bon',
            [
            'attribute'=>'id_guest',
            'value'=>'namatamu',
            ],
            'tiba',
            'cout',
            [
            'attribute'=>'id_kamar',
            'filter'=>ArrayHelper::map(Tipekamar::find()->where(['id_perusahaan'=>Yii::$app->user->identity->id_perusahaan])->all(), 'id', 'nama_kamar'),
            'value'=>'namakamar',
            ],
           // 'namakamar',
            'malam',
            'hargatot',
            'total',
            [
                //'class' => 'yii\grid\ActionColumn',
                'header'=>'Upgrade Room',
                'attribute' => 'img',
                'format' => 'raw',
                'label' => 'Status',
                'value'=>function ($data) {
                                return Html::a('<span class="glyphicon glyphicon-share" style="font-size:14pt;" title="Upgrade Room"></span>',['upgraderoom', 'id' => $data->id]);
                                },
            ],
            
        ],
    ]); ?>
</div>
</div>