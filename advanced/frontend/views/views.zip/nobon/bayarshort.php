<?php

use yii\helpers\Html;
use yii\widgets\DetailView;
use yii\widgets\ActiveForm;
use kartik\money\MaskMoney;
use kartik\select2\Select2;
$url = \yii\helpers\Url::to(['reservasi/guest']);
use yii\web\JsExpression;
//use app\models\Guest;
use yii\jui\DatePicker;
use yii\web\View;
use app\models\Guest;
use app\models\Market;
use app\models\Company;
use app\models\Rate;
use app\models\Penerimaan;
use app\models\Tipekamar;
use yii\helpers\ArrayHelper;
// Get the initial city description


/* @var $this yii\web\View */
/* @var $model app\models\Nobon */
/* @var $form yii\widgets\ActiveForm */
?>

<div class="nobon-form">
<?= DetailView::widget([
        'model' => $model,
        'attributes' => [
            
            'no_bon',
            'namatamu',
            'tiba',
            'cout',
            'malam',
            'namakamar',
            'tipekamar',
            'hargatot',
            'totald',
            'sisanya'
        ],
    ]) ?>
    <?php $form = ActiveForm::begin(); ?>


    
    <div class="col-md-6" style="padding-left: 0px;">
    <?php
        echo $form->field($model, 'id_terima2')->widget(Select2::classname(), [
        'data' => ArrayHelper::map(Penerimaan::find()->where(['status'=>0,'id_perusahaan'=>Yii::$app->user->identity->id_perusahaan])->all(), 'id', 'jenis'),
        'options' => ['placeholder' => 'Select '],
        'pluginOptions' => [
            'allowClear' => true
        ],
        ]);
    ?>
    </div>
    <div class="col-md-6" style="padding-right: 0px;">
    <?php
    echo $form->field($model, 'deposit2')->widget(MaskMoney::classname());
    ?>
    </div>
    
   
    <div class="form-group">
        <?= Html::submitButton($model->isNewRecord ? 'Create' : 'Update', ['class' => $model->isNewRecord ? 'btn btn-success' : 'btn btn-primary']) ?>
    </div>

    <?php ActiveForm::end(); ?>

</div>
