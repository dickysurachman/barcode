<?php

use yii\helpers\Html;
use yii\grid\GridView;
use yii\helpers\ArrayHelper;
//use app\models\Tipekamar;
//use yii\grid\GridView;
use kartik\export\ExportMenu;
use kartik\select2\Select2;
//use kartik\grid\GridView;
use yii\web\JsExpression;
use yii\web\View;
use app\models\Guest;
use app\models\Market;
use app\models\Company;
use app\models\Rate;
use app\models\Penerimaan;
use app\models\Tipekamar;
/* @var $this yii\web\View */
/* @var $searchModel app\models\NobonSearch */
/* @var $dataProvider yii\data\ActiveDataProvider */
$url = \yii\helpers\Url::to(['reservasi/guest']);
$this->title = 'Report Checkin';
$this->params['breadcrumbs'][] = $this->title;
$this->registerJs('
        function detail(obj,person_id){
            /*
                <table> 
                    <tr>
                        <td>
                            <a> */
            var a = obj; // get element anchor
            var td = $(a).parent();
            var tr = $(td).parent();
            var tdCount = $(tr).children().length;
            var table = $(tr).parent(); 
            $(table).children(".trDetail").remove();
            var trDetail = document.createElement("tr");
            $(trDetail).attr("class","trDetail");  
            var tdDetail = document.createElement("td");
            $(tdDetail).attr("colspan",tdCount);
            $(tdDetail).html("<span class=\'fa fa-spinner fa-spin\'></span>");              
            $.get("'.\yii\helpers\Url::to(['guest/viewx']).'?id="+person_id, function( data ) {
              $(tdDetail).html( data );
            }).fail(function() {
                alert( "error" );
              });
            $(trDetail).append(tdDetail); // add td to tr
            $(tr).after(trDetail);  // add tr to table
        }
     ', \yii\web\View::POS_HEAD);
 
// Register the formatting script
//$this->registerJs($formatJs, \yii\web\View::POS_HEAD);
//$cityDesc=empty($searchModel->id_guest) ? '' : Guest::findOne($searchModel->id_guest)->nama;
if(isset($searchModel->id_guest)){
    $tamu=Guest::findOne($searchModel->id_guest);
    if(isset($tamu)) {

    $cityDesc=$tamu->nama;
    } else {
    $cityDesc="";
        
    }
}else {
    $cityDesc="";

}

?>
<div class="nobon-index">

    <h1><?= Html::encode($this->title) ?></h1>

    <?php  echo $this->render('_searchd', ['model' => $searchModel]); ?>
    <?php // echo $this->render('_search', ['model' => $searchModel]); ?>

    <p>
        

<?php 


$gridColumns = [
    ['class' => 'yii\grid\SerialColumn'],
     'no_bon',
     
            'namatamu',
            'tiba',
            'cout',
            'namakamar',
            'tipekamar',
            'rate',
            'market',
            'costumer',
            'penerimaan',
            'malam',
            'harga',
            'breakfast',
            'hargatot',
            'aditional',
            'totalall',
            'deposit',
            'deposit2',
            'sisa',
            'add_who',
             'edit_who',
];

// Renders a export dropdown menu
echo ExportMenu::widget([
    'dataProvider' => $dataProvider,
    'filterModel' => $searchModel,
    'columns' => $gridColumns
]);
?>
    </p>
    <div class="table-responsive">
    <?= GridView::widget([
        'dataProvider' => $dataProvider,
        'filterModel' => $searchModel,
        //'htmlOptions'=>['class'=> 'table-responsive'],
        'columns' => [
            ['class' => 'yii\grid\SerialColumn'],
           // 'id',
            'no_bon',
            [
             'attribute'=>'id_guest',
             'format'=>'raw',
              'value' => function ($data){
                    return Html::a($data->namatamu,'#',['onclick'=>'detail(this,'.$data->id_guest.');return false;']);
                }  ,
             'filter'=> Select2::widget([
                            'name' => 'NobonSearch[id_guest]',
                            'theme' => Select2::THEME_BOOTSTRAP,
                            'value' => $cityDesc,//$nomeescola,
                            //'hideSearch' => true,
                            'options' => [
                                'initValueText' => $cityDesc, 
                                'placeholder' => 'Search',
                            ],
                            'pluginOptions' => [
                                'allowClear' => true,
                                'minimumInputLength' => 3,
                            'ajax' => [
                                'url' => $url,
                                'dataType' => 'json',
                                'data' => new JsExpression('function(params) { return {q:params.term}; }')
                            ],
                            'escapeMarkup' => new JsExpression('function (markup) { return markup; }'),
                            'templateResult' => new JsExpression('function(id_guest) { return id_guest.text; }'),
                            'templateSelection' => new JsExpression('function (id_guest) { return id_guest.text; }'),
                            ],
                        ]),
            ],
            /*[
            'attribute'=>'id_guest',
            'value'=>'namatamu',
            ],*/
            //'id_guest',
            'tiba',
            'cout',
            [
            'attribute'=>'id_kamar',
            'filter'=>ArrayHelper::map(Tipekamar::find()->where(['id_perusahaan'=>Yii::$app->user->identity->id_perusahaan])->all(), 'id', 'nama_kamar'),
            'value'=>'namakamar',
            ],
            'tipekamar',
            //'rate',
            [
            'attribute'=>'id_rate',
            'filter'=>ArrayHelper::map(Rate::find()->where(['id_perusahaan'=>Yii::$app->user->identity->id_perusahaan])->all(), 'kode', 'nama'),
            'value'=>'rate',
            ],
            //'market',
            [
            'attribute'=>'id_market',
            'filter'=>ArrayHelper::map(Market::find()->where(['id_perusahaan'=>Yii::$app->user->identity->id_perusahaan])->all(), 'kode', 'nama'),
            'value'=>'market',
            ],

            //'costumer',
            [
            'attribute'=>'id_company',
            'filter'=>ArrayHelper::map(Company::find()->where(['id_perusahaan'=>Yii::$app->user->identity->id_perusahaan])->all(), 'kode', 'nama'),
            'value'=>'costumer',
            ],

//            'penerimaan',
            [
            'attribute'=>'id_terima',
            'filter'=>ArrayHelper::map(Penerimaan::find()->where(['id_perusahaan'=>Yii::$app->user->identity->id_perusahaan])->all(), 'id', 'jenis'),
            'value'=>'penerimaan',
            ],

            //'namakamar',
            'malam',
            'harga',
            'breakfast',
            'hargatot',
            'aditional',
            //'totalall',
            [
            'attribute'=>'total',
            'value'=>'totalall'
            ],
            'deposit',
            'deposit2',
            'sisa',
            [
                //'class' => 'yii\grid\ActionColumn',
                'header'=>'Print',
                'attribute' => 'img',
                'format' => 'raw',
                'label' => 'Status',
                'value'=>function ($data) {
                                return Html::a('<span class="glyphicon glyphicon-print" style="font-size:14pt;" title="Print"></span>',['cetak', 'id' => $data->id],
                                    ['target'=>'_blank', 'class' => 'linksWithTarget']) .' '. Html::a('<span class="glyphicon glyphicon-file" style="font-size:14pt;" title="Print"></span>',['cetak1', 'id' => $data->id],
                                    ['target'=>'_blank', 'class' => 'linksWithTarget']);
                                },
            ],
            'add_who',
             'edit_who',
            // 'id_pegawai',
            // 'pajak',
            // 'status',
            // 'diskon',
            // 'total',
            // 'nobukti',
            // 'deposit',
            // 'keterangan',
            // 'id_market',
            // 'id_rate',
            // 'id_company',
            // 'id_kamar',
            // 'id_terima',
            // 'harga',
            // 'breakfast',
            // 'service',
            // 'add_who',
            // 'add_date',
            // 'edit_who',
            // 'edit_date',

        ],
    ]); ?>
    </div>
</div>
