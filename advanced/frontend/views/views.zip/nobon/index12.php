<?php

use yii\helpers\Html;
//use yii\grid\GridView;
use yii\helpers\ArrayHelper;
use app\models\Tipekamar;
//use yii\grid\GridView;
use kartik\grid\GridView;
//use kartik\GridView;
use kartik\export\ExportMenu;
use kartik\select2\Select2;
use app\models\Guest;
use yii\web\View;
use yii\widgets\Pjax;
/* @var $this yii\web\View */
/* @var $searchModel app\models\NobonSearch */
/* @var $dataProvider yii\data\ActiveDataProvider */
use yii\web\JsExpression;
use yii\bootstrap\Modal;
$url = \yii\helpers\Url::to(['reservasi/guest']);
$this->title = 'Check In';
$this->params['breadcrumbs'][] = $this->title;
$cityDesc=empty($searchModel->id_guest) ? '' : Guest::findOne($searchModel->id_guest)->nama;

$script = <<< JS
    $(function() {
        $('#popp').click(function () {
            $('#modal1').modal('show')
        });
    });
JS;

    $this->registerJs($script);

?>
<div class="nobon-index">

    <h1><?= Html::encode($this->title) ?></h1>
    <?php // echo $this->render('_search', ['model' => $searchModel]); ?>

    <p>

<?php 
$gridColumns = [
    ['class' => 'yii\grid\SerialColumn'],
     'no_bon',
            'namatamu',
            'tiba',
            'cout',
            'namakamar',
            'malam',
            'diskon',
            'hargatot',
            'aditional',
            'totalall',
];

// Renders a export dropdown menu
echo ExportMenu::widget([
    'dataProvider' => $dataProvider,
    'columns' => $gridColumns
]);
?>
        <?= Html::a('Create Check In', ['create'], ['class' => 'btn btn-success']) ?>
<?php
    Modal::begin([
        'id' => 'modal1',
        'header' => '<h2>Barang</h2>',
        //'toggleButton' => ['label' => 'Show Students'],
    ]);

    Pjax::begin([
        'id'=>'pjax-barang-gridview',
        'timeout' => false,
        'enablePushState' => false,
    ]);

    echo GridView::widget([
            'dataProvider' => $dataProvider1,
            'filterModel' => $searchModel1,
            'pjax'=>true,
            'pjaxSettings'=>[
                            'options'=>[
                                'enablePushState'=>false,
                            ],
                        ],
            'columns' => [
                'nama',
                'harga',
            ],
         ]);

    Pjax::end();
    Modal::end();
?>
  <?= Html::a('Show Barang','#', ['id'=>'popp', 'class' => 'btn btn-success']) ?>
    </p>
    <div class="table-responsive">
    <?= GridView::widget([
        'dataProvider' => $dataProvider,
        'filterModel' => $searchModel,
        'columns' => [
            ['class' => 'yii\grid\SerialColumn'],

           // 'id',
            'no_bon',
        [
             'attribute'=>'id_guest',
             'value'=>'namatamu',
             'filter'=> Select2::widget([
                            'name' => 'NobonSearch[id_guest]',
                            'theme' => Select2::THEME_BOOTSTRAP,
                            'value' => $cityDesc,//$nomeescola,
                            //'hideSearch' => true,
                            'options' => [
                                'initValueText' => $cityDesc, 
                                'placeholder' => 'Search',
                            ],
                            'pluginOptions' => [
                                'allowClear' => true,
                                'minimumInputLength' => 3,
                            'ajax' => [
                                'url' => $url,
                                'dataType' => 'json',
                                'data' => new JsExpression('function(params) { return {q:params.term}; }')
                            ],
                            'escapeMarkup' => new JsExpression('function (markup) { return markup; }'),
                            'templateResult' => new JsExpression('function(id_guest) { return id_guest.text; }'),
                            'templateSelection' => new JsExpression('function (id_guest) { return id_guest.text; }'),
                            ],
                        ]),
            ],
            //[
            //'attribute'=>'id_guest',
            //'value'=>'namatamu',
            //],
            //'id_guest',
            'tiba',
            'cout',
            [
            'attribute'=>'id_kamar',
            'filter'=>ArrayHelper::map(Tipekamar::find()->all(), 'id', 'nama_kamar'),
            'value'=>'namakamar',
            ],
            //'namakamar',
            'malam',
            'diskon',
            'hargatot',
            'aditional',
            //'total',
            [
            'attribute'=>'total',
            'value'=>'totalall'
            ],
            [
                'header'=>'Shorten',
                'attribute' => 'img',
                'format' => 'raw',
                'label' => 'Status',
                'value'=>function ($data) {
                                return Html::a('<span class="glyphicon glyphicon-minus" style="font-size:14pt;" title="Shorten"></span>',['shorten', 'id' => $data->id]);
                                },
            ],[
                'header'=>'Extend',
                'attribute' => 'img',
                'format' => 'raw',
                'label' => 'Status',
                'value'=>function ($data) {
                                return Html::a('<span class="glyphicon glyphicon-plus" style="font-size:14pt;" title="Extend"></span>',['extend', 'id' => $data->id]);
                                },
            ],
            [
                //'class' => 'yii\grid\ActionColumn',
                'header'=>'Print',
                'attribute' => 'img',
                'format' => 'raw',
                'label' => 'Status',
                'value'=>function ($data) {
                                return Html::a('<span class="glyphicon glyphicon-print" style="font-size:14pt;" title="Print"></span>',['cetak', 'id' => $data->id],
                                    ['target'=>'_blank', 'class' => 'linksWithTarget']);
                                },
            ],
            ['class' => 'yii\grid\ActionColumn'],
        ],
    ]); ?>
    </div>
</div>
