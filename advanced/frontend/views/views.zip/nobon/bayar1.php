<?php

use yii\helpers\Html;
use yii\widgets\DetailView;
use yii\widgets\ActiveForm;
use kartik\money\MaskMoney;
use kartik\select2\Select2;
$url = \yii\helpers\Url::to(['reservasi/guest']);
use yii\web\JsExpression;
//use app\models\Guest;
use yii\jui\DatePicker;
use yii\web\View;
use app\models\Guest;
use app\models\Market;
use app\models\Company;
use app\models\Rate;
use app\models\Penerimaan;
use app\models\Tipekamar;
use yii\helpers\ArrayHelper;
// Get the initial city description

//$cityDesc = "Ketikkan Nama";//empty($model->city) ? '' : City::findOne($model->city)->description;


/* @var $this yii\web\View */
/* @var $model app\models\Nobon */
/* @var $form yii\widgets\ActiveForm */
?>

<div class="nobon-form">
<?= DetailView::widget([
        'model' => $model,
        'attributes' => [
            'no_bon',
            'namatamu',
            'tiba',
            'cout',
            'malam',
            'namakamar',
            'tipekamar',
            //'hargatot',
            //'totald',
        ],
    ]) ?>
    <?php $form = ActiveForm::begin(); ?>

    
      <?php   
        echo $form->field($model, 'harga')->widget(MaskMoney::classname());
        ?>            
    
  
    
   
   
    <div class="form-group">
        <?= Html::submitButton($model->isNewRecord ? 'Create' : 'Update', ['class' => $model->isNewRecord ? 'btn btn-success' : 'btn btn-primary']) ?>
    </div>

    <?php ActiveForm::end(); ?>

</div>
