<?php

use yii\helpers\Html;
use yii\widgets\DetailView;

/* @var $this yii\web\View */
/* @var $model app\models\Nobon */

$this->title = $model->id;
$this->params['breadcrumbs'][] = ['label' => 'Nobons', 'url' => ['index']];
$this->params['breadcrumbs'][] = $this->title;
?>
<div class="nobon-view">

    

    <p>
        <?php // Html::a('Update', ['update', 'id' => $model->id], ['class' => 'btn btn-primary']) ?>
        <?= Html::a('Cetak', ['cetak', 'id' => $model->id], ['class' => 'btn btn-primary','target'=>'_blank']) ?>
        
        <?php /* Html::a('Delete', ['delete', 'id' => $model->id], [
            'class' => 'btn btn-danger',
            'data' => [
                'confirm' => 'Are you sure you want to delete this item?',
                'method' => 'post',
            ],
        ]) */?>
    </p>

    <?= DetailView::widget([
        'model' => $model,
        'attributes' => [
            'no_bon',
            'namatamu',
            'cekin',
            'cekout',
            'malam',
            'namakamar',
            'tipekamar',
            'hargatot',
            'totald',
            /*'id',
            'no_bon',
            'id_guest',
            'tiba',
            'cout',
            'id_pegawai',
            'pajak',
            'status',
            'diskon',
            'total',
            'nobukti',
            'deposit',
            'keterangan',
            'id_market',
            'id_rate',
            'id_company',
            'id_kamar',
            'id_terima',
            'harga',
            'breakfast',
            'service',
            'add_who',
            'add_date',
            'edit_who',
            'edit_date',*/
        ],
    ]) ?>

</div>
