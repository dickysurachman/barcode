<?php
use app\models\Nobonya;
use app\models\Outlet;
use app\models\Bayarbon;
?>

<html xmlns:o="urn:schemas-microsoft-com:office:office"
xmlns:x="urn:schemas-microsoft-com:office:excel"
xmlns="http://www.w3.org/TR/REC-html40">

<head>
<meta http-equiv=Content-Type content="text/html; charset=windows-1252">
<meta name=ProgId content=Excel.Sheet>
<meta name=Generator content="Microsoft Excel 15">
<link rel=File-List href="bon/filelist.xml">
<style id="BILLING HARLIN TOUR 7 SEPTEMBER_29088_Styles">
<!--table
	{mso-displayed-decimal-separator:"\.";
	mso-displayed-thousand-separator:"\,";}
.xl1529088
	{padding-top:1px;
	padding-right:1px;
	padding-left:1px;
	mso-ignore:padding;
	color:windowtext;
	font-size:10.0pt;
	font-weight:400;
	font-style:normal;
	text-decoration:none;
	font-family:Arial, sans-serif;
	mso-font-charset:0;
	mso-number-format:General;
	text-align:general;
	vertical-align:bottom;
	mso-background-source:auto;
	mso-pattern:auto;
	white-space:nowrap;}
.xl6529088
	{padding-top:1px;
	padding-right:1px;
	padding-left:1px;
	mso-ignore:padding;
	color:windowtext;
	font-size:10.0pt;
	font-weight:400;
	font-style:normal;
	text-decoration:none;
	font-family:Garamond, serif;
	mso-font-charset:0;
	mso-number-format:General;
	text-align:general;
	vertical-align:bottom;
	mso-background-source:auto;
	mso-pattern:auto;
	white-space:nowrap;}
.xl6629088
	{padding-top:1px;
	padding-right:1px;
	padding-left:1px;
	mso-ignore:padding;
	color:windowtext;
	font-size:11.0pt;
	font-weight:700;
	font-style:normal;
	text-decoration:none;
	font-family:"Maiandra GD", sans-serif;
	mso-font-charset:0;
	mso-number-format:General;
	text-align:general;
	vertical-align:bottom;
	mso-background-source:auto;
	mso-pattern:auto;
	white-space:nowrap;}
.xl6729088
	{padding-top:1px;
	padding-right:1px;
	padding-left:1px;
	mso-ignore:padding;
	color:windowtext;
	font-size:11.0pt;
	font-weight:700;
	font-style:normal;
	text-decoration:none;
	font-family:"Courier New", monospace;
	mso-font-charset:0;
	mso-number-format:General;
	text-align:general;
	vertical-align:bottom;
	mso-background-source:auto;
	mso-pattern:auto;
	white-space:nowrap;}
.xl6829088
	{padding-top:1px;
	padding-right:1px;
	padding-left:1px;
	mso-ignore:padding;
	color:windowtext;
	font-size:12.0pt;
	font-weight:700;
	font-style:normal;
	text-decoration:none;
	font-family:"Maiandra GD", sans-serif;
	mso-font-charset:0;
	mso-number-format:General;
	text-align:left;
	vertical-align:bottom;
	mso-background-source:auto;
	mso-pattern:auto;
	white-space:nowrap;}
.xl6929088
	{padding-top:1px;
	padding-right:1px;
	padding-left:1px;
	mso-ignore:padding;
	color:windowtext;
	font-size:11.0pt;
	font-weight:700;
	font-style:normal;
	text-decoration:none;
	font-family:"Maiandra GD", sans-serif;
	mso-font-charset:0;
	mso-number-format:General;
	text-align:center;
	vertical-align:middle;
	border-top:none;
	border-right:none;
	border-bottom:.5pt solid black;
	border-left:none;
	mso-background-source:auto;
	mso-pattern:auto;
	white-space:nowrap;}
.xl7029088
	{padding-top:1px;
	padding-right:1px;
	padding-left:1px;
	mso-ignore:padding;
	color:windowtext;
	font-size:11.0pt;
	font-weight:700;
	font-style:normal;
	text-decoration:none;
	font-family:"Maiandra GD", sans-serif;
	mso-font-charset:0;
	mso-number-format:General;
	text-align:center;
	vertical-align:middle;
	mso-background-source:auto;
	mso-pattern:auto;
	white-space:nowrap;}
.xl7129088
	{padding-top:1px;
	padding-right:1px;
	padding-left:1px;
	mso-ignore:padding;
	color:windowtext;
	font-size:11.0pt;
	font-weight:700;
	font-style:normal;
	text-decoration:none;
	font-family:"Maiandra GD", sans-serif;
	mso-font-charset:0;
	mso-number-format:General;
	text-align:center;
	vertical-align:middle;
	border-top:.5pt solid black;
	border-right:none;
	border-bottom:.5pt solid black;
	border-left:none;
	mso-background-source:auto;
	mso-pattern:auto;
	white-space:nowrap;}
.xl7229088
	{padding-top:1px;
	padding-right:1px;
	padding-left:1px;
	mso-ignore:padding;
	color:windowtext;
	font-size:11.0pt;
	font-weight:700;
	font-style:normal;
	text-decoration:none;
	font-family:"Courier New", monospace;
	mso-font-charset:0;
	mso-number-format:"\#\,\#\#0\\ \;\\\(\#\,\#\#0\\\)";
	text-align:center;
	vertical-align:bottom;
	mso-background-source:auto;
	mso-pattern:auto;
	white-space:nowrap;}
.xl7329088
	{padding-top:1px;
	padding-right:1px;
	padding-left:1px;
	mso-ignore:padding;
	color:windowtext;
	font-size:11.0pt;
	font-weight:700;
	font-style:normal;
	text-decoration:none;
	font-family:"Courier New", monospace;
	mso-font-charset:0;
	mso-number-format:"\#\,\#\#0\\ \;\\\(\#\,\#\#0\\\)";
	text-align:general;
	vertical-align:bottom;
	mso-background-source:auto;
	mso-pattern:auto;
	white-space:nowrap;}
.xl7429088
	{padding-top:1px;
	padding-right:1px;
	padding-left:1px;
	mso-ignore:padding;
	color:windowtext;
	font-size:11.0pt;
	font-weight:700;
	font-style:normal;
	text-decoration:none;
	font-family:"Courier New", monospace;
	mso-font-charset:0;
	mso-number-format:"\#\,\#\#0\\ \;\\\(\#\,\#\#0\\\)";
	text-align:right;
	vertical-align:bottom;
	mso-background-source:auto;
	mso-pattern:auto;
	white-space:nowrap;}
.xl7529088
	{padding-top:1px;
	padding-right:1px;
	padding-left:1px;
	mso-ignore:padding;
	color:windowtext;
	font-size:10.0pt;
	font-weight:400;
	font-style:normal;
	text-decoration:none;
	font-family:"Maiandra GD", sans-serif;
	mso-font-charset:0;
	mso-number-format:General;
	text-align:general;
	vertical-align:bottom;
	mso-background-source:auto;
	mso-pattern:auto;
	white-space:nowrap;}
.xl7629088
	{padding-top:1px;
	padding-right:1px;
	padding-left:1px;
	mso-ignore:padding;
	color:windowtext;
	font-size:11.0pt;
	font-weight:400;
	font-style:normal;
	text-decoration:none;
	font-family:"Maiandra GD", sans-serif;
	mso-font-charset:0;
	mso-number-format:General;
	text-align:left;
	vertical-align:bottom;
	mso-background-source:auto;
	mso-pattern:auto;
	white-space:nowrap;}
.xl7729088
	{padding-top:1px;
	padding-right:1px;
	padding-left:1px;
	mso-ignore:padding;
	color:windowtext;
	font-size:11.0pt;
	font-weight:700;
	font-style:normal;
	text-decoration:none;
	font-family:"Courier New", monospace;
	mso-font-charset:0;
	mso-number-format:"dd\/mm\/yy\;\@";
	text-align:center;
	vertical-align:bottom;
	mso-background-source:auto;
	mso-pattern:auto;
	white-space:nowrap;}
.xl7829088
	{padding-top:1px;
	padding-right:1px;
	padding-left:1px;
	mso-ignore:padding;
	color:windowtext;
	font-size:11.0pt;
	font-weight:400;
	font-style:normal;
	text-decoration:none;
	font-family:Arial, sans-serif;
	mso-font-charset:0;
	mso-number-format:General;
	text-align:general;
	vertical-align:middle;
	mso-background-source:auto;
	mso-pattern:auto;
	white-space:nowrap;}
.xl7929088
	{padding-top:1px;
	padding-right:1px;
	padding-left:1px;
	mso-ignore:padding;
	color:windowtext;
	font-size:11.0pt;
	font-weight:400;
	font-style:normal;
	text-decoration:none;
	font-family:Arial, sans-serif;
	mso-font-charset:0;
	mso-number-format:General;
	text-align:general;
	vertical-align:bottom;
	mso-background-source:auto;
	mso-pattern:auto;
	white-space:nowrap;}
.xl8029088
	{padding-top:1px;
	padding-right:1px;
	padding-left:1px;
	mso-ignore:padding;
	color:windowtext;
	font-size:11.0pt;
	font-weight:400;
	font-style:normal;
	text-decoration:none;
	font-family:Garamond, serif;
	mso-font-charset:0;
	mso-number-format:General;
	text-align:general;
	vertical-align:bottom;
	mso-background-source:auto;
	mso-pattern:auto;
	white-space:nowrap;}
.xl8129088
	{padding-top:1px;
	padding-right:1px;
	padding-left:1px;
	mso-ignore:padding;
	color:windowtext;
	font-size:10.0pt;
	font-weight:400;
	font-style:normal;
	text-decoration:underline;
	text-underline-style:single;
	font-family:"Maiandra GD", sans-serif;
	mso-font-charset:0;
	mso-number-format:General;
	text-align:general;
	vertical-align:bottom;
	border-top:none;
	border-right:none;
	border-bottom:.5pt solid windowtext;
	border-left:none;
	mso-background-source:auto;
	mso-pattern:auto;
	white-space:nowrap;}
.xl8229088
	{padding-top:1px;
	padding-right:1px;
	padding-left:1px;
	mso-ignore:padding;
	color:windowtext;
	font-size:11.0pt;
	font-weight:400;
	font-style:normal;
	text-decoration:underline;
	text-underline-style:single;
	font-family:"Maiandra GD", sans-serif;
	mso-font-charset:0;
	mso-number-format:General;
	text-align:left;
	vertical-align:bottom;
	border-top:none;
	border-right:none;
	border-bottom:.5pt solid windowtext;
	border-left:none;
	mso-background-source:auto;
	mso-pattern:auto;
	white-space:nowrap;}
.xl8329088
	{padding-top:1px;
	padding-right:1px;
	padding-left:1px;
	mso-ignore:padding;
	color:windowtext;
	font-size:10.0pt;
	font-weight:700;
	font-style:normal;
	text-decoration:none;
	font-family:"Courier New", monospace;
	mso-font-charset:0;
	mso-number-format:"dd\/mm\/yy\;\@";
	text-align:left;
	vertical-align:bottom;
	mso-background-source:auto;
	mso-pattern:auto;
	white-space:nowrap;}
.xl8429088
	{padding-top:1px;
	padding-right:1px;
	padding-left:1px;
	mso-ignore:padding;
	color:windowtext;
	font-size:10.0pt;
	font-weight:400;
	font-style:normal;
	text-decoration:none;
	font-family:Arial, sans-serif;
	mso-font-charset:0;
	mso-number-format:General;
	text-align:general;
	vertical-align:bottom;
	border-top:none;
	border-right:none;
	border-bottom:1.0pt solid windowtext;
	border-left:none;
	mso-background-source:auto;
	mso-pattern:auto;
	white-space:nowrap;}
.xl8529088
	{padding-top:1px;
	padding-right:1px;
	padding-left:1px;
	mso-ignore:padding;
	color:windowtext;
	font-size:11.0pt;
	font-weight:700;
	font-style:normal;
	text-decoration:none;
	font-family:"Courier New", monospace;
	mso-font-charset:0;
	mso-number-format:"\[$-421\]dd\\ mmmm\\ yyyy\;\@";
	text-align:center;
	vertical-align:bottom;
	mso-background-source:auto;
	mso-pattern:auto;
	white-space:nowrap;}
.xl8629088
	{padding-top:1px;
	padding-right:1px;
	padding-left:1px;
	mso-ignore:padding;
	color:windowtext;
	font-size:11.0pt;
	font-weight:400;
	font-style:normal;
	text-decoration:none;
	font-family:"Maiandra GD", sans-serif;
	mso-font-charset:0;
	mso-number-format:General;
	text-align:general;
	vertical-align:bottom;
	mso-background-source:auto;
	mso-pattern:auto;
	white-space:nowrap;}
.xl8729088
	{padding-top:1px;
	padding-right:1px;
	padding-left:1px;
	mso-ignore:padding;
	color:windowtext;
	font-size:10.0pt;
	font-weight:700;
	font-style:normal;
	text-decoration:none;
	font-family:"Courier New", monospace;
	mso-font-charset:0;
	mso-number-format:"\#\,\#\#0\\ \;\\\(\#\,\#\#0\\\)";
	text-align:general;
	vertical-align:bottom;
	mso-background-source:auto;
	mso-pattern:auto;
	white-space:nowrap;}
.xl8829088
	{padding-top:1px;
	padding-right:1px;
	padding-left:1px;
	mso-ignore:padding;
	color:windowtext;
	font-size:10.0pt;
	font-weight:700;
	font-style:normal;
	text-decoration:none;
	font-family:Arial, sans-serif;
	mso-font-charset:0;
	mso-number-format:"\#\,\#\#0\\ \;\\\(\#\,\#\#0\\\)";
	text-align:center;
	vertical-align:bottom;
	mso-background-source:auto;
	mso-pattern:auto;
	white-space:nowrap;}
.xl8929088
	{padding-top:1px;
	padding-right:1px;
	padding-left:1px;
	mso-ignore:padding;
	color:windowtext;
	font-size:11.0pt;
	font-weight:700;
	font-style:normal;
	text-decoration:none;
	font-family:"Courier New", monospace;
	mso-font-charset:0;
	mso-number-format:"_\(* \#\,\#\#0_\)\;_\(* \\\(\#\,\#\#0\\\)\;_\(* \0022-\0022_\)\;_\(\@_\)";
	text-align:center;
	vertical-align:middle;
	mso-background-source:auto;
	mso-pattern:auto;
	white-space:nowrap;}
.xl9029088
	{padding-top:1px;
	padding-right:1px;
	padding-left:1px;
	mso-ignore:padding;
	color:windowtext;
	font-size:11.0pt;
	font-weight:700;
	font-style:normal;
	text-decoration:none;
	font-family:"Courier New", monospace;
	mso-font-charset:0;
	mso-number-format:General;
	text-align:center;
	vertical-align:middle;
	mso-background-source:auto;
	mso-pattern:auto;
	white-space:nowrap;}
.xl9129088
	{padding-top:1px;
	padding-right:1px;
	padding-left:1px;
	mso-ignore:padding;
	color:windowtext;
	font-size:11.0pt;
	font-weight:700;
	font-style:normal;
	text-decoration:none;
	font-family:"Courier New", monospace;
	mso-font-charset:0;
	mso-number-format:General;
	text-align:left;
	vertical-align:bottom;
	mso-background-source:auto;
	mso-pattern:auto;
	white-space:nowrap;}
.xl9229088
	{padding-top:1px;
	padding-right:1px;
	padding-left:1px;
	mso-ignore:padding;
	color:windowtext;
	font-size:11.0pt;
	font-weight:400;
	font-style:normal;
	text-decoration:none;
	font-family:Garamond, serif;
	mso-font-charset:0;
	mso-number-format:General;
	text-align:general;
	vertical-align:bottom;
	border-top:none;
	border-right:none;
	border-bottom:1.0pt solid windowtext;
	border-left:none;
	mso-background-source:auto;
	mso-pattern:auto;
	white-space:nowrap;}
.xl9329088
	{padding-top:1px;
	padding-right:1px;
	padding-left:1px;
	mso-ignore:padding;
	color:windowtext;
	font-size:11.0pt;
	font-weight:400;
	font-style:normal;
	text-decoration:none;
	font-family:Arial, sans-serif;
	mso-font-charset:0;
	mso-number-format:General;
	text-align:general;
	vertical-align:middle;
	border-top:none;
	border-right:none;
	border-bottom:1.0pt solid windowtext;
	border-left:none;
	mso-background-source:auto;
	mso-pattern:auto;
	white-space:nowrap;}
.xl9429088
	{padding-top:1px;
	padding-right:1px;
	padding-left:1px;
	mso-ignore:padding;
	color:windowtext;
	font-size:11.0pt;
	font-weight:400;
	font-style:normal;
	text-decoration:none;
	font-family:Arial, sans-serif;
	mso-font-charset:0;
	mso-number-format:General;
	text-align:general;
	vertical-align:bottom;
	border-top:none;
	border-right:none;
	border-bottom:1.0pt solid windowtext;
	border-left:none;
	mso-background-source:auto;
	mso-pattern:auto;
	white-space:nowrap;}
-->
</style>
</head>

<body>
<!--[if !excel]>&nbsp;&nbsp;<![endif]-->
<!--The following information was generated by Microsoft Excel's Publish as Web
Page wizard.-->
<!--If the same item is republished from Excel, all information between the DIV
tags will be replaced.-->
<!----------------------------->
<!--START OF OUTPUT FROM EXCEL PUBLISH AS WEB PAGE WIZARD -->
<!----------------------------->

<div id="" align=center
x:publishsource="Excel" style="margin-left:300px">

<table border=0 cellpadding=0 cellspacing=0 width=1084 style='border-collapse:
 collapse;table-layout:fixed;width:815pt'>
 <col width=93 style='mso-width-source:userset;mso-width-alt:3401;width:70pt'>
 <col width=7 style='mso-width-source:userset;mso-width-alt:256;width:5pt'>
 <col width=10 style='mso-width-source:userset;mso-width-alt:365;width:8pt'>
 <col width=147 style='mso-width-source:userset;mso-width-alt:5376;width:110pt'>
 <col width=58 style='mso-width-source:userset;mso-width-alt:2121;width:44pt'>
 <col width=77 style='mso-width-source:userset;mso-width-alt:2816;width:58pt'>
 <col width=106 style='mso-width-source:userset;mso-width-alt:3876;width:80pt'>
 <col width=138 style='mso-width-source:userset;mso-width-alt:5046;width:104pt'>
 <col width=64 span=7 style='width:48pt'>
 <tr height=17 style='height:12.75pt'>
  <td height=17 class=xl1529088 style='height:12.75pt'></td>
  <td class=xl1529088></td>
  <td class=xl1529088></td>
  <td class=xl1529088></td>
  <td class=xl1529088></td>
  <td class=xl1529088></td>
  <td class=xl1529088></td>
  <td class=xl1529088></td>
  <td class=xl1529088></td>
  <td class=xl1529088></td>
  <td class=xl1529088></td>
  <td class=xl1529088></td>
  <td class=xl1529088></td>
  <td class=xl1529088></td>
  <td class=xl1529088></td>
 </tr>
 <tr height=21 style='height:15.75pt'>
  <td height=21 class=xl6629088 style='height:15.75pt'>Name</td>
  <td class=xl6629088 colspan=2>:</td>
  <td class=xl6729088><?php echo $model->namatamu ?></td>
  <td class=xl6629088></td>
  <td class=xl6629088></td>
  <td class=xl6629088>Account no</td>
  <td class=xl7229088><?php echo $model->no_bon ?></td>
  <td class=xl1529088></td>
  <td class=xl1529088></td>
  <td class=xl1529088></td>
  <td class=xl1529088></td>
  <td class=xl1529088></td>
  <td class=xl1529088></td>
  <td class=xl1529088></td>
 </tr>
 <tr height=21 style='height:15.75pt'>
  <td height=21 class=xl6629088 style='height:15.75pt'>Alamat</td>
  <td class=xl6629088 colspan=2>:</td>
  <td class=xl6729088 rowspan='2' colspan='2' style='overflow: auto; white-space: normal; word-wrap: break-word;'><?php echo $model->alamat ?></td>
  <td class=xl6729088></td>
  <td class=xl6629088>Check In</td>
  <td class=xl8529088><?php echo $model->cekin ?></td>
  <td class=xl1529088></td>
  <td class=xl1529088></td>
  <td class=xl1529088></td>
  <td class=xl1529088></td>
  <td class=xl1529088></td>
  <td class=xl1529088></td>
  <td class=xl1529088></td>
 </tr>
 <tr height=21 style='height:15.75pt'>
  <td height=21 class=xl6629088 style='height:15.75pt'></td>
  <td class=xl6629088></td>
  
  <td class=xl6629088></td>
  <td class=xl6629088></td>
  <td class=xl6629088>Check Out</td>
  <td class=xl8529088><?php echo $model->cekout ?></td>
  <td class=xl1529088></td>
  <td class=xl1529088></td>
  <td class=xl1529088></td>
  <td class=xl1529088></td>
  <td class=xl1529088></td>
  <td class=xl1529088></td>
  <td class=xl1529088></td>
 </tr>
 <tr height=21 style='height:15.75pt'>
  <td height=21 class=xl6629088 style='height:15.75pt'></td>
  <td class=xl6629088></td>
  <td class=xl6729088></td>
  <td class=xl8629088></td>
  <td class=xl6629088></td>
  <td class=xl6629088></td>
  <td class=xl6629088>Room No</td>
  <td class=xl8929088><?php echo $model->namakamar ." (".$model->tipekamar.")"?></td>
  <td class=xl1529088></td>
  <td class=xl1529088></td>
  <td class=xl1529088></td>
  <td class=xl1529088></td>
  <td class=xl1529088></td>
  <td class=xl1529088></td>
  <td class=xl1529088></td>
 </tr>
 <tr height=20 style='height:15.0pt'>
  <td height=20 class=xl6629088 style='height:15.0pt'></td>
  <td class=xl6629088></td>
  <td class=xl6629088></td>
  <td class=xl6629088></td>
  <td class=xl6629088></td>
  <td class=xl6629088></td>
  <td class=xl1529088></td>
  <td class=xl1529088></td>
  <td class=xl1529088></td>
  <td class=xl1529088></td>
  <td class=xl1529088></td>
  <td class=xl1529088></td>
  <td class=xl1529088></td>
  <td class=xl1529088></td>
  <td class=xl1529088></td>
 </tr>
 <tr height=22 style='height:16.5pt'>
  <td height=22 class=xl6629088 style='height:16.5pt'>Group</td>
  <td class=xl6629088 colspan=2>:</td>
  <td colspan=3 class=xl9129088><?php echo $model->costumer ?></td>
  <td class=xl6629088></td>
  <td class=xl6829088></td>
  <td class=xl1529088></td>
  <td class=xl1529088></td>
  <td class=xl1529088></td>
  <td class=xl1529088></td>
  <td class=xl1529088></td>
  <td class=xl1529088></td>
  <td class=xl1529088></td>
 </tr>
 <tr height=21 style='height:15.75pt'>
  <td height=21 class=xl6629088 style='height:15.75pt'></td>
  <td class=xl6629088></td>
  <td class=xl6629088></td>
  <td class=xl6629088></td>
  <td class=xl6929088>&nbsp;</td>
  <td class=xl7029088></td>
  <td class=xl6629088></td>
  <td class=xl6829088></td>
  <td class=xl1529088></td>
  <td class=xl1529088></td>
  <td class=xl1529088></td>
  <td class=xl1529088></td>
  <td class=xl1529088></td>
  <td class=xl1529088></td>
  <td class=xl1529088></td>
 </tr>
 <tr height=20 style='height:15.0pt'>
  <td height=20 class=xl7129088 style='height:15.0pt'>Date</td>
  <td class=xl7129088>&nbsp;</td>
  <td class=xl7129088><span style='mso-spacerun:yes'>
  </span>Voucher</td>
  <td class=xl7129088>&nbsp;</td>
  <td class=xl7129088 style='border-top:none'>&nbsp;</td>
  <td class=xl7129088>&nbsp;</td>
  <td class=xl7129088>Particular</td>
  <td class=xl7129088>Amount</td>
  <td class=xl1529088></td>
  <td class=xl1529088></td>
  <td class=xl1529088></td>
  <td class=xl1529088></td>
  <td class=xl1529088></td>
  <td class=xl1529088></td>
  <td class=xl1529088></td>
 </tr>
 <tr height=20 style='height:15.0pt'>
  <td height=20 class=xl7029088 style='height:15.0pt'></td>
  <td class=xl7029088></td>
  <td class=xl7029088></td>
  <td class=xl7029088></td>
  <td class=xl7029088></td>
  <td class=xl7029088></td>
  <td class=xl7029088></td>
  <td class=xl7029088></td>
  <td class=xl1529088></td>
  <td class=xl1529088></td>
  <td class=xl1529088></td>
  <td class=xl1529088 colspan=2><span
  style='mso-spacerun:yes'>
  <td class=xl1529088></td>
  <td class=xl1529088></td>
 </tr>
<?php
////ini perulangan bon
?>

 <tr height=21 style='height:15.75pt'>
  <td height=21 class=xl7729088 style='height:15.75pt'><?php echo date('d-M-Y',strtotime($model->tiba)) ?></td>
  <td class=xl7029088></td>
  <td class=xl7229088></td>
  <td class=xl8329088>Harga Room </td>
  <td class=xl9029088><?php echo $model->malam ?> Night</td>
  <td class=xl7429088>RP.</td>
  <td class=xl7329088 align=right><?php echo $model->hargatot ?></td>
  <td class=xl7329088 align=right><?php echo $model->totald ?></td>
  <td class=xl1529088></td>
  <td class=xl1529088></td>
  <td class=xl1529088></td>
  <td class=xl1529088></td>
  <td class=xl1529088></td>
  <td class=xl1529088></td>
  <td class=xl1529088></td>
 </tr>

<?php
	$detail=Nobonya::find()->where(['no_bon'=>$model->id])->All();
	$total=0;
	$tambahan=0;
	foreach ($detail as $key) {
		$sub=$key->grandtotal;
		$tambahan+=$sub;
		$total=$total+$sub;
	?>

<tr height=21 style='height:15.75pt'>
  <td height=21 class=xl7729088 style='height:15.75pt'><?php echo date('d-M-Y',strtotime($key->tgl)) ?></td>
  <td class=xl7029088></td>
  <td class=xl7229088></td>
  <td class=xl8329088><?php echo $key->jenis?> </td>
  <td class=xl9029088></td>
  <td class=xl7429088>RP.</td>
  <td class=xl7329088 align=right><?php echo $key->grand ?></td>
  <td class=xl7329088 align=right><?php echo $key->grand ?></td>
  <td class=xl1529088></td>
  <td class=xl1529088></td>
  <td class=xl1529088></td>
  <td class=xl1529088></td>
  <td class=xl1529088></td>
  <td class=xl1529088></td>
  <td class=xl1529088></td>
 </tr>

	<?php
	}
	$rom=$model->total;
 ?>
 <?php
	$detail=Outlet::find()->where(['id_folio'=>$model->id])->All();
	$outleta=0;
	foreach ($detail as $key) {
		$sub=$key['total'];
		$outleta+=$sub;
		$total=$total+$sub;
	?>

<tr height=21 style='height:15.75pt'>
  <td height=21 class=xl7729088 style='height:15.75pt'><?php echo date('d-M-Y',strtotime($key->tgl)) ?></td>
  <td class=xl7029088></td>
  <td class=xl7229088></td>
  <td class=xl8329088><?php echo $key['outlet']?> </td>
  <td class=xl9029088></td>
  <td class=xl7429088>RP.</td>
  <td class=xl7329088 align=right><?php echo $key['total'] ?></td>
  <td class=xl7329088 align=right><?php echo $key['total'] ?></td>
  <td class=xl1529088></td>
  <td class=xl1529088></td>
  <td class=xl1529088></td>
  <td class=xl1529088></td>
  <td class=xl1529088></td>
  <td class=xl1529088></td>
  <td class=xl1529088></td>
 </tr>
	<?php
	}
	$total=$total+$rom;
 ?>


 <tr height=21 style='height:15.75pt'>
  <td height=21 class=xl7729088 style='height:15.75pt'></td>
  <td class=xl7029088></td>
  <td class=xl7229088></td>
  <td class=xl7329088>TOTAL</td>
  <td class=xl7329088></td>
  <td class=xl7429088>RP.</td>
  <td class=xl7329088></td>
  <td class=xl7329088 align=right><?php echo number_format($total) ?></td>
  <td class=xl1529088></td>
  <td class=xl1529088></td>
  <td class=xl1529088></td>
  <td class=xl1529088></td>
  <td class=xl1529088></td>
  <td class=xl1529088></td>
  <td class=xl1529088></td>
 </tr>
 <?php
	
$kurang=0;
if($model->penerimaan<>""){
 $kurang=$total-$model->deposit;
 $bayar=$model->deposit;
 $kalimat=$model->penerimaan;
 $hasil_posisi=strpos("sss ".$kalimat,"Folio Master");
 if($hasil_posisi==true){
 	$bayar=$kurang-$outleta-$tambahan;
	$kurang=$outleta+$tambahan;
 }
 if($bayar==0){
	$bayar=$model->deposit;
 }
 ?>


 <tr height=21 style='height:15.75pt'>
  <td height=21 class=xl7729088 style='height:15.75pt'></td>
  <td class=xl7029088></td>
  <td class=xl7229088></td>
  <td class=xl7329088><?php echo $model->penerimaan?></td>
  <td class=xl7329088></td>
  <td class=xl7429088>RP.</td>
  <td class=xl7329088 align=right><?php  echo number_format($bayar); ?></td>
  <td class=xl7329088 align=right><?php echo number_format($kurang)?></td>
  <td class=xl1529088></td>
  <td class=xl1529088></td>
  <td class=xl1529088></td>
  <td class=xl1529088></td>
  <td class=xl1529088></td>
  <td class=xl1529088></td>
  <td class=xl1529088></td>
 </tr>

<?php
$total=$kurang;
	if($model->penerimaan2<>""){
 	$kurang=$total-$model->deposit2;
	?>
	
<tr height=21 style='height:15.75pt'>
  <td height=21 class=xl7729088 style='height:15.75pt'><?php echo date('d-M-Y',strtotime($model->tgl_deposit2)) ?></td>
  <td class=xl7029088></td>
  <td class=xl7229088></td>
  <td class=xl7329088><?php echo $model->penerimaan2?></td>
  <td class=xl7329088></td>
  <td class=xl7429088>RP.</td>
  <td class=xl7329088 align=right><?php echo number_format($model->deposit2)?></td>
  <td class=xl7329088 align=right><?php echo number_format($kurang)?></td>
  <td class=xl1529088></td>
  <td class=xl1529088></td>
  <td class=xl1529088></td>
  <td class=xl1529088></td>
  <td class=xl1529088></td>
  <td class=xl1529088></td>
  <td class=xl1529088></td>
 </tr>

	<?php }


} else {
	$detail=Bayarbon::find()->where(['id_bon'=>$model->id])->All();
	foreach ($detail as $key) {
	$kurang=$total-$key['jumlah'];
	?>
<tr height=21 style='height:15.75pt'>
  <td height=21 class=xl7729088 style='height:15.75pt'></td>
  <td class=xl7029088></td>
  <td class=xl7229088></td>
  <td class=xl7329088><?php echo $key->penerimaan?></td>
  <td class=xl7329088></td>
  <td class=xl7429088>RP.</td>
  <td class=xl7329088 align=right><?php echo number_format($key['jumlah'])?></td>
  <td class=xl7329088 align=right><?php echo number_format($kurang)?></td>
  <td class=xl1529088></td>
  <td class=xl1529088></td>
  <td class=xl1529088></td>
  <td class=xl1529088></td>
  <td class=xl1529088></td>
  <td class=xl1529088></td>
  <td class=xl1529088></td>
 </tr>
	<?php
	$total=$kurang;
	}

}
	$detail=Nobonya::find()->where(['no_bon'=>$model->id])->All();
	$total=$kurang;
	foreach ($detail as $key) {
		$kurang=$total-$key->grandtotal;
	?>

<tr height=21 style='height:15.75pt'>
  <td height=21 class=xl7729088 style='height:15.75pt'></td>
  <td class=xl7029088></td>
  <td class=xl7229088></td>
  <td class=xl7329088><?php echo $key->penerimaan?></td>
  <td class=xl7329088></td>
  <td class=xl7429088>RP.</td>
  <td class=xl7329088 align=right><?php echo number_format($key->grandtotal)?></td>
  <td class=xl7329088 align=right><?php echo number_format($kurang)?></td>
  <td class=xl1529088></td>
  <td class=xl1529088></td>
  <td class=xl1529088></td>
  <td class=xl1529088></td>
  <td class=xl1529088></td>
  <td class=xl1529088></td>
  <td class=xl1529088></td>
 </tr>

	<?php
		$total=$kurang;
	}
 ?>
 <?php
	$detail=Outlet::find()->where(['id_folio'=>$model->id])->All();
	$total=$kurang;
	foreach ($detail as $key) {
		$sub=$key['total'];
		$kurang1=$total-$sub;
	?>

<tr height=21 style='height:15.75pt'>
  <td height=21 class=xl7729088 style='height:15.75pt'></td>
  <td class=xl7029088></td>
  <td class=xl7229088></td>
  <td class=xl7329088><?php echo $key->penerimaan?></td>
  <td class=xl7329088></td>
  <td class=xl7429088>RP.</td>
  <td class=xl7329088 align=right><?php echo number_format($sub)?></td>
  <td class=xl7329088 align=right><?php echo number_format($kurang1)?></td>
  <td class=xl1529088></td>
  <td class=xl1529088></td>
  <td class=xl1529088></td>
  <td class=xl1529088></td>
  <td class=xl1529088></td>
  <td class=xl1529088></td>
  <td class=xl1529088></td>
 </tr>
	<?php
		$total=$kurang1;
	}
 ?>


 <tr height=21 style='height:15.75pt'>
  <td height=21 class=xl8029088 style='height:15.75pt'></td>
  <td class=xl7829088></td>
  <td class=xl7929088></td>
  <td class=xl7329088></td>
  <td class=xl7329088></td>
  <td class=xl7429088></td>
  <td class=xl7329088></td>
  <td class=xl7429088></td>
  <td class=xl1529088></td>
  <td class=xl1529088></td>
  <td class=xl1529088></td>
  <td class=xl1529088></td>
  <td class=xl1529088></td>
  <td class=xl1529088></td>
  <td class=xl1529088></td>
 </tr>
 <tr height=21 style='height:15.75pt'>
  <td height=21 class=xl8029088 style='height:15.75pt'></td>
  <td class=xl7829088></td>
  <td class=xl7929088></td>
  <td class=xl7329088></td>
  <td class=xl7329088></td>
  <td class=xl7429088></td>
  <td class=xl7329088></td>
  <td class=xl8829088></td>
  <td class=xl1529088></td>
  <td class=xl1529088></td>
  <td class=xl1529088></td>
  <td class=xl1529088></td>
  <td class=xl1529088></td>
  <td class=xl1529088></td>
  <td class=xl1529088></td>
 </tr>
 <tr height=21 style='height:15.75pt'>
  <td height=21 class=xl8029088 style='height:15.75pt'></td>
  <td class=xl7829088></td>
  <td class=xl7929088></td>
  <?php $jam = date ("H:i:s"); ?>
  <td colspan=4 class=xl7229088>Time Closed By <?php echo $model->add_who;?> . . . . . . .<?php echo $jam?></td>
  <td class=xl7329088></td>
  <td class=xl1529088></td>
  <td class=xl1529088></td>
  <td class=xl1529088></td>
  <td class=xl1529088></td>
  <td class=xl1529088></td>
  <td class=xl1529088></td>
  <td class=xl1529088></td>
 </tr>
 
 <tr height=20 style='height:15.0pt'>
  <td height=20 class=xl8029088 style='height:15.0pt'></td>
  <td class=xl7829088></td>
  <td class=xl7929088></td>
  <td class=xl1529088></td>
  <td class=xl1529088></td>
  <td class=xl1529088></td>
  <td class=xl1529088></td>
  <td class=xl1529088></td>
  <td class=xl1529088></td>
  <td class=xl1529088></td>
  <td class=xl1529088></td>
  <td class=xl1529088></td>
  <td class=xl1529088></td>
  <td class=xl1529088></td>
  <td class=xl1529088></td>
 </tr>
 <tr height=21 style='height:15.75pt'>
  <td height=21 class=xl9229088 style='height:15.75pt'>&nbsp;</td>
  <td class=xl9329088>&nbsp;</td>
  <td class=xl9429088>&nbsp;</td>
  <td class=xl8429088>&nbsp;</td>
  <td class=xl8429088>&nbsp;</td>
  <td class=xl8429088>&nbsp;</td>
  <td class=xl8429088>&nbsp;</td>
  <td class=xl8429088>&nbsp;</td>
  <td class=xl1529088></td>
  <td class=xl1529088></td>
  <td class=xl1529088></td>
  <td class=xl1529088></td>
  <td class=xl1529088></td>
  <td class=xl1529088></td>
  <td class=xl1529088></td>
 </tr>
 <tr height=21 style='height:15.75pt'>
  <td height=21 class=xl1529088 style='height:15.75pt'></td>
  <td class=xl1529088></td>
  <td class=xl1529088></td>
  <td class=xl1529088></td>
  <td class=xl1529088></td>
  <td class=xl7529088 colspan=3>I agree that I am responsible for the full</td>
  <td class=xl1529088></td>
  <td class=xl1529088></td>
  <td class=xl1529088></td>
  <td class=xl1529088></td>
  <td class=xl1529088></td>
  <td class=xl1529088></td>
  <td class=xl1529088></td>
 </tr>
 <tr height=20 style='height:15.0pt'>
  <td height=20 class=xl1529088 style='height:15.0pt'></td>
  <td class=xl1529088></td>
  <td class=xl1529088></td>
  <td class=xl1529088></td>
  <td class=xl1529088></td>
  <td class=xl6529088></td>
  <td class=xl7629088></td>
  <td class=xl1529088></td>
  <td class=xl1529088></td>
  <td class=xl1529088></td>
  <td class=xl1529088></td>
  <td class=xl1529088></td>
  <td class=xl1529088></td>
  <td class=xl1529088></td>
  <td class=xl1529088></td>
 </tr>
 <tr height=20 style='height:15.0pt'>
  <td height=20 class=xl1529088 style='height:15.0pt'></td>
  <td class=xl1529088></td>
  <td class=xl1529088></td>
  <td class=xl1529088></td>
  <td class=xl1529088></td>
  <td class=xl7529088></td>
  <td class=xl7629088></td>
  <td class=xl1529088></td>
  <td class=xl1529088></td>
  <td class=xl1529088></td>
  <td class=xl1529088></td>
  <td class=xl1529088></td>
  <td class=xl1529088></td>
  <td class=xl1529088></td>
  <td class=xl1529088></td>
 </tr>
 <tr height=17 style='height:12.75pt'>
  <td height=17 class=xl1529088 style='height:12.75pt'></td>
  <td class=xl1529088></td>
  <td class=xl1529088></td>
  <td class=xl1529088></td>
  <td class=xl1529088></td>
  <td class=xl1529088></td>
  <td class=xl1529088></td>
  <td class=xl1529088></td>
  <td class=xl1529088></td>
  <td class=xl1529088></td>
  <td class=xl1529088></td>
  <td class=xl1529088></td>
  <td class=xl1529088></td>
  <td class=xl1529088></td>
  <td class=xl1529088></td>
 </tr>
 <tr height=17 style='height:12.75pt'>
  <td height=17 class=xl1529088 style='height:12.75pt'></td>
  <td class=xl1529088></td>
  <td class=xl1529088></td>
  <td class=xl1529088></td>
  <td class=xl1529088></td>
  <td class=xl1529088></td>
  <td class=xl1529088></td>
  <td class=xl1529088></td>
  <td class=xl1529088></td>
  <td class=xl1529088></td>
  <td class=xl1529088></td>
  <td class=xl1529088></td>
  <td class=xl1529088></td>
  <td class=xl1529088></td>
  <td class=xl1529088></td>
 </tr>
 <tr height=17 style='height:12.75pt'>
  <td height=17 class=xl1529088 style='height:12.75pt'></td>
  <td class=xl1529088></td>
  <td class=xl1529088></td>
  <td class=xl1529088></td>
  <td class=xl1529088></td>
  <td class=xl1529088></td>
  <td class=xl1529088></td>
  <td class=xl1529088></td>
  <td class=xl1529088></td>
  <td class=xl1529088></td>
  <td class=xl1529088></td>
  <td class=xl1529088></td>
  <td class=xl1529088></td>
  <td class=xl1529088></td>
  <td class=xl1529088></td>
 </tr>
 <tr height=17 style='height:12.75pt'>
  <td height=17 class=xl1529088 style='height:12.75pt'></td>
  <td class=xl1529088></td>
  <td class=xl1529088></td>
  <td class=xl1529088></td>
  <td class=xl1529088></td>
  <td class=xl1529088></td>
  <td class=xl1529088></td>
  <td class=xl1529088></td>
  <td class=xl1529088></td>
  <td class=xl1529088></td>
  <td class=xl1529088></td>
  <td class=xl1529088></td>
  <td class=xl1529088></td>
  <td class=xl1529088></td>
  <td class=xl1529088></td>
 </tr>
 <tr height=20 style='height:15.0pt'>
  <td height=20 class=xl1529088 style='height:15.0pt'></td>
  <td class=xl1529088></td>
  <td class=xl1529088></td>
  <td class=xl1529088></td>
  <td class=xl1529088></td>
  <td class=xl8129088 colspan=2>GUEST SIGNATURE</td>
  <td class=xl1529088></td>
  <td class=xl1529088></td>
  <td class=xl1529088></td>
  <td class=xl1529088></td>
  <td class=xl1529088></td>
  <td class=xl1529088></td>
  <td class=xl1529088></td>
  <td class=xl1529088></td>
 </tr>
 <tr height=17 style='height:12.75pt'>
  <td height=17 class=xl1529088 style='height:12.75pt'></td>
  <td class=xl1529088></td>
  <td class=xl1529088></td>
  <td class=xl1529088></td>
  <td class=xl1529088></td>
  <td class=xl1529088></td>
  <td class=xl1529088></td>
  <td class=xl1529088></td>
  <td class=xl1529088></td>
  <td class=xl1529088></td>
  <td class=xl1529088></td>
  <td class=xl1529088></td>
  <td class=xl1529088></td>
  <td class=xl1529088></td>
  <td class=xl1529088></td>
 </tr>
 <tr height=17 style='height:12.75pt'>
  <td height=17 class=xl1529088 style='height:12.75pt'></td>
  <td class=xl1529088></td>
  <td class=xl1529088></td>
  <td class=xl1529088></td>
  <td class=xl1529088></td>
  <td class=xl1529088></td>
  <td class=xl1529088></td>
  <td class=xl1529088></td>
  <td class=xl1529088></td>
  <td class=xl1529088></td>
  <td class=xl1529088></td>
  <td class=xl1529088></td>
  <td class=xl1529088></td>
  <td class=xl1529088></td>
  <td class=xl1529088></td>
 </tr>
 <![if supportMisalignedColumns]>
 <tr height=0 style='display:none'>
  <td width=93 style='width:70pt'></td>
  <td width=7 style='width:5pt'></td>
  <td width=10 style='width:8pt'></td>
  <td width=147 style='width:110pt'></td>
  <td width=58 style='width:44pt'></td>
  <td width=77 style='width:58pt'></td>
  <td width=106 style='width:80pt'></td>
  <td width=138 style='width:104pt'></td>
  <td width=64 style='width:48pt'></td>
  <td width=64 style='width:48pt'></td>
  <td width=64 style='width:48pt'></td>
  <td width=64 style='width:48pt'></td>
  <td width=64 style='width:48pt'></td>
  <td width=64 style='width:48pt'></td>
  <td width=64 style='width:48pt'></td>
 </tr>
 <![endif]>
</table>

</div>


<!----------------------------->
<!--END OF OUTPUT FROM EXCEL PUBLISH AS WEB PAGE WIZARD-->
<!----------------------------->
</body>

</html>
