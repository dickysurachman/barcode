<?php

use yii\helpers\Html;
use yii\grid\GridView;
use yii\helpers\ArrayHelper;
use app\models\Tipekamar;
/* @var $this yii\web\View */
/* @var $searchModel app\models\NobonSearch */
/* @var $dataProvider yii\data\ActiveDataProvider */

$this->title = 'Menambahkan Charge';
$this->params['breadcrumbs'][] = $this->title;



?>
<div class="nobon-index">

    <h1><?= Html::encode($this->title) ?></h1>
    <?php // echo $this->render('_search', ['model' => $searchModel]); ?>

    <p>
             <?= Html::a('List Data Additional Charge', ['tambahan/index'], ['class' => 'btn btn-success']) ?>
    </p>
    <div class="table-responsive">
    <?= GridView::widget([
        'dataProvider' => $dataProvider,
        'filterModel' => $searchModel,
        'columns' => [
            ['class' => 'yii\grid\SerialColumn'],

           // 'id',
            'no_bon',
            [
            'attribute'=>'id_guest',
            'value'=>'namatamu',
            ],
            //'id_guest',
            'tiba',
            'cout',
            [
            'attribute'=>'id_kamar',
            'filter'=>ArrayHelper::map(Tipekamar::find()->where(['id_perusahaan'=>Yii::$app->user->identity->id_perusahaan])->all(), 'id', 'nama_kamar'),
            'value'=>'namakamar',
            ],
            //'namakamar',
            'malam',
            'hargatot',
            //'total',
            [
            'attribute'=>'total',
            'value'=>'totald'
            ],
        [
                //'class' => 'yii\grid\ActionColumn',
                'header'=>'Charge',
                'attribute' => 'img',
                'format' => 'raw',
                'label' => 'Status',
                'value'=>function ($data) {
                                return Html::a('<span class="glyphicon glyphicon-plus" style="font-size:14pt;" title="Print"></span>',['tambahan/createnih', 'id' => $data->id]);
                                },
            ],
            //['class' => 'yii\grid\ActionColumn'],
        ],
    ]); ?>
</div>
</div>