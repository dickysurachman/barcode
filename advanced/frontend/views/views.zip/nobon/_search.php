<?php

use yii\helpers\Html;
use yii\widgets\ActiveForm;

/* @var $this yii\web\View */
/* @var $model app\models\NobonSearch */
/* @var $form yii\widgets\ActiveForm */
?>

<div class="nobon-search">

    <?php $form = ActiveForm::begin([
        'action' => ['index'],
        'method' => 'get',
    ]); ?>

    <?= $form->field($model, 'id') ?>

    <?= $form->field($model, 'no_bon') ?>

    <?= $form->field($model, 'id_guest') ?>

    <?= $form->field($model, 'tiba') ?>

    <?= $form->field($model, 'cout') ?>

    <?php // echo $form->field($model, 'id_pegawai') ?>

    <?php // echo $form->field($model, 'pajak') ?>

    <?php // echo $form->field($model, 'status') ?>

    <?php // echo $form->field($model, 'diskon') ?>

    <?php // echo $form->field($model, 'total') ?>

    <?php // echo $form->field($model, 'nobukti') ?>

    <?php // echo $form->field($model, 'deposit') ?>

    <?php // echo $form->field($model, 'keterangan') ?>

    <?php // echo $form->field($model, 'id_market') ?>

    <?php // echo $form->field($model, 'id_rate') ?>

    <?php // echo $form->field($model, 'id_company') ?>

    <?php // echo $form->field($model, 'id_kamar') ?>

    <?php // echo $form->field($model, 'id_terima') ?>

    <?php // echo $form->field($model, 'harga') ?>

    <?php // echo $form->field($model, 'breakfast') ?>

    <?php // echo $form->field($model, 'service') ?>

    <?php // echo $form->field($model, 'add_who') ?>

    <?php // echo $form->field($model, 'add_date') ?>

    <?php // echo $form->field($model, 'edit_who') ?>

    <?php // echo $form->field($model, 'edit_date') ?>

    <div class="form-group">
        <?= Html::submitButton('Search', ['class' => 'btn btn-primary']) ?>
        <?= Html::resetButton('Reset', ['class' => 'btn btn-default']) ?>
    </div>

    <?php ActiveForm::end(); ?>

</div>
