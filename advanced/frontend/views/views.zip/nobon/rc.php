<?php 

use yii\helpers\Html;
use yii\widgets\DetailView;
use app\models\Perusahaan;
use app\models\Guest;

$haha=Perusahaan::findOne(1);
?>
<style type="text/css">
    #body1{
        zoom:0.9;
        -moz-transform:scale(0.9);
        -webkit-transform:scale(0.9);
    }


</style>

<div id="body1">
<div align="center">
<img   style="height:100px;"  src="<?php echo Yii::$app->homeUrl ?>/images/<?php echo $haha->logo_1 ?>">
<h3>Registration Card</h3>
</div>
<?php



?>
<div class="col-xs-7 col-md-8">
<?= DetailView::widget([
        'model' => $model,
        'attributes' => [
            'no_bon',
            'namatamu',
            'cekin',
            'cekout',
            'malam',
            'namakamar',
            'tipekamar',
            'hargatot',
            'totald',
            /*'id',
            'no_bon',
            'id_guest',
            'tiba',
            'cout',
            'id_pegawai',
            'pajak',
            'status',
            'diskon',
            'total',
            'nobukti',
            'deposit',
            'keterangan',
            'id_market',
            'id_rate',
            'id_company',
            'id_kamar',
            'id_terima',
            'harga',
            'breakfast',
            'service',
            'add_who',
            'add_date',
            'edit_who',
            'edit_date',*/
        ],
    ]) ?>

<?php
$tamu=Guest::findOne($model->id_guest);

?>
</div>
<div class="col-xs-5 col-md-4">
<table id="w0" class="table table-striped table-bordered detail-view">
<tbody><tr><th>Address: <?php echo $tamu->alamat ?></th></tr>
<tbody><tr><th>City:  <?php echo $tamu->tempat ?></th></tr>
<tbody><tr><th>Country: <?php echo $tamu->kebangsaan ?></th></tr>
<tr><th>ID No : <?php echo $tamu->no_identitas ?> </th></tr>
<tr><th>Telp No : <?php echo $tamu->kontak ?></th></tr>
<tr><th>Type of Payment:</th></tr>
<tr><th>Credit Card No. : </th></tr>
<tr><th>Card Holder Name : </th></tr>
<tr><th>Notes : </th></tr>


</tbody></table>
</div>

<div class="col-sm-offset-4 col-sm-4">signature : </div><div class="col-sm-4">Date:</div>

<p>Notes :</p> 
<p>Check-in time start from 14:00 PM and Check-out time is 12:00 PM </p>
<p>Late Check-out is chargeable </p>
<p>Hotel is not responsibble for valuable guest belonging in guest room </p>
<p><b>Smoking is not allows in non-smoking room, and will be charged Rp 500,000,- for penalty</b></p> 
<p>Room key and Deposit Voucher must be presented in Front office upon Check-out </p>
<p><b>Lost Room Key will be Charged Rp 50,000</b></p>
</div>
 <script type="text/javascript">
        
        window.print();
    </script>