<?php

use yii\helpers\Html;
use yii\widgets\ActiveForm;
use kartik\money\MaskMoney;
use kartik\select2\Select2;
$url = \yii\helpers\Url::to(['reservasi/guest']);
use yii\web\JsExpression;
//use app\models\Guest;
use yii\jui\DatePicker;
use yii\web\View;
use app\models\Guest;
use app\models\Market;
use app\models\Company;
use app\models\Rate;
use app\models\Penerimaan;
use app\models\Tipekamar;
use yii\helpers\ArrayHelper;
// Get the initial city description
$cityDesc =empty($model->id_guest) ? '' : Guest::findOne($model->id_guest)->nama;
//$cityDesc = "Ketikkan Nama";//empty($model->city) ? '' : City::findOne($model->city)->description;
$script = <<< JS
$("#nobonsearch-tiba").datepicker({
    changeMonth: true, 
    changeYear: true, 
    dateFormat:'yy-mm-dd',
    minDate:'today',
    maxDate:'today',
    onSelect: function( selectedDate ) {
        var dateMin = $("#nobonsearch-tiba").datepicker("getDate");
        var rMin = new Date(dateMin.getFullYear(), dateMin.getMonth(),dateMin.getDate() + 1); 

     $( "#nobonsearch-cout" ).datepicker( "option", "minDate", rMin );
    }
});
$("#nobonsearch-cout").datepicker({
    changeMonth: true, 
    changeYear: true, 
    dateFormat:'yy-mm-dd',
});
 
JS;
$position= View::POS_END;
$this->registerJs($script,$position);

/* @var $this yii\web\View */
/* @var $model app\models\Nobon */
/* @var $form yii\widgets\ActiveForm */
?>

<div class="nobon-form">
    <?= Html::a('List Master Folio', ['/masterbon/index'], ['class' => 'btn btn-primary']) ?><br/>

    <?php $form = ActiveForm::begin(); ?>


    <?php 
    echo $form->field($model, 'id_guest')->widget(Select2::classname(), [
        'initValueText' => $cityDesc, 
        'options' => ['placeholder' => 'Search for Guest ...'],
        'pluginOptions' => [
            'allowClear' => true,
            'minimumInputLength' => 3,
            'language' => [
                'errorLoading' => new JsExpression("function () { return 'Waiting for results...'; }"),
            ],
            'ajax' => [
                'url' => $url,
                'dataType' => 'json',
                'data' => new JsExpression('function(params) { return {q:params.term}; }')
            ],
            'escapeMarkup' => new JsExpression('function (markup) { return markup; }'),
            'templateResult' => new JsExpression('function(id_guest) { return id_guest.text; }'),
            'templateSelection' => new JsExpression('function (id_guest) { return id_guest.text; }'),
        ],
    ]);
    ?>


 <div class="col-md-6" style="padding-left: 0px;"> <label class="control-label" for="semen-tgl"><?php echo "Tanggal Check In" ?> </label>
    <?php
    echo DatePicker::widget([
    'model'  => $model,
    'attribute'=>'tiba',
    'dateFormat' => 'yyyy-MM-dd',
    'options'=>['class'=>'form-control','autocomplete'=>'off','readonly'=>'readonly']
]);?></div>
<div class="col-md-6" style="padding-right: 0px">
   <label class="control-label" for="semen-tgl"><?php echo "Tanggal Check Out" ?> </label>
    <?php
    echo DatePicker::widget([
    'model'  => $model,
    'attribute'=>'cout',
    'dateFormat' => 'yyyy-MM-dd',
    'options'=>['class'=>'form-control','autocomplete'=>'off','readonly'=>'readonly']
]);?></div>
   
    <div class="col-md-6" style="padding-left: 0px;">
    <?php
    echo $form->field($model, 'id_market')->widget(Select2::classname(), [
    'data' => ArrayHelper::map(Market::find()->where(['id_perusahaan'=>Yii::$app->user->identity->id_perusahaan])->all(), 'kode', 'nama'),
    'options' => ['placeholder' => 'Select '],
    'pluginOptions' => [
        'allowClear' => true
    ],
    ]);
    ?></div>
     
    <div class="col-md-6" style="padding-right: 0px;">
         <?php
    echo $form->field($model, 'id_company')->widget(Select2::classname(), [
    'data' => ArrayHelper::map(Company::find()->where(['id_perusahaan'=>Yii::$app->user->identity->id_perusahaan])->all(), 'kode', 'nama'),
    'options' => ['placeholder' => 'Select '],
    'pluginOptions' => [
        'allowClear' => true
    ],
    ]);
    ?>

    </div>

    <div class="col-md-4" style="padding-left: 0px;">
      <?php
        echo $form->field($model, 'id_rate')->widget(Select2::classname(), [
        'data' => ArrayHelper::map(Rate::find()->where(['id_perusahaan'=>Yii::$app->user->identity->id_perusahaan])->all(), 'kode', 'nama'),
        'options' => ['placeholder' => 'Select '],
        'pluginOptions' => [
            'allowClear' => true
        ],
        ]);
    ?>
    </div>
    <div class="col-md-2">
         <?= $form->field($model, 'diskon')->textInput() ?>

    </div>
    <div class="col-md-6" style="padding-right: 0px;">
        
      <?php
        echo $form->field($model, 'id_kamar')->widget(Select2::classname(), [
        'data' => ArrayHelper::map(Tipekamar::find()->where(['status'=>'VC','id_perusahaan'=>Yii::$app->user->identity->id_perusahaan])->all(), 'id', 'nama_kamar'),
        'options' => ['placeholder' => 'Select '],
        'pluginOptions' => [
            'allowClear' => true
        ],
        ]);
    ?>


    </div>

    <?= $form->field($model, 'keterangan')->textInput(['maxlength' => true]) ?>
    
   
    <div class="form-group">
        <?= Html::submitButton('Input to Master', ['class' => $model->isNewRecord ? 'btn btn-success' : 'btn btn-primary']) ?>
    </div>

    <?php ActiveForm::end(); ?>

</div>
