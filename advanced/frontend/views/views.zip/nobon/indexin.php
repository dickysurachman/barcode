<?php

use yii\helpers\Html;
use yii\grid\GridView;
use yii\helpers\ArrayHelper;
use app\models\Tipekamar;
//use yii\grid\GridView;
//use kartik\grid\GridView;
//use kartik\GridView;
use kartik\export\ExportMenu;
use kartik\select2\Select2;
use app\models\Guest;
use yii\web\View;
use yii\widgets\Pjax;
/* @var $this yii\web\View */
/* @var $searchModel app\models\NobonSearch */
/* @var $dataProvider yii\data\ActiveDataProvider */
use yii\web\JsExpression;
use yii\bootstrap\Modal;
$url = \yii\helpers\Url::to(['reservasi/guest']);
$this->title = 'Guest In House & Count Sheet';
$this->params['breadcrumbs'][] = $this->title;
//$cityDesc=empty($searchModel->id_guest) ? '' : Guest::findOne($searchModel->id_guest)->nama;

if(isset($searchModel->id_guest)){
    $tamu=Guest::findOne($searchModel->id_guest);
    if(isset($tamu)) {

    $cityDesc=$tamu->nama;
    } else {
    $cityDesc="";
        
    }
}else {
    $cityDesc="";

}

$amount = 0;
$amountrns = 0;
$sisaon =0;
$amount = Yii::$app->db->createCommand("select sum(diskon)  from no_bon where status=0 ")->queryScalar();
$amountrns = Yii::$app->db->createCommand("select sum(total)  from no_bon where status=0 ")->queryScalar();
$sisaon = Yii::$app->db->createCommand("select sum(total)-sum(deposit)-sum(deposit2)  from no_bon where status=0 ")->queryScalar();

    //if (!isset($dataProvider->getModels())) {
/*    if (isset($dataProvider)) {
        foreach ($dataProvider->getModels() as $key => $val) {
            $amount += $val->diskon;
            $amountrns += $val->total;
            $sisaon += $val->sisa;
            //$amountrns += $val->rns;
        }
    }
*/
/*
$script = <<< JS
    $(function() {
        $('#popp').click(function () {
            $('#modal1').modal('show')
        });
    });
JS;

    $this->registerJs($script);*/

?>
<div class="nobon-index">

    <h1><?= Html::encode($this->title) ?></h1>
    <?php // echo $this->render('_search', ['model' => $searchModel]); ?>

    <p>

<?php 
$gridColumns = [
    ['class' => 'yii\grid\SerialColumn'],
            'namatamu',
     'namakamar',
     'tipekamar',
     'no_bon',
            'tiba',
            'cout',       
            'malam',
            'diskon',
            'harga',
            'breakfast',
            'aditional',
            'totalall',
            'deposit',
            'sisa',
//            'market',
//            'costumer',
];

// Renders a export dropdown menu
echo ExportMenu::widget([
    'dataProvider' => $dataProvider,
    'columns' => $gridColumns
]);
?>
        <?php //= Html::a('Create Check In', ['create'], ['class' => 'btn btn-success']) ?>

    </p>
    <div class="table-responsive">
    <?= GridView::widget([
        'dataProvider' => $dataProvider,
        'filterModel' => $searchModel,
        'showFooter'=>TRUE,
        'columns' => [
            ['class' => 'yii\grid\SerialColumn'],

           // 'id',
        [
             'attribute'=>'id_guest',
             'value'=>'namatamu',
             'filter'=> Select2::widget([
                            'name' => 'NobonSearch[id_guest]',
                            'theme' => Select2::THEME_BOOTSTRAP,
                            'value' => $cityDesc,//$nomeescola,
                            //'hideSearch' => true,
                            'options' => [
                                'initValueText' => $cityDesc, 
                                'placeholder' => 'Search',
                            ],
                            'pluginOptions' => [
                                'allowClear' => true,
                                'minimumInputLength' => 3,
                            'ajax' => [
                                'url' => $url,
                                'dataType' => 'json',
                                'data' => new JsExpression('function(params) { return {q:params.term}; }')
                            ],
                            'escapeMarkup' => new JsExpression('function (markup) { return markup; }'),
                            'templateResult' => new JsExpression('function(id_guest) { return id_guest.text; }'),
                            'templateSelection' => new JsExpression('function (id_guest) { return id_guest.text; }'),
                            ],
                        ]),
            ],
                        [
            'attribute'=>'id_kamar',
            'filter'=>ArrayHelper::map(Tipekamar::find()->where(['id_perusahaan'=>Yii::$app->user->identity->id_perusahaan])->all(), 'id', 'nama_kamar'),
            'value'=>'namakamar',
            ],
            'tipekamar',
            'no_bon',

            'tiba',
            'cout',
            //'namakamar',
            'malam',
            [
            'attribute'=>'diskon',
            'footer'=>number_format($amount),
            ],
            //'diskon',
            //[
            //'attribute'=>'harga:number',
            //'value'=>number_format($data->harga),
            //],
            //[
            //'attribute'=>'breakfast:number',
//            'format'=>'number'
            //],

            'harga:integer',
            'breakfast:integer',
            'aditional',
            //'tota',
            //'total',
            [
            'attribute'=>'total',
            'value'=>'totalall',
            'footer'=>number_format($amountrns)
            ],
            'deposit',
            //'sisa',
            [
            'attribute'=>'sisa',
            'value'=>'sisa',
            'footer'=>number_format($sisaon)
            ],
            //'market',
            //'costumer',

        ],
    ]); ?>
    </div>

        <h3>Compliment</h3>
    <div class="table-responsive">
    <?php 
$gridColumns2 = [
    ['class' => 'yii\grid\SerialColumn'],
            'namatamu',
            'cekin',
            'cekout',
            'namakamar',
            'tipekamar',
            'jenis',
            'malam',
            'keterangan:ntext',
];

// Renders a export dropdown menu
echo ExportMenu::widget([
    'dataProvider' => $dataProvider2,
    'columns' => $gridColumns2
]);
?>

        <?= GridView::widget([
        'dataProvider' => $dataProvider2,
        'filterModel' => $searchModel2,
        'columns' => [
            ['class' => 'yii\grid\SerialColumn'],

            //'id',
            'namatamu',
            'cekin',
            'cekout',
            [
            'attribute'=>'id_kamar',
            'filter'=>ArrayHelper::map(Tipekamar::find()->where(['id_perusahaan'=>Yii::$app->user->identity->id_perusahaan])->all(), 'id', 'nama_kamar'),
            'value'=>'namakamar',
            ],            
            'tipekamar',
            'jenis',
            'malam',
            'keterangan:ntext',

        ],
    ]); ?>
    </div>

</div>
