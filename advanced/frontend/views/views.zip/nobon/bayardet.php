<?php
use yii\helpers\Html;
use yii\widgets\ActiveForm;
use yii\jui\DatePicker;
use yii\web\View;
use app\models\Penerimaan;
use kartik\money\MaskMoney;
use yii\helpers\ArrayHelper;
use kartik\select2\Select2;
use yii\widgets\DetailView;
/* @var $this yii\web\View */
/* @var $model app\models\Bayarbon */
/* @var $form yii\widgets\ActiveForm */


?>

<div class="bayarbon-form">

    <?php $form = ActiveForm::begin(); ?>

    <?= DetailView::widget([
        'model' => $data,
        'attributes' => [
            'no_bon',
            'namatamu',
            'tiba',
            'cout',
            'malam',
            'namakamar',
            'tipekamar',
            'total',
            'deposit',
            'sisa',
            //'hargatot',
            //'totald',
        ],
    ]) ?>

    <?= $form->field($model, 'kode_bayar')->textInput(['readonly'=>'readonly']) ?>
    <?= $form->field($model, 'tanggal')->hiddenInput(['readonly'=>'readonly'])->label(false) ?>    
    <?php
        echo $form->field($model, 'id_terima')->widget(Select2::classname(), [
        'data' => ArrayHelper::map(Penerimaan::find()->where(['status'=>0,'id_perusahaan'=>Yii::$app->user->identity->id_perusahaan])->all(), 'id', 'jenis'),
        'options' => ['placeholder' => 'Select '],
        'pluginOptions' => [
            'allowClear' => true
        ],
        ]);
    ?>
    <?php
    echo $form->field($model, 'jumlah')->widget(MaskMoney::classname());
    ?>
    

  
	<?php if (!Yii::$app->request->isAjax){ ?>
	  	<div class="form-group">
	        <?= Html::submitButton($model->isNewRecord ? 'Create' : 'Update', ['class' => $model->isNewRecord ? 'btn btn-success' : 'btn btn-primary']) ?>
	    </div>
	<?php } ?>

    <?php ActiveForm::end(); ?>
    
</div>
