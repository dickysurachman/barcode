<?php

use yii\helpers\Html;

/* @var $this yii\web\View */
/* @var $model app\models\Tipekamar */
?>
<div class="tipekamar-update">

    <?= $this->render('_form1', [
        'model' => $model,
    ]) ?>

</div>
