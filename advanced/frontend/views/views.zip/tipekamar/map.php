<?php
//use yii\helpers\Url;
use yii\helpers\Html;
use yii\web\View;
//use yii\bootstrap\Modal;
//use kartik\grid\GridView;
//use johnitvn\ajaxcrud\CrudAsset; 
//use johnitvn\ajaxcrud\BulkButtonWidget;

/* @var $this yii\web\View */
/* @var $searchModel app\models\TipekamarSearch */
/* @var $dataProvider yii\data\ActiveDataProvider */

$this->title = 'Map Kamar';
$this->params['breadcrumbs'][] = $this->title;

//CrudAsset::register($this);
?>
<style type="text/css">
    .container{
        min-height: 1200px !important;
    }


</style>

<div class="tipekamar-index">
<?php 
$tip="";
$baris=1;
foreach ($dataProvider as $key) {
    if($tip<>$key['id_jenis']){
        $tip=$key['id_jenis'];
        echo "<div class=\"row\"></div>";
        //echo "<br/><p>&nbsp;</p>";
        $baris=0;
    }    

    if($baris==6){
        //echo "<br/><p>&nbsp;</p>";
        //echo "<div class=\"row\"></div>";
        $baris=0;
    }

    echo "<div class=\"col-md-2\" style=\"border:1px solid black !important;text-align: center; padding: 5px\">
        <h2>".$key['nama_kamar']."</h2>";
        echo $key->nama."<br>";
            if($key['status']=="VC"){
                echo Html::a('Available', ['nobon/createmap','id'=>$key['id']],['class'=>'btn btn-success']);
                //echo "<a href=\"index.php?r=nobon/createmap&id=".$key['id']."\" class=\"btn btn-success\">Available</a>";
            }else{
                echo "<a href=\"#\" class=\"btn btn-danger\">Not Available</a>";
            }
    echo "</div>";
    $baris++;
}

?>

</div>
<div class="row"></div>
