<?php
use yii\helpers\Html;
use yii\widgets\ActiveForm;
use app\models\Kamar;
use yii\web\View;
use kartik\select2\Select2;
use yii\helpers\ArrayHelper;
/* @var $this yii\web\View */
/* @var $model app\models\Tipekamar */
/* @var $form yii\widgets\ActiveForm */
$tipe=[
'VC'=>"Vacant Clean",
'OC'=>"Occupied Clean",
'OD'=>"Occupied Dirty",
'VD'=>"Vacant Dirty",
'UC'=>"Underconstruction",
'OO'=>"Out of Order",
];

?>

<div class="tipekamar-form">

    <?php $form = ActiveForm::begin(); ?>

    <?= $form->field($model, 'nama_kamar')->textInput(['maxlength' => true]) ?>

    
 	<?php
    echo $form->field($model, 'id_jenis')->widget(Select2::classname(), [
    'data' => ArrayHelper::map(Kamar::find()->where(['id_perusahaan'=>Yii::$app->user->identity->id_perusahaan])->all(), 'id', 'tipe_kamar'),
    'options' => ['placeholder' => 'Select item '],
    'pluginOptions' => [
        'allowClear' => true
    ],
    ]);
    ?>
  
	<?= $form->field($model, 'status')->dropDownList($tipe,array('prompt'=>'Please Choose')) ?>

  
	<?php if (!Yii::$app->request->isAjax){ ?>
	  	<div class="form-group">
	        <?= Html::submitButton($model->isNewRecord ? 'Create' : 'Update', ['class' => $model->isNewRecord ? 'btn btn-success' : 'btn btn-primary']) ?>
	    </div>
	<?php } ?>

    <?php ActiveForm::end(); ?>
    
</div>
