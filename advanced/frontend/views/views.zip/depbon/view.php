<?php

use yii\widgets\DetailView;

/* @var $this yii\web\View */
/* @var $model app\models\Depositbon */
?>
<div class="depositbon-view">
 
    <?= DetailView::widget([
        'model' => $model,
        'attributes' => [
            'id',
            'tanggal',
            'id_deposit',
            'nm_tabel',
            'id_bon',
            'jumlah',
            'add_who',
            'add_date',
            'edit_who',
            'edit_date',
        ],
    ]) ?>

</div>
