<?php

use yii\helpers\Html;


/* @var $this yii\web\View */
/* @var $model app\models\Depositbon */

?>
<div class="depositbon-create">
    <?= $this->render('_form', [
        'model' => $model,
    ]) ?>
</div>
