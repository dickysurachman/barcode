<?php

use yii\helpers\Html;
use yii\widgets\ActiveForm;
use app\models\Penerimaan;
use yii\helpers\ArrayHelper;
use kartik\select2\Select2;
/* @var $this yii\web\View */
/* @var $model app\models\Outlet */
/* @var $form yii\widgets\ActiveForm */
use yii\widgets\DetailView;
use app\models\Outletdetp;
?>

<div class="outlet-form">
<?php 
$detail=Outletdetp::find()->where(['id_bon'=>$model->id])->All();
?>
<table id="w0" class="table table-striped table-bordered detail-view">
<tbody>
<tr>
<th>Nama Item</th>
<th>Harga</th>
<th>Qty</th>
<th>Total</th>
</tr>
<?php
foreach ($detail as $key) {
?>
<tr>
<td><?php echo $key->barang ?></td>
<td><?php echo $key->hrg_satuan ?></td>
<td><?php echo $key->jumlah ?></td>
<td><?php echo $key->grandtotal ?></td>
</tr>
<?php }
?>
</tbody>
</table>

<?= DetailView::widget([
        'model' => $model,
        'attributes' => [
            'grandtotal',
        ],
    ]) ?>
    <?php $form = ActiveForm::begin(); ?>

    
    <?= $form->field($model, 'uraian')->textInput(['maxlength' => true]) ?>
     <?php
        echo $form->field($model, 'id_terima')->widget(Select2::classname(), [
        'data' => ArrayHelper::map(Penerimaan::find()->where(['id_perusahaan'=>Yii::$app->user->identity->id_perusahaan,'status'=>0])->all(), 'id', 'jenis'),

        'options' => ['placeholder' => 'Select ',
        ],
        'pluginOptions' => [
            'allowClear' => true
        ],
        ]);
    ?>
  
    <div class="form-group">
        <?= Html::submitButton($model->isNewRecord ? 'Create' : 'Update', ['class' => $model->isNewRecord ? 'btn btn-success' : 'btn btn-primary']) ?>
    </div>

    <?php ActiveForm::end(); ?>

</div>
