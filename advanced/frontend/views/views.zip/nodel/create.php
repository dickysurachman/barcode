<?php

use yii\helpers\Html;


/* @var $this yii\web\View */
/* @var $model app\models\Nobondel */

?>
<div class="nobondel-create">
    <?= $this->render('_form', [
        'model' => $model,
    ]) ?>
</div>
