<?php

use yii\widgets\DetailView;

/* @var $this yii\web\View */
/* @var $model app\models\Nobondel */
?>
<div class="nobondel-view">
 
    <?= DetailView::widget([
        'model' => $model,
        'attributes' => [
            'id',
            'no_bon',
            'id_guest',
            'tiba',
            'cout',
            'id_pegawai',
            'pajak',
            'status',
            'diskon',
            'total',
            'nobukti',
            'deposit',
            'keterangan',
            'id_market',
            'id_rate',
            'id_company',
            'id_kamar',
            'id_terima',
            'harga',
            'breakfast',
            'service',
            'add_who',
            'add_date',
            'edit_who',
            'edit_date',
            'id_terima2',
            'deposit2',
            'tgl_deposit2',
            'id_master',
        ],
    ]) ?>

</div>
