<?php
use yii\helpers\Html;
use yii\widgets\ActiveForm;

/* @var $this yii\web\View */
/* @var $model app\models\Nobondel */
/* @var $form yii\widgets\ActiveForm */
?>

<div class="nobondel-form">

    <?php $form = ActiveForm::begin(); ?>

    <?= $form->field($model, 'no_bon')->textInput(['maxlength' => true]) ?>

    <?= $form->field($model, 'id_guest')->textInput() ?>

    <?= $form->field($model, 'tiba')->textInput() ?>

    <?= $form->field($model, 'cout')->textInput() ?>

    <?= $form->field($model, 'id_pegawai')->textInput() ?>

    <?= $form->field($model, 'pajak')->textInput() ?>

    <?= $form->field($model, 'status')->textInput() ?>

    <?= $form->field($model, 'diskon')->textInput() ?>

    <?= $form->field($model, 'total')->textInput() ?>

    <?= $form->field($model, 'nobukti')->textInput(['maxlength' => true]) ?>

    <?= $form->field($model, 'deposit')->textInput() ?>

    <?= $form->field($model, 'keterangan')->textInput(['maxlength' => true]) ?>

    <?= $form->field($model, 'id_market')->textInput(['maxlength' => true]) ?>

    <?= $form->field($model, 'id_rate')->textInput(['maxlength' => true]) ?>

    <?= $form->field($model, 'id_company')->textInput(['maxlength' => true]) ?>

    <?= $form->field($model, 'id_kamar')->textInput() ?>

    <?= $form->field($model, 'id_terima')->textInput() ?>

    <?= $form->field($model, 'harga')->textInput() ?>

    <?= $form->field($model, 'breakfast')->textInput() ?>

    <?= $form->field($model, 'service')->textInput() ?>

    <?= $form->field($model, 'add_who')->textInput(['maxlength' => true]) ?>

    <?= $form->field($model, 'add_date')->textInput() ?>

    <?= $form->field($model, 'edit_who')->textInput(['maxlength' => true]) ?>

    <?= $form->field($model, 'edit_date')->textInput() ?>

    <?= $form->field($model, 'id_terima2')->textInput() ?>

    <?= $form->field($model, 'deposit2')->textInput() ?>

    <?= $form->field($model, 'tgl_deposit2')->textInput() ?>

    <?= $form->field($model, 'id_master')->textInput() ?>

  
	<?php if (!Yii::$app->request->isAjax){ ?>
	  	<div class="form-group">
	        <?= Html::submitButton($model->isNewRecord ? 'Create' : 'Update', ['class' => $model->isNewRecord ? 'btn btn-success' : 'btn btn-primary']) ?>
	    </div>
	<?php } ?>

    <?php ActiveForm::end(); ?>
    
</div>
