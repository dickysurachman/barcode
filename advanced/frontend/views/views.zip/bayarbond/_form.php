<?php
use yii\helpers\Html;
use yii\widgets\ActiveForm;

/* @var $this yii\web\View */
/* @var $model app\models\Bayarbond */
/* @var $form yii\widgets\ActiveForm */
?>

<div class="bayarbond-form">

    <?php $form = ActiveForm::begin(); ?>

    <?= $form->field($model, 'kode_bayar')->textInput(['maxlength' => true]) ?>

    <?= $form->field($model, 'tanggal')->textInput() ?>

    <?= $form->field($model, 'id_bon')->textInput() ?>

    <?= $form->field($model, 'id_bond')->textInput() ?>

    <?= $form->field($model, 'id_terima')->textInput() ?>

    <?= $form->field($model, 'jumlah')->textInput() ?>

    <?= $form->field($model, 'status')->textInput() ?>

    <?= $form->field($model, 'add_who')->textInput(['maxlength' => true]) ?>

    <?= $form->field($model, 'add_date')->textInput() ?>

    <?= $form->field($model, 'edit_who')->textInput(['maxlength' => true]) ?>

    <?= $form->field($model, 'edit_date')->textInput() ?>

  
	<?php if (!Yii::$app->request->isAjax){ ?>
	  	<div class="form-group">
	        <?= Html::submitButton($model->isNewRecord ? 'Create' : 'Update', ['class' => $model->isNewRecord ? 'btn btn-success' : 'btn btn-primary']) ?>
	    </div>
	<?php } ?>

    <?php ActiveForm::end(); ?>
    
</div>
