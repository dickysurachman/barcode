<?php

use yii\helpers\Html;


/* @var $this yii\web\View */
/* @var $model app\models\Bayarbond */

?>
<div class="bayarbond-create">
    <?= $this->render('_form', [
        'model' => $model,
    ]) ?>
</div>
