<?php

use yii\helpers\Html;
use yii\grid\GridView;
use app\models\Charge;
use yii\helpers\ArrayHelper;
/* @var $this yii\web\View */
/* @var $searchModel app\models\NobonyaSearch */
/* @var $dataProvider yii\data\ActiveDataProvider */

$this->title = 'List Additional Charge';
$this->params['breadcrumbs'][] = $this->title;


?>
<div class="nobonya-index">

    <h1><?= Html::encode($this->title) ?></h1>
    <?php // echo $this->render('_search', ['model' => $searchModel]); ?>

    <p>

    </p>
    <div class="table-responsive">
    <?= GridView::widget([
        'dataProvider' => $dataProvider,
        'filterModel' => $searchModel,
        'columns' => [
            ['class' => 'yii\grid\SerialColumn'],

            [
            'attribute'=>'nobon',
            'value'=>'bon'
            ],'tgl',
            [
            'attribute'=>'id_charge',
            'value'=>'jenis',
            'filter'=>ArrayHelper::map(Charge::find()->where(['id_perusahaan'=>Yii::$app->user->identity->id_perusahaan])->all(), 'id', 'nama_charge'),
            ],
            'uraian',
            'hrg_satuan',
            'jumlah',
            'grand',
            // 'jumlah',
            // 'uraian',
            // 'sub_total',
            // 'add_who',
            // 'add_date',
            // 'edit_who',
            // 'edit_date',

            ['class' => 'yii\grid\ActionColumn',
            'template'=>'{delete}'
            ],
        ],
    ]); ?>
</div>
</div>
