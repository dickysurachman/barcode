<?php

use yii\helpers\Html;
use yii\widgets\DetailView;

/* @var $this yii\web\View */
/* @var $model app\models\Nobonya */

$this->title = $model->id;
$this->params['breadcrumbs'][] = ['label' => 'Nobonyas', 'url' => ['index']];
$this->params['breadcrumbs'][] = $this->title;
?>
<div class="nobonya-view">

    <h1><?= Html::encode($this->title) ?></h1>

    <p>
        <?= Html::a('Update', ['update', 'id' => $model->id], ['class' => 'btn btn-primary']) ?>
        <?= Html::a('Delete', ['delete', 'id' => $model->id], [
            'class' => 'btn btn-danger',
            'data' => [
                'confirm' => 'Are you sure you want to delete this item?',
                'method' => 'post',
            ],
        ]) ?>
    </p>

    <?= DetailView::widget([
        'model' => $model,
        'attributes' => [
            'id',
            'no_bon',
            'tgl',
            'id_charge',
            'hrg_satuan',
            'jumlah',
            'uraian',
            'sub_total',
            'add_who',
            'add_date',
            'edit_who',
            'edit_date',
        ],
    ]) ?>

</div>
