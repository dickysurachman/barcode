<?php

use yii\helpers\Html;
use yii\widgets\ActiveForm;
use app\models\Charge;
use yii\helpers\ArrayHelper;
use yii\web\View;
use app\models\Penerimaan;
use kartik\money\MaskMoney;
use kartik\select2\Select2;
/* @var $this yii\web\View */
/* @var $model app\models\Nobonya */
/* @var $form yii\widgets\ActiveForm */

$countries=Charge::find()->where(['id_perusahaan'=>Yii::$app->user->identity->id_perusahaan])->all();
//use yii\helpers\ArrayHelper;
$dataPost=ArrayHelper::map($countries,'id','nama_charge');
?>

<div class="nobonya-form">

    <?php $form = ActiveForm::begin(); ?>

    <?= $form->field($model, 'id_charge')->dropDownList($dataPost,['prompt'=>'Choose']) ?>
    <div class="col-md-4" style="padding-left: 0px">
    <?php   
        echo $form->field($model, 'hrg_satuan')->widget(MaskMoney::classname());
        
    ?></div>    
    <div class="col-md-4">
    <?= $form->field($model, 'jumlah')->textInput() ?></div>

     <div class="col-md-4" style="padding-left: 0px;">
    <?php
        echo $form->field($model, 'id_terima')->widget(Select2::classname(), [
        'data' => ArrayHelper::map(Penerimaan::find()->all(), 'id', 'jenis'),
        'options' => ['placeholder' => 'Select '],
        'pluginOptions' => [
            'allowClear' => true
        ],
        ]);
    ?>
    </div>
    <?= $form->field($model, 'uraian')->textInput(['maxlength' => true]) ?>
    
   

    <div class="form-group">
        <?= Html::submitButton($model->isNewRecord ? 'Create' : 'Update', ['class' => $model->isNewRecord ? 'btn btn-success' : 'btn btn-primary']) ?>
    </div>

    <?php ActiveForm::end(); ?>

</div>
