<?php

use yii\helpers\Html;


/* @var $this yii\web\View */
/* @var $model app\models\Nobonya */

$this->title = 'Create Nobonya';
$this->params['breadcrumbs'][] = ['label' => 'Nobonyas', 'url' => ['index']];
$this->params['breadcrumbs'][] = $this->title;
?>
<div class="nobonya-create">

    <h1><?= Html::encode($this->title) ?></h1>

    <?= $this->render('_form', [
        'model' => $model,
    ]) ?>

</div>
