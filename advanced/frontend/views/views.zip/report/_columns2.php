<?php
use yii\helpers\Url;

return [
    [
        'class' => 'kartik\grid\CheckboxColumn',
        'width' => '20px',
    ],
    [
        'class' => 'kartik\grid\SerialColumn',
        'width' => '30px',
    ],
        // [
        // 'class'=>'\kartik\grid\DataColumn',
        // 'attribute'=>'id',
    // ],
    [
        'class'=>'\kartik\grid\DataColumn',
        'attribute'=>'nama',
    ],
    [
        'class'=>'\kartik\grid\DataColumn',
        'attribute'=>'tgl',
    ],
    [
        'class'=>'\kartik\grid\DataColumn',
        'attribute'=>'rns',
        'pageSummary' => true
    ],
    [
        'class'=>'\kartik\grid\DataColumn',
        'attribute'=>'revenue',
         'format'=>['decimal',2],
         'hAlign' => 'right',
           'pageSummary' => true
    ],
    [
        'class'=>'\kartik\grid\DataColumn',
        'attribute'=>'status',
    ],
   

];   