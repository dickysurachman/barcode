<?php
use app\models\Nobon;
use app\models\Nobonya;
use yii\helpers\Html;
use yii\widgets\DetailView;
$da=explode("-",$has);
$bln=$da[1];
$thn=$da[0];
$tgl=$da[2];    
/* @var $this yii\web\View */
/* @var $model app\models\Reservasi */

$this->title = "REPORT Cashier ". $tgl."-".$bln."-".$thn;
$this->params['breadcrumbs'][] = ['label' => 'Report', 'url' => ['index']];
$this->params['breadcrumbs'][] = $this->title;
?>
<div class="reservasi-view">

    <h1><?= Html::encode($this->title) ?></h1>
    <div class="table-responsive">
    <table class="table table-striped table-hover">
        <tr>
            <th class="text-left">No.</th>
            <th class="text-left">Outlet</th>
            <th class="text-left">Cashier</th>
            <th class="text-center">Metode Pembayaran</th>
            <th class="text-center">Amount Detail</th>
            <th class="text-center">Amount Summary</th>
        </tr>
    <?php 
    $i=0;
    $where4=" where tgl='".$has."' and add_who='".$nama."' and a.id_perusahaan=".Yii::$app->user->identity->id_perusahaan;
    $where4b=" where tanggal='".$has."' and add_who='".$nama."' and a.id_perusahaan=".Yii::$app->user->identity->id_perusahaan;
    $where4a=" where tiba='".$has."' and add_who='".$nama."' and a.id_perusahaan=".Yii::$app->user->identity->id_perusahaan;
    $deposit= Yii::$app->db->createCommand("SELECT jenis as jenis,SUM(jumlah) AS jumlah,add_who as add_who,id_penerimaan FROM deposit a JOIN jenis_penerimaan b ON a.id_penerimaan=b.id  ". $where4." GROUP BY jenis,add_who,id_penerimaan")->queryAll();

    foreach ($deposit as $keya ) {
    $i++;
    ?>
    <tr>
    <td><?php echo $i ?></td>
    <td>Deposit</td>
    <td><?php echo $keya['add_who'] ?></td>
    <td class="text-center"><?php echo $keya['jenis'] ?></td>
    <td></td>
    <td class="text-right"><?php echo number_format($keya['jumlah']) ?></td>
    </tr>
    <?php 
    $deposit2= Yii::$app->db->createCommand("SELECT no_deposit,jumlah AS jumlah FROM deposit a JOIN jenis_penerimaan b ON a.id_penerimaan=b.id  ". $where4 ."
        and id_penerimaan=".$keya['id_penerimaan'])->queryAll();
    foreach ($deposit2 as $keya2 ) {
    ?>
    <tr>
    <td></td>
    <td><?php echo $keya2['no_deposit'] ?></td>
    <td></td>
    <td class="text-center"></td>
    <td class="text-right"><?php echo number_format($keya2['jumlah']) ?></td>
    <td class="text-right"></td>
    </tr>
    <?php
        }
    }

    $outlet=Yii::$app->db->createCommand("SELECT c.nama as nama,jenis,SUM(total) as jumlah,add_who AS add_who,id_terima FROM no_bon_outlet a JOIN jenis_penerimaan b ON a.id_terima=b.id 
    join profile_daerah c on a.id_profile=c.id
     ". $where4." GROUP BY nama,jenis,add_who")->queryAll();
    foreach ($outlet as $key ) {
    $i++;
    ?>
    <tr>
    <td><?php echo $i ?></td>
    <td><?php echo $key['nama'] ?></td>
    <td><?php echo $key['add_who'] ?></td>
    <td class="text-center"><?php echo $key['jenis'] ?></td>
    <td class="text-right"></td>
    <td class="text-right"><?php echo number_format($key['jumlah']) ?></td>
    </tr>
    <?php

    $outlet2=Yii::$app->db->createCommand("SELECT no_bon,jenis,total as jumlah FROM no_bon_outlet a JOIN jenis_penerimaan b ON a.id_terima=b.id 
    join profile_daerah c on a.id_profile=c.id
     ". $where4." and id_terima=".$key['id_terima'])->queryAll();
    foreach ($outlet2 as $key2 ) {
    //$i++;
    ?>
    <tr>
    <td></td>
    <td><?php echo $key2['no_bon'] ?></td>
    <td></td>
    <td class="text-center"></td>
    <td class="text-right"><?php echo number_format($key2['jumlah']) ?></td>
    <td class="text-right"></td>
    </tr>
    <?php 
        }
    }

    $nobon=Yii::$app->db->createCommand("SELECT jenis as jenis,SUM(deposit) AS jumlah,add_who,id_terima FROM no_bon a JOIN jenis_penerimaan b ON a.id_terima=b.id 
     ". $where4a." GROUP BY jenis,add_who")->queryAll();
    foreach ($nobon as $key ) {
    $i++;
    ?>

    <tr>
    <td><?php echo $i ?></td>
    <td>FO</td>
    <td><?php echo $key['add_who'] ?></td>
    <td class="text-center"><?php echo $key['jenis'] ?></td>
    <td class="text-right"></td>
    <td class="text-right"><?php echo number_format($key['jumlah']) ?></td>
    </tr>
    <?php 
    $nobon2=Yii::$app->db->createCommand("SELECT no_bon,deposit AS jumlah,add_who,a.id as id FROM no_bon a JOIN jenis_penerimaan b ON a.id_terima=b.id 
     ". $where4a." and id_terima=".$key['id_terima'])->queryAll();
    foreach ($nobon2 as $key2 ) {
        $nob=Nobon::findOne($key2['id']);
//    $i++;
    ?>

    <tr>
    <td></td>
    <td><?php echo $key2['no_bon'] ?></td>
    <td>Folio Kamar <?php echo $nob->namakamar ." (".$nob->tipekamar.") an. ".$nob->namatamu; ?></td>
    <td class="text-center"><?php //echo $key['jenis'] ?></td>
    <td class="text-right"><?php echo number_format($key2['jumlah']) ?></td>
    <td class="text-right"></td>
    </tr>
    <?php   
        }
    }

    $where5=" where tgl_deposit2='".$has."' and edit_who='".$nama."' and a.id_perusahaan=".Yii::$app->user->identity->id_perusahaan;
    $nobon=Yii::$app->db->createCommand("SELECT jenis as jenis,SUM(deposit2) AS jumlah,edit_who,id_terima2 FROM no_bon a JOIN jenis_penerimaan b ON a.id_terima2=b.id  ". $where5." GROUP BY jenis,edit_who")->queryAll();
    foreach ($nobon as $key ) {
    $i++;
    ?>
    <tr>
    <td><?php echo $i ?></td>
    <td>FO</td>
    <td><?php echo $key['edit_who'] ?></td>
    <td class="text-center"><?php echo $key['jenis'] ?></td>
    <td class="text-right"></td>
    <td class="text-right"><?php echo number_format($key['jumlah']) ?></td>
    </tr>
    <?php 
    $nobon2=Yii::$app->db->createCommand("SELECT no_bon,deposit2 AS jumlah,edit_who FROM no_bon a JOIN jenis_penerimaan b ON a.id_terima2=b.id  ". $where5." and 
        id_terima2=".$key['id_terima2'])->queryAll();
    foreach ($nobon2 as $key2 ) {
   // $i++;
    ?>
    <tr>
    <td><?php //echo $i ?></td>
    <td><?php echo $key2['no_bon'] ?></td>
    <td>Folio Kamar Extend / Shorten</td>
    <td class="text-center"></td>
    <td class="text-right"><?php echo number_format($key['jumlah']) ?></td>
    <td class="text-right"></td>
    </tr>
    <?php 

        }
    }

    $nobon= Yii::$app->db->createCommand("SELECT jenis,SUM(jumlah) AS jumlah,add_who as add_who,id_terima FROM bayar_bon a left JOIN jenis_penerimaan b ON a.id_terima=b.id   ".
                    $where4b." GROUP BY jenis,add_who")->queryAll();
    foreach ($nobon as $key ) {
    $i++;
    ?>
    <tr>
    <td><?php echo $i ?></td>
    <td>FO</td>
    <td><?php echo $key['add_who'] ?></td>
    <td class="text-center"><?php echo $key['jenis'] ?></td>
    <td class="text-right"></td>
    <td class="text-right"><?php echo number_format($key['jumlah']) ?></td>
    </tr>
    <?php
    $where4b=" where tanggal='".$has."' and a.add_who='".$nama."' and a.id_perusahaan=".Yii::$app->user->identity->id_perusahaan;
    //$where4b2= 
    $nobon2= Yii::$app->db->createCommand("SELECT c.no_bon as no_bon,jumlah AS jumlah,a.add_who as add_who FROM bayar_bon a join no_bon c on a.id_bon=c.id left JOIN jenis_penerimaan b ON a.id_terima=b.id   ".
                    $where4b." and a.id_terima=".$key['id_terima']." ")->queryAll();
    foreach ($nobon2 as $key2){
        $nob=Nobon::findOne(['no_bon'=>$key2['no_bon']]);
    //$i++;
    ?>
    <tr>
    <td><?php //var_dump($key2) ?></td>
    <td><?php echo $key2['no_bon']?></td>
    <td>Folio Kamar <?php echo $nob->namakamar ." (".$nob->tipekamar.") an. ".$nob->namatamu; ?></td>
    <td class="text-center"></td>
    <td class="text-right"><?php echo number_format($key2['jumlah']) ?></td>
    <td class="text-right"></td>
    </tr>
    <?php 
    
        }

    }

    $where6=" where tanggal='".$has."' and a.add_who='".$nama."' and a.id_perusahaan=".Yii::$app->user->identity->id_perusahaan;
    $nobon= Yii::$app->db->createCommand("SELECT jenis,SUM(jumlah) AS jumlah,add_who,id_terima FROM bayar_master a JOIN jenis_penerimaan b ON a.id_terima=b.id   ". $where6." GROUP BY kode_akun,jenis")->queryAll();
    foreach ($nobon as $key ) {
    $i++;
    ?>
    <tr>
    <td><?php echo $i ?></td>
    <td>FO</td>
    <td><?php echo $key['add_who'] ?></td>
    <td class="text-center"><?php echo $key['jenis'] ?></td>
    <td class="text-right"></td>
    <td class="text-right"><?php echo number_format($key['jumlah']) ?></td>
    </tr>
    <?php 
    $where6=" where a.tanggal='".$has."' and a.add_who='".$nama."' and a.id_perusahaan=".Yii::$app->user->identity->id_perusahaan;
    $nobon2= Yii::$app->db->createCommand("SELECT no_inv,a.jumlah AS jumlah,a.add_who FROM bayar_master a join no_bon_master c on a.id_master=c.id JOIN jenis_penerimaan b ON a.id_terima=b.id   ". $where6." and id_terima=".$key['id_terima'])->queryAll();
    foreach ($nobon2 as $key2 ) {
    //$i++;
    ?>
    <tr>
    <td></td>
    <td><?php echo $key2['no_inv'] ?></td>
    <td>FOLIO MASTER</td>
    <td class="text-center"></td>
    <td class="text-right"><?php echo number_format($key2['jumlah']) ?></td>
    <td class="text-right"></td>
    </tr>
    <?php 
        }
    
    }

    $where5x=" where tgl='".$has."' and add_who='".$key['add_who']."' and a.id_perusahaan=".Yii::$app->user->identity->id_perusahaan;
    $nobon=Yii::$app->db->createCommand("SELECT jenis as jenis,SUM(hrg_satuan*jumlah) AS jumlah,add_who FROM no_bon_tambah a JOIN jenis_penerimaan b ON a.id_terima=b.id  ". $where5x." GROUP BY jenis,add_who")->queryAll();
    foreach ($nobon as $key ) {
    $i++;
    ?>
    <tr>
    <td><?php echo $i ?></td>
    <td>FO Charge</td>
    <td><?php echo $key['add_who'] ?></td>
    <td class="text-center"><?php echo $key['jenis'] ?></td><td></td>
    <td class="text-right"><?php echo number_format($key['jumlah']) ?></td>
    </tr>
    <?php 

    $where5xa=" where tgl='".$has."' and a.add_who='".$key['add_who']."' and a.id_perusahaan=".Yii::$app->user->identity->id_perusahaan;
        $nobon=Yii::$app->db->createCommand("SELECT c.no_bon as no_bon, jenis as jenis,hrg_satuan*jumlah AS jumlah,a.add_who,a.id FROM no_bon_tambah a JOIN jenis_penerimaan b ON a.id_terima=b.id join no_bon c on a.no_bon=c.id ". $where5xa." ")->queryAll();
        foreach ($nobon as $key ) {
             $nob=Nobonya::findOne($key['id']);
        //$i++;
        ?>
        <tr>
        <td><?php //echo $i ?></td>
        <td><?php echo $key['no_bon'] ?></td>
        <td> <?php echo $nob->jenis  ?></td>
        <td class="text-center"></td>
        <td class="text-right"><?php echo number_format($key['jumlah']) ?></td>
        <td class="text-right"></td>
        </tr>
        <?php 
        }

    }


     $where5=" where tgl_refund='".$has."' and edit_who='".$nama."' and a.id_perusahaan=".Yii::$app->user->identity->id_perusahaan;
     $nobon= Yii::$app->db->createCommand("SELECT jenis,c.nama,SUM(refund) AS jumlah,edit_who,id_penerimaan2 FROM deposit a JOIN jenis_penerimaan b ON a.id_penerimaan2=b.id join guest c on a.id_guest=c.id  ". $where5." GROUP BY jenis,c.nama,edit_who")->queryAll();
    foreach ($nobon as $key ) {
    $i++;
    ?>
    <tr>
    <td><?php echo $i ?></td>
    <td>FO - Refund Deposit</td>
    <td><?php echo $key['edit_who'] ?></td>
    <td class="text-center"><?php echo $key['jenis'] ?></td>
    <td class="text-right"><?php echo number_format($key['jumlah']) ?></td>
    </tr>
    <?php 
    $nobon2= Yii::$app->db->createCommand("SELECT no_deposit,c.nama,refund AS jumlah,edit_who FROM deposit a JOIN jenis_penerimaan b ON a.id_penerimaan2=b.id join guest c on a.id_guest=c.id  ". $where5." and id_penerimaan2=".$key['id_penerimaan2'])->queryAll();
    foreach ($nobon2 as $key2 ) {
    //$i++;
    ?>
    <tr>
    <td></td>
    <td>FO - Refund Deposit</td>
    <td><?php echo $key2['no_deposit'] ?></td>
    <td class="text-center"></td>
    <td class="text-right"><?php echo number_format($key2['jumlah']) ?></td>
    <td class="text-right"></td>
    </tr>
    <?php 
       }
    }
    ?>

    <?php 
    $where5=" where tanggal='".$has."' and add_who='".$nama."' and a.id_perusahaan=".Yii::$app->user->identity->id_perusahaan;
     $nobon= Yii::$app->db->createCommand("SELECT jenis,SUM(jumlah) AS jumlah,add_who,id_terima FROM bayar_outlet a JOIN jenis_penerimaan b ON a.id_terima=b.id  ". $where5." GROUP BY jenis,add_who")->queryAll();
    foreach ($nobon as $key ) {
    $i++;
    ?>
    <tr>
    <td><?php echo $i ?></td>
    <td>FO - Bayar Outlet</td>
    <td><?php echo $key['add_who'] ?></td>
    <td class="text-center"><?php echo $key['jenis'] ?></td>
    <td></td>
    <td class="text-right"><?php echo number_format($key['jumlah']) ?></td>
    </tr>
    <?php
     //$where5=" where tanggal='".$has."' ";//and edit_who='".$nama."'";
    $nobon2= Yii::$app->db->createCommand("SELECT kode_bayar, jumlah,add_who FROM bayar_outlet a JOIN jenis_penerimaan b ON a.id_terima=b.id ". $where5." and add_who='".$key['add_who']."' and id_terima=".$key['id_terima'])->queryAll();
    foreach ($nobon2 as $key2 ) {
    //$i++;
    ?>
    <tr>
    <td></td>
    <td><?php echo $key2['kode_bayar'] ?></td>
    <td class="text-center"></td>
    <td></td>
    <td class="text-right"><?php echo number_format($key2['jumlah']) ?></td>
    <td class="text-right"></td>
    </tr>
    <?php 
       }
    } ?>
    </table>
    </div>

    <script type="text/javascript">
        
        window.print();
    </script>
</div>
