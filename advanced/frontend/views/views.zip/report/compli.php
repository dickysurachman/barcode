<?php

use yii\helpers\Html;
use yii\grid\GridView;
use kartik\export\ExportMenu;
use yii\helpers\ArrayHelper;
/* @var $this yii\web\View */
/* @var $searchModel app\models\ComplimentSearch */
/* @var $dataProvider yii\data\ActiveDataProvider */
use app\models\Tipekamar;
$this->title = 'Compliments';
$this->params['breadcrumbs'][] = $this->title;
?>
<div class="compliment-index">

    <h1><?= Html::encode($this->title) ?></h1>
    <?php // echo $this->render('_search', ['model' => $searchModel]); ?>

    <p>
 <?php  echo $this->render('_searchd1', ['model' => $searchModel]); ?>
<?php 

$gridColumns = [
    ['class' => 'yii\grid\SerialColumn'],
    
       'namatamu',
            'cekin',
            'cekout',
            'namakamar',
            'jenis',
            'malam',
            'keterangan:ntext',
];

// Renders a export dropdown menu
echo ExportMenu::widget([
    'dataProvider' => $dataProvider,
    'columns' => $gridColumns
]);
?>
        
    </p>
     <div class="table-responsive">
    <?= GridView::widget([
        'dataProvider' => $dataProvider,
        'filterModel' => $searchModel,
        'columns' => [
            ['class' => 'yii\grid\SerialColumn'],

            //'id',
            'namatamu',
            'cekin',
            'cekout',
            [
            'attribute'=>'id_kamar',
            'filter'=>ArrayHelper::map(Tipekamar::find()->where(['id_perusahaan'=>Yii::$app->user->identity->id_perusahaan])->all(), 'id', 'nama_kamar'),
            'value'=>'namakamar',
            ],            
            'tipekamar',
            'jenis',
            'malam',
            'keterangan:ntext',
            //'id_guest',
            // 'id_kamar',
            // 'status',

            //['class' => 'yii\grid\ActionColumn'],
        ],
    ]); ?>
</div>
</div>
