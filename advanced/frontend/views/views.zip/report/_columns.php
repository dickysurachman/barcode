<?php
use yii\helpers\Url;

return [
    [
        'class' => 'kartik\grid\CheckboxColumn',
        'width' => '20px',
    ],
    [
        'class' => 'kartik\grid\SerialColumn',
        'width' => '30px',
    ],
        // [
        // 'class'=>'\kartik\grid\DataColumn',
        // 'attribute'=>'id',
    // ],
    [
        'class'=>'\kartik\grid\DataColumn',
        'attribute'=>'tanggal',
    ],
    [
        'class'=>'\kartik\grid\DataColumn',
        'attribute'=>'akun',
    ],
    [
        'class'=>'\kartik\grid\DataColumn',
        'attribute'=>'uraian',
    ],
    [
        'class'=>'\kartik\grid\DataColumn',
        'attribute'=>'debit',
        'format'=>['decimal',2],
        'hAlign' => 'right',
        'pageSummary' => true
    ],
    [
        'class'=>'\kartik\grid\DataColumn',
        'attribute'=>'kredit',
        'format'=>['decimal',2],
        'hAlign' => 'right',
        'pageSummary' => true
    ],
    // [
        // 'class'=>'\kartik\grid\DataColumn',
        // 'attribute'=>'status',
    // ],
   

];   