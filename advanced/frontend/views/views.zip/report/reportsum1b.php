<?php

use yii\helpers\Html;
use yii\widgets\ActiveForm;
//use app\models\Guest;
use yii\jui\DatePicker;
use yii\web\View;
use yii\helpers\ArrayHelper;
$tipe=['Aktif','Non Aktif'];

$script = <<< JS
$("#report-tgl").datepicker({
    changeMonth: true, 
    changeYear: true, 
    dateFormat:'yy-mm-dd',
}); 
$("#report-tgl_akhir").datepicker({
    changeMonth: true, 
    changeYear: true, 
    dateFormat:'yy-mm-dd',
}); 
JS;
$position= View::POS_END;
$this->registerJs($script,$position);
/* @var $this yii\web\View */
/* @var $model app\models\Nobon */
/* @var $form yii\widgets\ActiveForm */
/*$ha=Yii::$app->db->createCommand("SELECT DATE_FORMAT(cout,'%m-%Y') AS nilai,DATE_FORMAT(cout,'%b-%Y') AS nilaia,YEAR(cout),MONTH(cout) 
FROM no_bon GROUP BY DATE_FORMAT(cout,'%m-%Y') ORDER BY YEAR(cout) DESC,MONTH(cout) DESC LIMIT 12")->queryAll();
*/
//$tipe=ArrayHelper::map($ha, 'nilai', 'nilaia')
//$ha=Yii::$app->db->createCommand("")
?>

<div class="nobon-form">



    <?php $form = ActiveForm::begin(); ?>

 <div class="col-md-6" style="padding-left: 0px;"> <label class="control-label" for="semen-tgl"><?php echo "Mulai" ?> </label>
    <?php
    echo DatePicker::widget([
    'model'  => $model,
    'attribute'=>'tgl',
    'dateFormat' => 'yyyy-MM-dd',
    'options'=>['class'=>'form-control','autocomplete'=>'off','readonly'=>'readonly']
]);?></div>
 <div class="col-md-6" style="padding-left: 0px;"> <label class="control-label" for="semen-tgl"><?php echo "Sampai" ?> </label>
    <?php
    echo DatePicker::widget([
    'model'  => $model,
    'attribute'=>'tgl_akhir',
    'dateFormat' => 'yyyy-MM-dd',
    'options'=>['class'=>'form-control','autocomplete'=>'off','readonly'=>'readonly']
]);?></div>
   <?php //= $form->field($model, 'tgl_akhir')->dropDownList($tipe,['prompt'=>'Pilihan']) ?>
   <?php
        /*echo $form->field($model, 'id_kamar')->widget(Select2::classname(), [
        'data' => ArrayHelper::map(Tipekamar::find()->where(['status'=>'VC'])->all(), 'id', 'nama_kamar'),
        'options' => ['placeholder' => 'Select '],
        'pluginOptions' => [
            'allowClear' => true
        ],
        ]);*/
    
 
    ?>
 

   <br/>
   <br/>
    
   
    <div class="form-group" style="margin-top: 25px; ">
        <?= Html::submitButton('Print',['class' =>'btn btn-primary']) ?>
    </div>

    <?php ActiveForm::end(); ?>

</div>
