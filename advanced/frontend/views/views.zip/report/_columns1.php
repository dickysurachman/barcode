<?php
use yii\helpers\Url;

return [
    [
        'class' => 'kartik\grid\SerialColumn',
        'width' => '30px',
    ],
        // [
        // 'class'=>'\kartik\grid\DataColumn',
        // 'attribute'=>'id',
    // ],
    [
        'class'=>'\kartik\grid\DataColumn',
        'attribute'=>'nama',
    ],
    [
        'class'=>'\kartik\grid\DataColumn',
        'attribute'=>'tgl',
    ],
    [
        'class'=>'\kartik\grid\DataColumn',
        'attribute'=>'actual',
        'format'=>['decimal',2],
        'hAlign' => 'right',
           'pageSummary' => true
    ],
    /*
    [
        'class'=>'\kartik\grid\DataColumn',
        'attribute'=>'budget',
    ],
    [
        'class'=>'\kartik\grid\DataColumn',
        'attribute'=>'status',
    ],
    */

];   