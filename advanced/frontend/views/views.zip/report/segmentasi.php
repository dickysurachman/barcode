<?php
use yii\helpers\Url;
use yii\helpers\Html;
use yii\bootstrap\Modal;
use kartik\grid\GridView;
use johnitvn\ajaxcrud\CrudAsset; 
use johnitvn\ajaxcrud\BulkButtonWidget;
use scotthuangzl\googlechart\GoogleChart;
/* @var $this yii\web\View */
/* @var $searchModel app\models\ReportmarketSearch */
/* @var $dataProvider yii\data\ActiveDataProvider */

$this->title = 'Reportmarkets';
$this->params['breadcrumbs'][] = $this->title;

CrudAsset::register($this);

?>
<?php  echo $this->render('_searchd', ['model' => $searchModel]); ?>
<div class="row">
<?php
if($tgl_a<>""){
?>
    <div class="col-md-12">
    <?php
    $haa=Yii::$app->db->createCommand("Select nama,sum(rns) as rns,sum(revenue) as rev from report_market where tgl between '".$tgl_a. "' and '".$tgl_b. "' and revenue>0 and id_perusahaan=".Yii::$app->user->identity->id_perusahaan. " group by nama")->queryAll();
    $i=0;
    $item[$i][]="Nama";
    $item[$i][]="Jumlah";
    $i=1;
    //$item=["Task","Hours per Day"];
    foreach ($haa as $keya) {
        $item[$i][]=$keya['nama'];
        $item[$i][]=(int)$keya['rev'];
        //$item[]=[$keya['nama'],intval($keya['rev'])];
        $i++;
    }
    echo GoogleChart::widget(array('visualization' => 'PieChart',
                'data' => $item,
                'options' => array('title' => 'Market Segment'))); 

                    
      ?>
      </div>
<?php
}

?>
</div>
<div class="reportmarket-index">
    <div id="ajaxCrudDatatable">
        <?=GridView::widget([
            'id'=>'crud-datatable',
            'dataProvider' => $dataProvider,
            'filterModel' => $searchModel,
            'pjax'=>true,
            'columns' => require(__DIR__.'/_columns2.php'),
            'toolbar'=> [
                ['content'=>
                    Html::a('<i class="glyphicon glyphicon-repeat"></i>', [''],
                    ['data-pjax'=>1, 'class'=>'btn btn-default', 'title'=>'Reset Grid']).
                    '{toggleData}'.
                    '{export}'
                ],
            ],          
            'striped' => true,
            'condensed' => true,
            'responsive' => true,          
            'responsiveWrap' => false,          
            'panel' => [
                'type' => 'primary', 
                'heading' => '<i class="glyphicon glyphicon-list"></i> Reportmarkets listing',
                'before'=>'<em>* Resize table columns just like a spreadsheet by dragging the column edges.</em>',
                'after'=>                        
                        '<div class="clearfix"></div>',
            ],
              'showPageSummary' => true
        ])?>
    </div>
</div>
