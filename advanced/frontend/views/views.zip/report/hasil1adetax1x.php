<?php
use app\models\Nobon;
use yii\helpers\Html;
use yii\widgets\DetailView;
use app\models\Perusahaan;
$haha=Perusahaan::findOne(1);
$pajak=$haha->tax;
$service=$haha->service;
if($pajak==0 && $service==0){
    $pembagi=1;
} else {
    $pembagi=1+($pajak+$service+($service/10))/100;
}
$kpajak=($pajak/100)+($service/1000);
$kservice=$service/100;
$da=explode("-",$has1);
$bln=$da[1];
$thn=$da[0];
$tgl=$da[2];
$tgl_a=$has1;
$tgl_b=$has2;    
/* @var $this yii\web\View */
/* @var $model app\models\Reservasi */

$this->title = "Daily Revenue from ". $has1." until ".$has2;
$this->params['breadcrumbs'][] = ['label' => 'Report', 'url' => ['report']];
$this->params['breadcrumbs'][] = $this->title;
?>
<div class="reservasi-view">

    <h1><?= Html::encode($this->title) ?></h1>
    <div class="table-responsive">
    <table class="table table-striped table-hover">
        <tr>
            <th class="text-left">No.</th>
            <th class="text-left">Tanggal</th>
            <th class="text-center">Room / Other</th>
            <th class="text-center">Food / Beverage</th>
            <th class="text-center">Charge Revenue</th>
            <th class="text-center">Outlet Revenu</th>
            <th class="text-center">Tax</th>
            <th class="text-center">Service</th>
        </tr>
    <?php 

    $jumlahhari=(strtotime($tgl_b)-strtotime($tgl_a))/86400;
    for($ij=0;$ij<=$jumlahhari;$ij++){
    $tgls=date('Y-m-d',strtotime($tgl_a)+(86400*$i));
    $i=0;
    $ro=0;
    $rot=0;
    $tax=0;
    $service=0;
    $taxo=0;
    $taxot=0;
    $sevot=0;
    $sevo=0;
    $where="WHERE tiba='".$tgls."' OR (cout>'".$tgls."' AND tiba<'".$tgls."')";
    $where2="WHERE cekin='".$tgls."' OR (cekout>'".$tgls."' AND cekout<>'".$tgls."')";
    $where3="WHERE tgl='".$tgls."'";
    $rr= Yii::$app->db->createCommand("select sum(harga)  from no_bon ".$where)->queryScalar();
    $rb= Yii::$app->db->createCommand("select sum(breakfast)  from no_bon ".$where)->queryScalar();
    $revr=$rr/$pembagi;
    $taxr=($rr/$pembagi)*$kpajak;
    $sevr=($rr/$pembagi)*$kservice;
    $revb=$rb/$pembagi;
    $taxb=($rb/$pembagi)*$kpajak;
    $sevb=($rb/$pembagi)*$kservice;
    $rev=$revr+$revb;
    $tax=$taxr+$taxb;
    $sev=$sevr+$sevb;
    ?>    
    <tr>
    <td><?php echo $ij ?></td>
    <td><?php echo date(d-M-Y,strtotime($tgls)) ?></td>
    <td>Room Charge</td>
    <td class="text-right"></td>
    <td class="text-right"></td>
    <td class="text-right"><?php echo number_format($revr) ?></td>
    <td class="text-right"><?php echo number_format($taxr) ?></td>
    <td class="text-right"><?php echo number_format($sevr) ?></td>
    </tr>
    <?php 
    }
    ?>

    <tr>
    <td>2</td>
    <td>FB Meal</td>
    <td class="text-right"><?php echo number_format($revb) ?></td>
    <td class="text-right"></td>
    <td class="text-right"></td>
    <td class="text-right"><?php echo number_format($taxb) ?></td>
    <td class="text-right"><?php echo number_format($sevb) ?></td>
    </tr>


    <?php
    $i=3;
    $other= Yii::$app->db->createCommand("SELECT b.nama_charge as nama,SUM(hrg_satuan*jumlah) as rev FROM no_bon_tambah a JOIN charge b ON a.id_charge=b.id "
            .$where3 ." GROUP BY nama_charge")->queryAll();

           $taxo=0;
           $sevo=0;
           $ro=0;
           foreach ($other as $keyx) {
            $reven=$keyx['rev']/$pembagi;
            $taxa=($keyx['rev']/$pembagi)*$kpajak;
            $seva=($keyx['rev']/$pembagi)*$kpajak;
            $ro+=$reven;
            $taxo+=$taxa;
            $sevo+=$seva;
            ?>

            <tr>
            <td><?php echo $i; ?></td>
            <td><?php echo $keyx['nama'];?></td>
            <td class="text-right"></td>
            <td class="text-right"></td>
            <td class="text-right"><?php echo number_format($reven) ?></td>
            <td class="text-right"><?php echo number_format($taxa) ?></td>
            <td class="text-right"><?php echo number_format($seva) ?></td>
            </tr>

            <?php
            $i++;
            }
           $tax=$tax+$taxo;;
           $sev=$sev+$sevo;
           $rev+=$ro;
           $outlet=Yii::$app->db->createCommand("
            SELECT b.nama,b.fax,SUM(total) as rev FROM no_bon_outlet a JOIN profile_daerah b ON a.id_profile=b.id ".
            $where3 ." GROUP BY nama,fax")->queryAll();
           $taxo=0;
           $sevo=0;
           $ro=0;
           foreach ($outlet as $keyx) {
            $reven=$keyx['rev']/$pembagi;
            $taxa=($keyx['rev']/$pembagi)*$kpajak;
            $seva=($keyx['rev']/$pembagi)*$kservice;
            $ro+=$reven;
            $taxo+=$taxa;
            $sevo+=$seva;
            
            if($keyx['fax']<>""){

            ?>

            <tr>
            <td><?php echo $i; ?></td>
            <td><?php echo $keyx['nama'];?></td>
            <td class="text-right"><?php echo number_format($reven) ?></td>
            <td class="text-right"></td>
            <td class="text-right"></td>
            <td class="text-right"><?php echo number_format($taxa) ?></td>
            <td class="text-right"><?php echo number_format($seva) ?></td>
            </tr>

            <?php
                        } else {
                            ?>
            <tr>
            <td><?php echo $i; ?></td>
            <td><?php echo $keyx['nama'];?></td>
            <td class="text-right"></td>
            <td class="text-right"></td>
            <td class="text-right"><?php echo number_format($reven) ?></td>
            <td class="text-right"><?php echo number_format($taxa) ?></td>
            <td class="text-right"><?php echo number_format($seva) ?></td>
            </tr>

                            <?php
                        }

            $i++;
            }
           $tax=$tax+$taxo;;
           $sev=$sev+$sevo;
           $rev+=$ro;
           ?>

            <tr>
            <td></td>
            <td>Total</td>
            <td class="text-right"></td>
            <td class="text-right"></td>
            <td class="text-right"><?php echo number_format($rev) ?></td>
            <td class="text-right"><?php echo number_format($tax) ?></td>
            <td class="text-right"><?php echo number_format($sev) ?></td>
            </tr>

            <?php 
            $rns = Yii::$app->db->createCommand("select count(id)  from no_bon ".$where)->queryScalar();
            //$roms=Yii::$app->db->createCommand()
            

            ?>

            <tr>
            <td></td>
            <td>Room Sold</td>
            <td class="text-right"><?php echo $rns; ?> rooms</td>
            <td class="text-right"></td>
            <td class="text-right"></td>
            <td class="text-right"></td>
            <td class="text-right"></td>
            </tr>
            <tr>
            <td></td>
            <td>ARR</td>
            <td class="text-right"><?php 
            if($rns==0) 
            { $rns1=1; } else {

              $rns1=$rns;  
            } 

            echo number_format($rev/$rns1); ?></td>
            <td class="text-right"></td>
            <td class="text-right"></td>
            <td class="text-right"></td>
            <td class="text-right"></td>
            </tr>
            <tr>
            <td></td>
            <td>ROOMSOCCUPIED</td>
            <td class="text-right"><?php echo (($rns/16) * 100); ?> %</td>
            <td class="text-right"></td>
            <td class="text-right"></td>
            <td class="text-right"></td>
            <td class="text-right"></td>
            </tr>


    </table>
    </div>

    <script type="text/javascript">
        
        window.print();
    </script>
</div>
