<?php

use yii\helpers\Html;
use yii\widgets\DetailView;
use app\models\Perusahaan;
$haha=Perusahaan::findOne(Yii::$app->user->identity->id_perusahaan);
        $pajak=$haha->tax;
        $service=$haha->service;
        if($pajak==0 && $service==0){
            $pembagi=1;
        } else {
            $pembagi=1+($pajak+$service+($service/10))/100;
        }
        $kpajak=($pajak/100)+($service/1000);
        $kservice=$service/100;
$da=explode("-",$has);
$bln=$da[0];
$thn=$da[1];    
/* @var $this yii\web\View */
/* @var $model app\models\Reservasi */

$this->title = "REPORT SUMARY ".$bln."-".$thn;
$this->params['breadcrumbs'][] = ['label' => 'Report', 'url' => ['index']];
$this->params['breadcrumbs'][] = $this->title;
?>
<div class="reservasi-view">

    <h1><?= Html::encode($this->title) ?></h1>
    <div class="table-responsive">
    <table class="table table-striped table-hover">
        <tr>
            <th class="text-left">No.</th>
            <th class="text-left">Nama Item</th>
            <th class="text-center">YTD</th>
            <th class="text-center">MTD</th>
            <th class="text-center">Last Night</th>
        </tr>
    <?php 
    $i=0;
    $haa=Yii::$app->db->createCommand("Select nama,sum(actual) as rns,avg(actual) as rev, max(status) as status from night_cdr where month(tgl)<=".$bln." and year(tgl)=".$thn. " and id_perusahaan=".Yii::$app->user->identity->id_perusahaan." group by nama order by status ")->queryAll();
    $revenuey=0;
    $rsoldy=0;
    $ravay=0;
   
    foreach ($haa as $keya) {
    $i++;
    $namanya=$keya['nama'];

    if($namanya<>"ROOMSOCCUPIED"){

    //}
    
    if($namanya=="FB REVENUE") {
        $haha="Breakfast";
    } else {
        $haha=$namanya;
    }
    ?>
    <tr>
    <td><?php echo $i ?></td>
    <td><?php echo $haha//$keya['nama'] ?></td>
    <?php
     if($namanya=="TOTALROOMREVENUE"){
        $revenuey=$keya['rns'];
    }
    if($namanya=="ROOMSSOLD"){
        $rsoldy=$keya['rns'];
    }
    if($namanya=="AVAILABLEROOM"){
        $ravay=$keya['rns'];
    }
    if($namanya<>"ARR" and $namanya<>"REVPAR"){
        ?>
        <td  align="center"><?php echo number_format($keya['rns']) ?></td>
        <?php
    } else {
        if($namanya=="ARR") {
            ?>
        <td  align="center"><?php echo number_format($revenuey / $rsoldy) ?></td>        
        <?php } else { ?>
        <td  align="center"><?php echo number_format($revenuey / $ravay) ?></td>
            <?php
        }
        ?>
        <?php
    }

    /*if($namanya<>"ARR" and $namanya<>"REVPAR"){ 
//    if($namanya<>"AVAILABLEROOM" or $namanya<>"ROOMSSOLD" or $namanya<>"COMPLIMENTARYROOMS" or $namanya<>"HOUSEUSEROOM" or $namanya <>"ROOMSOCCUPIED" or $namanya<>"TOTALROOMREVENUE" or $namanya<>"ARR" or $namanya<>"REVPAR"){
    ?>
    <td  align="center"><?php echo number_format($keya['rns']) ?></td>
    <?php
    } else {        
    ?>
    <td  align="center"><?php echo number_format($keya['rev']) ?></td>
    <?php }*/

    $hus=Yii::$app->db->createCommand("select sum(actual) as rns from night_cdr where nama='".$keya['nama']."' and year(tgl)=".$thn. " and id_perusahaan=".Yii::$app->user->identity->id_perusahaan." and month(tgl)=".$bln)->queryScalar();
     if($keya['nama']=="ROOMSSOLD"){
            $rns1=$hus;
        }
        if($keya['nama']=="AVAILABLEROOM"){
            $avai1=$hus;
        }
        if($keya['nama']=="TOTALROOMREVENUE"){
            $rev1=$hus;
        }

/*    $rns=0;
    $revenue=0;
    foreach ($hus as $key) {
        if($keya['nama']=="ROOMSSOLD"){
            $rns1=$key['rns'];
        }
        if($keya['nama']=="AVAILABLEROOM"){
            $avai1=$key['rns'];
        }
        if($keya['nama']=="TOTALROOMREVENUE"){
            $rev1=$key['rns'];
        }

        $rns=$key['rns'];
        $revenue=$key['rev'];
    }*/

    
    if($namanya<>"ARR" and $namanya<>"REVPAR"){ 
    //if($namanya<>"AVAILABLEROOM" or $namanya<>"ROOMSSOLD" or $namanya<>"COMPLIMENTARYROOMS" or $namanya<>"HOUSEUSEROOM" or $namanya <>"ROOMSOCCUPIED" or $namanya<>"TOTALROOMREVENUE" or $namanya<>"ARR" or $namanya<>"REVPAR"){
    ?>
    <td align="center"><?php echo number_format($hus) ?></td>
    <?php } else { 
    if($namanya=="ARR") { ?>
    <td  align="center"><?php echo number_format($rev1/$rns1) ?></td>
    <?php } else 
        {?>
    <td  align="center"><?php echo number_format($rev1/$avai1) ?></td>
        <?php }
    }
    $haha=Yii::$app->db->createCommand("select  sum(actual) as rns, avg(actual) as rev from night_cdr  where nama='".$keya['nama']."' and id_perusahaan=".Yii::$app->user->identity->id_perusahaan." and date(tgl)=date(DATE_SUB(NOW(), INTERVAL 1 DAY))")->queryScalar();
        if($keya['nama']=="ROOMSSOLD"){
            if($haha==0){
            $rns1a=1;
            } else {
            $rns1a=$haha;
            }

        }
        if($keya['nama']=="AVAILABLEROOM"){
            if($haha==0){
            $avai1a=1;
            } else {
            $avai1a=$haha;
            }
//            $avai1a=$haha;
        }
        if($keya['nama']=="TOTALROOMREVENUE"){
            $rev1a=$haha;
        }

    /*$rns=0;
    $revenue=0;
    foreach ($haha as $key) {
        if($keya['nama']=="ROOMSSOLD"){
            $rns1=$key['rns'];
        }
        if($keya['nama']=="AVAILABLEROOM"){
            $avai1=$key['rns'];
        }
        if($keya['nama']=="TOTALROOMREVENUE"){
            $rev1=$key['rns'];
        }

        $rns=$key['rns'];
        $revenue=$key['rev'];

        $rns=$key['rns'];
        $revenue=$key['rev'];

    }*/


    if($namanya<>"ARR" and $namanya<>"REVPAR"){ 
   //if($namanya<>"AVAILABLEROOM" or $namanya<>"ROOMSSOLD" or $namanya<>"COMPLIMENTARYROOMS" or $namanya<>"HOUSEUSEROOM" or $namanya <>"ROOMSOCCUPIED" or $namanya<>"TOTALROOMREVENUE" or $namanya<>"ARR" or $namanya<>"REVPAR"){
    ?>
        <td  align="center"><?php echo number_format($haha) ?></td>
        <?php } 
        else { 

    if($namanya=="ARR") { ?>
    <td  align="center"><?php echo number_format($rev1a/$rns1a) ?></td>
    <?php } else 
        {?>
    <td  align="center"><?php echo number_format($rev1a/$avai1a) ?></td>
        <?php 
    }

            ?>
    <?php } ?>
    </tr>
    <?php
    }
    }
    ?>


    </table>

  <table class="table table-striped table-hover">
        <tr>
            <th rowspan="2" class="text-center">No.</th>
            <th rowspan="2" class="text-center">Market Segment</th>
            <th colspan="2" class="text-center">YTD</th>
            <th colspan="2" class="text-center">MTD</th>
            <th  colspan="2" class="text-center">Last Night</th>
        </tr>
        <tr>
            <th style="text-align:center;">Room Night</th>
            <th style="text-align:center;">Revenue</th>
            <th style="text-align:center;">Room Night</th>
            <th style="text-align:center;">Revenue</th>
            <th style="text-align:center;">Room Night</th>
            <th style="text-align:center;">Revenue</th>
        </tr>

    
    <?php 
    $i=0;
    $haa=Yii::$app->db->createCommand("Select nama,sum(rns) as rns,sum(revenue) as rev from report_market where month(tgl)<=".$bln." and year(tgl)=".$thn. " and id_perusahaan=".Yii::$app->user->identity->id_perusahaan." group by nama")->queryAll();
    foreach ($haa as $keya) {
    $i++;
    ?>
    <tr>
    <td><?php echo $i ?></td>
    <td><?php echo $keya['nama'] ?></td>
    <td  align="center"><?php echo number_format($keya['rns']) ?></td>
    <td  align="center"><?php echo number_format($keya['rev']) ?></td>
    <?php
    $hus=Yii::$app->db->createCommand("select sum(rns) as rns, sum(revenue) as rev from report_market where nama='".$keya['nama']."' and year(tgl)=".$thn. " and id_perusahaan=".Yii::$app->user->identity->id_perusahaan." and month(tgl)=".$bln)->queryAll();
    $rns=0;
    $revenue=0;
    foreach ($hus as $key) {
        $rns=$key['rns'];
        $revenue=$key['rev'];
    }
    ?>
    <td align="center"><?php echo number_format($rns) ?></td>
    <td  align="center"><?php echo number_format($revenue) ?></td>
    <?php
    $haha=Yii::$app->db->createCommand("select sum(rns) as rns, sum(revenue) as rev from report_market where nama='".$keya['nama']."' and id_perusahaan=".Yii::$app->user->identity->id_perusahaan." and date(tgl)=date(DATE_SUB(NOW(), INTERVAL 1 DAY))")->queryAll();
    $rns=0;
    $revenue=0;

    foreach ($haha as $key) {
        $rns=$key['rns'];
        $revenue=$key['rev'];
    }

    ?>
        <td  align="center"><?php echo number_format($rns) ?></td>
    <td  align="center"><?php echo number_format($revenue) ?></td>


    </tr>


    <?php
    }


    ?>

    </table>


 
<table class="table table-striped table-hover">
        <tr>
            <th rowspan="2" class="text-center">No.</th>
            <th rowspan="2" class="text-center">Tipe Kamar</th>
            <th colspan="2" class="text-center">YTD</th>
            <th colspan="2" class="text-center">MTD</th>
            <th  colspan="2" class="text-center">Last Night</th>
        </tr>
        <tr>
            <th style="text-align:center;">Room Night</th>
            <th style="text-align:center;">Revenue</th>
            <th style="text-align:center;">Room Night</th>
            <th style="text-align:center;">Revenue</th>
            <th style="text-align:center;">Room Night</th>
            <th style="text-align:center;">Revenue</th>
        </tr>

    
    <?php 
    $i=0;
    $haa=Yii::$app->db->createCommand("Select nama,sum(rns) as rns,sum(revenue) as rev from report_kamar where month(tgl)<=".$bln." and year(tgl)=".$thn. " and id_perusahaan=".Yii::$app->user->identity->id_perusahaan." group by nama")->queryAll();
    foreach ($haa as $keya) {
    $i++;
    ?>
    <tr>
    <td><?php echo $i ?></td>
    <td><?php echo $keya['nama'] ?></td>
    <td  align="center"><?php echo number_format($keya['rns']) ?></td>
    <td  align="center"><?php echo number_format($keya['rev']) ?></td>
    <?php
    $hus=Yii::$app->db->createCommand("select sum(rns) as rns, sum(revenue) as rev from report_kamar where nama='".$keya['nama']."' and year(tgl)=".$thn. " and id_perusahaan=".Yii::$app->user->identity->id_perusahaan." and month(tgl)=".$bln)->queryAll();
    $rns=0;
    $revenue=0;
    foreach ($hus as $key) {
        $rns=$key['rns'];
        $revenue=$key['rev'];
    }
    ?>
    <td align="center"><?php echo number_format($rns) ?></td>
    <td  align="center"><?php echo number_format($revenue) ?></td>
    <?php
    $haha=Yii::$app->db->createCommand("select sum(rns) as rns, sum(revenue) as rev from report_kamar where nama='".$keya['nama']."' and id_perusahaan=".Yii::$app->user->identity->id_perusahaan." and date(tgl)=date(DATE_SUB(NOW(), INTERVAL 1 DAY))")->queryAll();
    $rns=0;
    $revenue=0;

    foreach ($haha as $key) {
        $rns=$key['rns'];
        $revenue=$key['rev'];
    }

    ?>
        <td  align="center"><?php echo number_format($rns) ?></td>
    <td  align="center"><?php echo number_format($revenue) ?></td>


    </tr>


    <?php
    }


    ?>

    </table>


    



 <table class="table table-striped table-hover">
          <tr>
            <th rowspan="2" class="text-center">No.</th>
            <th rowspan="2" class="text-center">Company Name</th>
            <th colspan="2" class="text-center">YTD</th>
            <th colspan="2" class="text-center">MTD</th>
            <th  colspan="2" class="text-center">Last Night</th>
        </tr>
        <tr>
            <th style="text-align:center;">Room Night</th>
            <th style="text-align:center;">Revenue</th>
            <th style="text-align:center;">Room Night</th>
            <th style="text-align:center;">Revenue</th>
            <th style="text-align:center;">Room Night</th>
            <th style="text-align:center;">Revenue</th>
        </tr>

 <?php 
    $i=0;
    $haa=Yii::$app->db->createCommand("Select nama,SUM(DATEDIFF(cout, tiba)) as rns,sum(a.total) as rev from no_bon a join company b on a.id_company=b.kode 
             where year(tiba)=".$thn. " and a.id_perusahaan=".Yii::$app->user->identity->id_perusahaan." and id_company<>'' group by nama")->queryAll();
    foreach ($haa as $keya) {
    $i++;
    $namanya=$keya['nama'];
    ?>
    <tr>
    <td><?php echo $i ?></td>
    <td><?php echo $namanya ?></td>
    <td align="center"><?php echo number_format($keya['rns']) ?></td>
    <td align="center"><?php echo number_format($keya['rev']/$pembagi) ?></td>
    <?php 

    $hus=Yii::$app->db->createCommand("Select nama,SUM(DATEDIFF(cout, tiba)) as rns,sum(a.total) as rev from no_bon a join company b on a.id_company=b.kode where nama='".$namanya."' and year(tiba)=".$thn. " and a.id_perusahaan=".Yii::$app->user->identity->id_perusahaan." and id_company<>'' and month(tiba)=".$bln)->queryAll();
    //tipe_kamar='CAPSULE'
    $rns=0;
    $revenue=0;
    foreach ($hus as $key) {
    ?>
    <td align="center"> <?php echo number_format($key['rns']); ?></td>
    <td align="center"><?php echo number_format($key['rev']/$pembagi) ?></td>
    <?php
    }
    $haha=Yii::$app->db->createCommand("Select nama,SUM(DATEDIFF(cout, tiba)) as rns,sum(a.total) as rev from no_bon a join company b on a.id_company=b.kode  where nama='".$namanya."' and id_company<>'' and a.id_perusahaan=".Yii::$app->user->identity->id_perusahaan." and date(tiba)=date(DATE_SUB(NOW(), INTERVAL 1 DAY))")->queryAll();
    $rns=0;
    $revenue=0;
    foreach ($haha as $key) {
        $rns=$key['rns'];
        $revenue=$key['rev'];
    }
    ?>
    <td align="center"><?php echo number_format($key['rns']); ?></td>
    <td align="center"><?php echo number_format($key['rev']/$pembagi) ?></td>
    <?php
    }
    ?>
    </tr>
    </table>

 
<table class="table table-striped table-hover">
        <tr>
            <th rowspan="2" class="text-center">No.</th>
            <th rowspan="2" class="text-center">Negara</th>
            <th colspan="2" class="text-center">YTD</th>
            <th colspan="2" class="text-center">MTD</th>
            <th  colspan="2" class="text-center">Last Night</th>
        </tr>
        <tr>
            <th style="text-align:center;">Room Night</th>
            <th style="text-align:center;">Revenue</th>
            <th style="text-align:center;">Room Night</th>
            <th style="text-align:center;">Revenue</th>
            <th style="text-align:center;">Room Night</th>
            <th style="text-align:center;">Revenue</th>
        </tr>

    
    <?php 
    $i=0;
    $haa=Yii::$app->db->createCommand("Select nama,sum(rns) as rns,sum(revenue) as rev from report_country where month(tgl)<=".$bln." and id_perusahaan=".Yii::$app->user->identity->id_perusahaan." and year(tgl)=".$thn. " group by nama")->queryAll();
    foreach ($haa as $keya) {
    $i++;
    ?>
    <tr>
    <td><?php echo $i ?></td>
    <td><?php echo $keya['nama'] ?></td>
    <td  align="center"><?php echo number_format($keya['rns']) ?></td>
    <td  align="center"><?php echo number_format($keya['rev']) ?></td>
    <?php
    $hus=Yii::$app->db->createCommand("select sum(rns) as rns, sum(revenue) as rev from report_country where nama='".$keya['nama']."' and year(tgl)=".$thn. " and id_perusahaan=".Yii::$app->user->identity->id_perusahaan." and month(tgl)=".$bln)->queryAll();
    $rns=0;
    $revenue=0;
    foreach ($hus as $key) {
        $rns=$key['rns'];
        $revenue=$key['rev'];
    }
    ?>
    <td align="center"><?php echo number_format($rns) ?></td>
    <td  align="center"><?php echo number_format($revenue) ?></td>
    <?php
    $haha=Yii::$app->db->createCommand("select sum(rns) as rns, sum(revenue) as rev from report_country where nama='".$keya['nama']."' and id_perusahaan=".Yii::$app->user->identity->id_perusahaan." and date(tgl)=date(DATE_SUB(NOW(), INTERVAL 1 DAY))")->queryAll();
    $rns=0;
    $revenue=0;

    foreach ($haha as $key) {
        $rns=$key['rns'];
        $revenue=$key['rev'];
    }

    ?>
        <td  align="center"><?php echo number_format($rns) ?></td>
    <td  align="center"><?php echo number_format($revenue) ?></td>


    </tr>


    <?php
    }


    ?>

    </table>

<?php /*
    <table class="table table-striped table-hover">
          <tr>
            <th rowspan="2" class="text-center">No.</th>
            <th rowspan="2" class="text-center">Tipe Kamar</th>
            <th colspan="2" class="text-center">YTD</th>
            <th colspan="2" class="text-center">MTD</th>
            <th  colspan="2" class="text-center">Last Night</th>
        </tr>
        <tr>
            <th style="text-align:center;">Room Night</th>
            <th style="text-align:center;">Revenue</th>
            <th style="text-align:center;">Room Night</th>
            <th style="text-align:center;">Revenue</th>
            <th style="text-align:center;">Room Night</th>
            <th style="text-align:center;">Revenue</th>
        </tr>
    <?php 
    $i=0;
    $haa=Yii::$app->db->createCommand("Select tipe_kamar,SUM(DATEDIFF(cout, tiba)) as rns,sum(a.total-a.breakfast) as rev from no_bon a join tipe_kamar b on a.id_kamar=b.id 
            join jenis_kamar c on b.id_jenis=c.id where year(tiba)=".$thn. " group by tipe_kamar")->queryAll();
    foreach ($haa as $keya) {
    $i++;
    $namanya=$keya['tipe_kamar'];
    ?>
    <tr>
    <td><?php echo $i ?></td>
    <td><?php echo $namanya ?></td>
    <td align="center"><?php echo number_format($keya['rns']) ?></td>
    <td align="center"><?php echo number_format($keya['rev']/1.144) ?></td>
    <?php 

    $hus=Yii::$app->db->createCommand("select tipe_kamar,SUM(DATEDIFF(cout, tiba)) as rns,sum(a.total-a.breakfast) as rev from no_bon a join tipe_kamar b on a.id_kamar=b.id 
            join jenis_kamar c on b.id_jenis=c.id where tipe_kamar='".$namanya."' and year(tiba)=".$thn. " and month(tiba)=".$bln)->queryAll();
    //tipe_kamar='CAPSULE'
    $rns=0;
    $revenue=0;
    foreach ($hus as $key) {
    ?>
    <td align="center"> <?php echo number_format($key['rns']); ?></td>
    <td align="center"><?php echo number_format($key['rev']/1.144) ?></td>
    <?php
    }
    $haha=Yii::$app->db->createCommand("select tipe_kamar,SUM(DATEDIFF(cout, tiba)) as rns,sum(a.total-a.breakfast) as rev from no_bon a join tipe_kamar b on a.id_kamar=b.id 
            join jenis_kamar c on b.id_jenis=c.id where tipe_kamar='".$namanya."'  and date(tiba)=date(DATE_SUB(NOW(), INTERVAL 1 DAY))")->queryAll();
    $rns=0;
    $revenue=0;
    foreach ($haha as $key) {
        $rns=$key['rns'];
        $revenue=$key['rev'];
    }
    ?>
    <td align="center"><?php echo number_format($key['rns']); ?></td>
    <td align="center"><?php echo number_format($key['rev']/1.144) ?></td>
    <?php
    }
    ?>
    </tr>
    </table>*/?>
    </div>

    <script type="text/javascript">
        
        window.print();
    </script>
</div>
