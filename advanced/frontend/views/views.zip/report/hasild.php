<?php

use yii\helpers\Html;
use yii\widgets\DetailView;
$da=explode("-",$has);
$bln=$da[1];
$tgl=$da[2];    
$thn=$da[0];    
/* @var $this yii\web\View */
/* @var $model app\models\Reservasi */

$this->title = "REPORT SUMARY ".$tgl ."-".$bln."-".$thn;
$this->params['breadcrumbs'][] = ['label' => 'Report', 'url' => ['index']];
$this->params['breadcrumbs'][] = $this->title;
?>
<div class="reservasi-view">

    <h1><?= Html::encode($this->title) ?></h1>
    <div class="table-responsive">
    <table class="table table-striped table-hover">
        <tr>
            <th class="text-left">No.</th>
            <th class="text-left">Nama Item</th>
            <th class="text-center">Actual</th>
        </tr>
    <?php 
    $i=0;
    $haa=Yii::$app->db->createCommand("Select nama,sum(actual) as rns,avg(actual) as rev, max(status) as status from night_cdr where tgl='".$has. "' group by nama order by status ")->queryAll();
    $revenuey=0;
    $rsoldy=0;
    $ravay=0;
    $avail=1;
    $rns1=0;
    foreach ($haa as $keya) {
    $i++;
    $namanya=$keya['nama'];

    if($namanya=="ROOMSSOLD"){
        $rns1=$keya['rns'];
    }
    if($namanya=="AVAILABLEROOM"){
        $avail=$keya['rns'];
    }

    if($namanya<>"ROOMSOCCUPIED"){    
        if($namanya=="FB REVENUE") {
            $haha="Breakfast";
        } else {
            $haha=$namanya;
        }
    ?>
    <tr>
    <td><?php echo $i ?></td>
    <td><?php echo $haha ?></td>
    <?php
         if($namanya=="TOTALROOMREVENUE"){
            $revenuey=$keya['rns'];
        }
        if($namanya=="ROOMSSOLD"){
            $rsoldy=$keya['rns'];
        }
        if($namanya=="AVAILABLEROOM"){
            $ravay=$keya['rns'];
        }
    if($namanya<>"ARR" and $namanya<>"REVPAR"){
        ?>
        <td  align="center"><?php echo number_format($keya['rns']) ?></td>
        <?php
    } else {
        if($namanya=="ARR") {
            ?>
        <td  align="center"><?php echo number_format($revenuey / $rsoldy) ?></td>        
        <?php } else { ?>
        <td  align="center"><?php echo number_format($revenuey / $ravay) ?></td>
            <?php
        }
        ?>
        <?php
    }

    }?>
    </tr>
    <?php 

    }
    $i=$i+1;
    ?>
    <tr>
        <td><?php echo $i; ?></td>
        <td>ROOMSOCCUPIED</td>
        <td align="center"><?php echo number_format(($rns1 / $avail)*100) ?> %</td>
        
    </tr>


    </table>

  <table class="table table-striped table-hover">
        <tr>
            <th rowspan="2" class="text-center">No.</th>
            <th rowspan="2" class="text-center">Market Segment</th>
            <th colspan="2" class="text-center">Total</th>
        </tr>
        <tr>
            <th style="text-align:center;">Room Night</th>
            <th style="text-align:center;">Revenue</th>
        </tr>

    
    <?php 
    $i=0;
    $haa=Yii::$app->db->createCommand("Select nama,sum(rns) as rns,sum(revenue) as rev from report_market where tgl='".$has."' group by nama")->queryAll();
    foreach ($haa as $keya) {
    $i++;
    ?>
    <tr>
    <td><?php echo $i ?></td>
    <td><?php echo $keya['nama'] ?></td>
    <td  align="center"><?php echo number_format($keya['rns']) ?></td>
    <td  align="center"><?php echo number_format($keya['rev']) ?></td>


    </tr>


    <?php
    }


    ?>

    </table>


    </div>
    <script type="text/javascript">
        
        window.print();
    </script>
</div>
