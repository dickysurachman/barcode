<?php

use yii\helpers\Html;
use yii\widgets\ActiveForm;
//use app\models\Guest;
use yii\jui\DatePicker;
use yii\web\View;
use yii\helpers\ArrayHelper;
$tipe=['Aktif','Non Aktif'];

/* @var $this yii\web\View */
/* @var $model app\models\Nobon */
/* @var $form yii\widgets\ActiveForm */
$ha=Yii::$app->db->createCommand("SELECT DATE_FORMAT(tiba,'%m-%Y') AS nilai,DATE_FORMAT(tiba,'%b-%Y') AS nilaia,YEAR(tiba),MONTH(tiba) 
FROM no_bon where id_perusahaan=".Yii::$app->user->identity->id_perusahaan." GROUP BY DATE_FORMAT(tiba,'%m-%Y') ORDER BY YEAR(tiba) DESC,MONTH(tiba) DESC")->queryAll();

$tipe=ArrayHelper::map($ha, 'nilai', 'nilaia')
//$ha=Yii::$app->db->createCommand("")
?>

<div class="nobon-form">



    <?php $form = ActiveForm::begin(); ?>

   <?= $form->field($model, 'tgl_akhir')->dropDownList($tipe,['prompt'=>'Pilihan']) ?>
   <?php
        /*echo $form->field($model, 'id_kamar')->widget(Select2::classname(), [
        'data' => ArrayHelper::map(Tipekamar::find()->where(['status'=>'VC'])->all(), 'id', 'nama_kamar'),
        'options' => ['placeholder' => 'Select '],
        'pluginOptions' => [
            'allowClear' => true
        ],
        ]);*/
    
 
    ?>
 

   <br/>
    
   
    <div class="form-group">
        <?= Html::submitButton('Hasil',['class' =>'btn btn-primary']) ?>
    </div>

    <?php ActiveForm::end(); ?>

</div>
