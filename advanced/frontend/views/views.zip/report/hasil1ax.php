<?php

use yii\helpers\Html;
use yii\widgets\DetailView;
$da=explode("-",$has);
$bln=$da[1];
$thn=$da[0];
$tgl=$da[2];    
/* @var $this yii\web\View */
/* @var $model app\models\Reservasi */
$hasiltotal=0;
$this->title = "REPORT Cashier ".$has ." until ". $has1;
$this->params['breadcrumbs'][] = ['label' => 'Report', 'url' => ['index']];
$this->params['breadcrumbs'][] = $this->title;
?>
<div class="reservasi-view">

    <h1><?= Html::encode($this->title) ?></h1>
    <div class="table-responsive">
    <table class="table table-striped table-hover">
        <tr>
            <th class="text-left">No.</th>
            <th class="text-left">Tanggal</th>
            <th class="text-left">Outlet</th>
            <th class="text-left"></th>
            <th class="text-center">Metode Pembayaran</th>
            <th class="text-center">Amount</th>
        </tr>
    <?php 
    $i=0;
    $where4=" where tgl between '".$has."' and '" .$has1. "' and a.id_perusahaan=".Yii::$app->user->identity->id_perusahaan;
    $where4b=" where tanggal between '".$has."' and '" .$has1. "' and a.id_perusahaan=".Yii::$app->user->identity->id_perusahaan;
    $where4a=" where tiba between '".$has."' and '" .$has1. "' and a.id_perusahaan=".Yii::$app->user->identity->id_perusahaan;
    $deposit= Yii::$app->db->createCommand("SELECT tgl,jenis as jenis,SUM(jumlah) AS jumlah FROM deposit a JOIN jenis_penerimaan b ON a.id_penerimaan=b.id  ". $where4."
    and id_penerimaan=".$nama." GROUP BY jenis,tgl")->queryAll();

    foreach ($deposit as $keya ) {
    $i++;
    $hasiltotal+=$keya['jumlah'];
    ?>
    <tr>
    <td><?php echo $i ?></td>
    <td><?php echo $keya['tgl'] ?></td>
    <td>Deposit</td>
    <td></td>
    <td class="text-center"><?php echo $keya['jenis'] ?></td>
    <td class="text-right"><?php echo number_format($keya['jumlah']) ?></td>
    </tr>


    <?php
    }

    $outlet=Yii::$app->db->createCommand("SELECT a.tgl,c.nama as nama,jenis,SUM(total) as jumlah FROM no_bon_outlet a JOIN jenis_penerimaan b ON a.id_terima=b.id 
    join profile_daerah c on a.id_profile=c.id
     ". $where4." and id_terima=".$nama." GROUP BY nama,jenis,tgl")->queryAll();
    foreach ($outlet as $key ) {
    $i++;
        $hasiltotal+=$key['jumlah'];

    ?>

    <tr>
    <td><?php echo $i ?></td>
    <td><?php echo $key['tgl'] ?></td>
    <td><?php echo $key['nama'] ?></td>
    <td></td>
    <td class="text-center"><?php echo $key['jenis'] ?></td>
    <td class="text-right"><?php echo number_format($key['jumlah']) ?></td>
    </tr>



    <?php
           }

    $nobon=Yii::$app->db->createCommand("SELECT tiba as tgl, jenis as jenis,SUM(deposit) AS jumlah FROM no_bon a JOIN jenis_penerimaan b ON a.id_terima=b.id 
     ". $where4a." and id_terima=".$nama." GROUP BY jenis,tiba")->queryAll();
    foreach ($nobon as $key ) {
    $i++;
        $hasiltotal+=$key['jumlah'];

    ?>

    <tr>
    <td><?php echo $i ?></td>
    <td><?php echo $key['tgl'] ?></td>
    <td>FO</td>
    <td></td>
    <td class="text-center"><?php echo $key['jenis'] ?></td>
    <td class="text-right"><?php echo number_format($key['jumlah']) ?></td>
    </tr>
    <?php 
    }

    $where5=" where tgl_deposit2 between '".$has."' and '".$has1."' and a.id_perusahaan=".Yii::$app->user->identity->id_perusahaan;
    $nobon=Yii::$app->db->createCommand("SELECT tgl_deposit2 as tgl,jenis as jenis,SUM(deposit2) AS jumlah FROM no_bon a JOIN jenis_penerimaan b ON a.id_terima2=b.id  ". $where5." and id_terima2=".$nama." GROUP BY jenis,tgl_deposit2")->queryAll();
    foreach ($nobon as $key ) {
    $i++;
        $hasiltotal+=$key['jumlah'];

    ?>
    <tr>
    <td><?php echo $i ?></td>
    <td><?php echo $key['tgl'] ?></td>
    <td>FO</td>
    <td></td>
    <td class="text-center"><?php echo $key['jenis'] ?></td>
    <td class="text-right"><?php echo number_format($key['jumlah']) ?></td>
    </tr>
    <?php 
    }


    $where5x=" where tgl between '".$has."' and '".$has1."' and a.id_perusahaan=".Yii::$app->user->identity->id_perusahaan;
    $nobon=Yii::$app->db->createCommand("SELECT a.tgl,jenis as jenis,SUM(hrg_satuan*jumlah) AS jumlah FROM no_bon_tambah a JOIN jenis_penerimaan b ON a.id_terima=b.id  ". $where5x." and id_terima=".$nama." GROUP BY jenis,tgl")->queryAll();
    foreach ($nobon as $key ) {
    $i++;
        $hasiltotal+=$key['jumlah'];

    ?>
    <tr>
    <td><?php echo $i ?></td>
    <td><?php echo $key['tgl'] ?></td>
    <td>FO Charge</td>
    <td></td>
    <td class="text-center"><?php echo $key['jenis'] ?></td>
    <td class="text-right"><?php echo number_format($key['jumlah']) ?></td>
    </tr>
    <?php 
    }



    $nobon= Yii::$app->db->createCommand("SELECT a.tanggal,jenis,SUM(jumlah) AS jumlah FROM bayar_bon a left JOIN jenis_penerimaan b ON a.id_terima=b.id   ".
                    $where4b." and id_terima=".$nama." GROUP BY jenis,tanggal")->queryAll();
    foreach ($nobon as $key ) {
    $i++;
        $hasiltotal+=$key['jumlah'];

    ?>
    <tr>
    <td><?php echo $i ?></td>
     <td><?php echo $key['tanggal'] ?></td>
     <td>FO</td>
    <td></td>
    <td class="text-center"><?php echo $key['jenis'] ?></td>
    <td class="text-right"><?php echo number_format($key['jumlah']) ?></td>
    </tr>
    <?php 
    }
    $where6=" where tanggal between '".$has."' and '" .$has1."' and a.id_perusahaan=".Yii::$app->user->identity->id_perusahaan;
    $nobon= Yii::$app->db->createCommand("SELECT a.tanggal,jenis,SUM(jumlah) AS jumlah FROM bayar_master a JOIN jenis_penerimaan b ON a.id_terima=b.id   ". $where6."
    and id_terima=".$nama." GROUP BY kode_akun,jenis,tanggal")->queryAll();
    foreach ($nobon as $key ) {
    $i++;
        $hasiltotal+=$key['jumlah'];

    ?>
    <tr>
    <td><?php echo $i ?></td>
     <td><?php echo $key['tanggal'] ?></td>
    <td>FO</td>
    <td></td>
    <td class="text-center"><?php echo $key['jenis'] ?></td>
    <td class="text-right"><?php echo number_format($key['jumlah']) ?></td>
    </tr>
    <?php 
    }
     $where5=" where tgl_refund between '".$has."' and '".$has1."' and a.id_perusahaan=".Yii::$app->user->identity->id_perusahaan;
     $nobon= Yii::$app->db->createCommand("SELECT tgl_refund as tgl,jenis,c.nama,SUM(refund) AS jumlah FROM deposit a JOIN jenis_penerimaan b ON a.id_penerimaan2=b.id join guest c on a.id_guest=c.id  ". $where5." and id_penerimaan2=".$nama." GROUP BY jenis,c.nama,tgl_refund")->queryAll();
    foreach ($nobon as $key ) {
    $i++;
        $hasiltotal+=$key['jumlah'];

    ?>
    <tr>
    <td><?php echo $i ?></td>
     <td><?php echo $key['tgl'] ?></td>
    <td>FO - Refund Deposit</td>
    <td></td>
    <td class="text-center"><?php echo $key['jenis'] ?></td>
    <td class="text-right"><?php echo number_format($key['jumlah']) ?></td>
    </tr>
    <?php 
    }
    
  $where5=" where tanggal between '".$has."' and '".$has1."' and a.id_perusahaan=".Yii::$app->user->identity->id_perusahaan;
     $nobon= Yii::$app->db->createCommand("SELECT tanggal as tanggal,b.jenis,SUM(jumlah) AS jumlah FROM bayar_outlet a JOIN jenis_penerimaan b ON a.id_terima=b.id ". $where5." GROUP BY tanggal,jenis")->queryAll();
    foreach ($nobon as $key ) {
    $i++;
        $hasiltotal+=$key['jumlah'];

    ?>
    <tr>
    <td><?php echo $i ?></td>
     <td><?php echo $key['tanggal'] ?></td>
    <td>FO - Refund Deposit</td>
    <td></td>
    <td class="text-center"><?php echo $key['jenis'] ?></td>
    <td class="text-right"><?php echo number_format($key['jumlah']) ?></td>
    </tr>
    <?php 
    }
    ?>
    <tr>

    <td></td>
    <td>Total</td>
    <td></td>
    <td></td>
    <td class="text-center"></td>
    <td class="text-right"><?php echo number_format($hasiltotal) ?></td>
    </tr>

    </table>
    </div>

    <script type="text/javascript">
        
        window.print();
    </script>
</div>
