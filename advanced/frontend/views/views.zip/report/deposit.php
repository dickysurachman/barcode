<?php

use yii\helpers\Html;
use yii\grid\GridView;

/* @var $this yii\web\View */
/* @var $searchModel app\models\DepositSearch */
/* @var $dataProvider yii\data\ActiveDataProvider */
use kartik\export\ExportMenu;
use kartik\select2\Select2;
use yii\web\View;
//use kartik\export\ExportMenu;
//use kartik\grid\GridView;
use yii\web\JsExpression;
use app\models\Guest;
$url = \yii\helpers\Url::to(['reservasi/guest']);
$this->title = 'Deposits';
$this->params['breadcrumbs'][] = $this->title;
$cityDesc=empty($searchModel->id_guest) ? '' : Guest::findOne($searchModel->id_guest)->nama;
?>
<div class="deposit-index">

    <h1><?= Html::encode($this->title) ?></h1>

    <?php // echo $this->render('_search', ['model' => $searchModel]); ?>

    <p>
    <?php 
$gridColumns = [
    ['class' => 'yii\grid\SerialColumn'],
     'no_deposit',
            'namatamu',
            'tgl',
            [
            'attribute'=>'tgl_chekin',
            'value'=>'cekin'
            ],
            [
            'attribute'=>'tgl_chekout',
            'value'=>'cekout'
            ],
             //'tgl_chekout',
            // 'status',
            // 'refund',
            [
            'attribute'=>'jumlah',
            'value'=>function($data) {
                            return number_format($data->jumlah);
                    },
            ],
             'jumlah',
             'refund',
             'tgl_refund',
             'keterangan:ntext',
            // 'id_penerimaan',
             'add_who',
            // 'add_date',
             'edit_who',
];
$statusa=['Belum Terpakai','Sudah Terpakai'];
// Renders a export dropdown menu
echo ExportMenu::widget([
    'dataProvider' => $dataProvider,
    'columns' => $gridColumns
]);
?>
    </p>
    <div class="table-responsive">
    <?= GridView::widget([
        'dataProvider' => $dataProvider,
        'filterModel' => $searchModel,
        'columns' => [
            ['class' => 'yii\grid\SerialColumn'],

            //'id',
            'no_deposit',
            //'namatamu',
            [
             'attribute'=>'id_guest',
             'value'=>'namatamu',
             'filter'=> Select2::widget([
                            'name' => 'DepositSearch[id_guest]',
                            'theme' => Select2::THEME_BOOTSTRAP,
                            'value' => $cityDesc,//$nomeescola,
                            //'hideSearch' => true,
                            'options' => [
                                'initValueText' => $cityDesc, 
                                'placeholder' => 'Search',
                            ],
                            'pluginOptions' => [
                                'allowClear' => true,
                                'minimumInputLength' => 3,
                            'ajax' => [
                                'url' => $url,
                                'dataType' => 'json',
                                'data' => new JsExpression('function(params) { return {q:params.term}; }')
                            ],
                            'escapeMarkup' => new JsExpression('function (markup) { return markup; }'),
                            'templateResult' => new JsExpression('function(id_guest) { return id_guest.text; }'),
                            'templateSelection' => new JsExpression('function (id_guest) { return id_guest.text; }'),
                            ],
                        ]),
            ],
            'tgl',
            [
            'attribute'=>'tgl_chekin',
            'value'=>'cekin'
            ],
            [
            'attribute'=>'tgl_chekout',
            'value'=>'cekout'
            ],
             [
            'attribute'=>'status',
            'value'=>'st',
            'filter'=>$statusa,
            ],
             //'tgl_chekout',
            // 'status',
            // 'refund',
            [
            'attribute'=>'jumlah',
            'value'=>function($data) {
                            return number_format($data->jumlah);
                    },
            ],
            [
            'attribute'=>'refund',
            'value'=>function($data) {
                            return number_format($data->refund);
                    },
            ],
             //'jumlah',
             'keterangan:ntext',
            // 'id_penerimaan',
             'add_who',
            // 'add_date',
             'edit_who',
            // 'edit_date',
            [
                //'class' => 'yii\grid\ActionColumn',
                'header'=>'Print',
                'attribute' => 'img',
                'format' => 'raw',
                'label' => 'Status',
                'value'=>function ($data) {
                                return Html::a('<span class="glyphicon glyphicon-print" style="font-size:14pt;" title="Print"></span>',['deposit/cetak', 'id' => $data->id],
                                    ['target'=>'_blank', 'class' => 'linksWithTarget']);
                                },
            ],
            'tgl_refund',
        ],
    ]); ?>
    </div>
</div>
