<?php

use yii\helpers\Html;
use yii\widgets\ActiveForm;
//use app\models\Guest;
use yii\jui\DatePicker;
use yii\web\View;
$script = <<< JS
$("#report-tgl").datepicker({
    changeMonth: true, 
    changeYear: true, 
    dateFormat:'yy-mm-dd',
    'maxDate':'-1 days',
});
JS;
 
$position= View::POS_END;
$this->registerJs($script,$position);

/* @var $this yii\web\View */
/* @var $model app\models\Nobon */
/* @var $form yii\widgets\ActiveForm */
?>

<div class="nobon-form">



    <?php $form = ActiveForm::begin(); ?>

       <label class="control-label" for="semen-tgl"><?php echo "Tanggal Transaksi Night Audit" ?> </label>
        <?php
        echo DatePicker::widget([
        'model'  => $model,
        'attribute'=>'tgl',
        'dateFormat' => 'yyyy-MM-dd',
        'options'=>['class'=>'form-control','autocomplete'=>'off','readonly'=>'readonly']
    ]);?>
   
   <br/>
<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>
<script>
 $(document).ready(function(){
  $("#report-tgl").change(function(){
     $.ajax({
                                 type: "post",
                                 dataType: "",
                                 url: "<?php echo Yii::$app->urlManager->createUrl('report/test1')?>",
                                 data: $("#w0").serialize(),
                                 success: function(response) {
                                     $("#hasil1").html(response);
                                 }
                             });
     return false;
  });
});
</script>
    <div class="form-group">
        <?= Html::submitButton('Proses',['class' =>'btn btn-primary']) ?>
        
    </div>

    <?php ActiveForm::end(); ?>
<div id="hasil1">
</div>
<?php

?>
</div>
