<?php

use yii\helpers\Html;
use app\models\Nobon;
use yii\widgets\DetailView;
use app\models\Bondmaster;
use app\models\Bonmaster;
$da=explode("-",$has);
$bln=$da[1];
$thn=$da[0];
$tgl=$da[2];    
/* @var $this yii\web\View */
/* @var $model app\models\Reservasi */

//$this->title = "A/R Guest Ledger ". $tgl."-".$bln."-".$thn;
$this->title = "A/R Guest Ledger ".$has ." s/d ".$has2 ;
$this->params['breadcrumbs'][] = ['label' => 'Report', 'url' => ['index']];
$this->params['breadcrumbs'][] = $this->title;
?>
<div class="reservasi-view">

    <h1><?= Html::encode($this->title) ?></h1>
    <div class="table-responsive">
    <table class="table table-striped table-hover">
        <tr>
            <th class="text-left">No.</th>
            <th class="text-left">Outlet</th>
            <th class="text-left">Folio</th>
            <th class="text-center">Remarks</th>
            <th class="text-center">Amount</th>
        </tr>

    <?php 
    $i=0;
    $where="WHERE (tiba between '".$has."' and '".$has2."') OR (cout>'".$has."' AND tiba<'".$has."') and id_perusahaan=".Yii::$app->user->identity->id_perusahaan ;
    $where="WHERE tiba between '".$has."' and '".$has2."' and id_perusahaan=".Yii::$app->user->identity->id_perusahaan;
    $nobon=Yii::$app->db->createCommand("SELECT id,no_bon,total,deposit,id_terima,deposit2,id_terima2 FROM no_bon ". $where)->queryAll();
    foreach ($nobon as $key ) {
    $bayar=$key['deposit'];
    $tagihan=$key['total'];
    $hasil=false;
    if($bayar==$tagihan){
    $hasil=true;
    }elseif($bayar<$tagihan){
        $hasil=false;
        if($key['deposit2']<>"" and $key['deposit2']<>0){
            $bayar2=$key['deposit2'];
            $totbayar=$bayar+$bayar2;
            if($totbayar<$tagihan){
                $hasil=false;
            } else {
                $hasil=true;
            }
        } else {   
        $cek=Bondmaster::findOne(['id_bon'=>$key['id']]);
        if(isset($cek)) {
            $cek2=Bonmaster::findOne($cek->id_master);
            if(isset($cek2)){
                //var_dump($cek2);die();
                $bayar1=$cek2->bayar;
                $tagihan1=$cek2->jumlah;
                if($bayar1>=$tagihan1){
                    $hasil=true;
                }
            }
        }
        }
    }   else {
    if(is_null($key['id_terima']) or $key['id_terima']==""){
        $bayardet=Yii::$app->db->createCommand("select sum(jumlah) as jumlah from bayar_bon where id_bon=".$key['id'])->queryScalar();
        if($bayardet<$tagihan)
            $hasil=false; 
        } else {
            $hasil=true;
    }
    }
    if($hasil==false) {
    $i++;
    
    $kamar=Nobon::findOne($key['id']);

    ?>

    <tr>
    <td><?php echo $i ?></td>
    <td>FO</td>
    <td><?php echo $key['no_bon'] ?></td>
    <td class="text-center"><?php echo "Kamar " .$kamar->namakamar ." " .$kamar->tipekamar ." an. ".$kamar->namatamu ?></td>
    <td class="text-right"><?php echo number_format($kamar->total) ?></td>
    </tr>

    <?php
    }

    }


?>

    </table>
    </div>

    <script type="text/javascript">
        
        window.print();
    </script>
</div>
