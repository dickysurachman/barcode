<?php

use yii\widgets\DetailView;

/* @var $this yii\web\View */
/* @var $model app\models\Bonmaster */
?>
<div class="bonmaster-view">
 
    <?= DetailView::widget([
        'model' => $model,
        'attributes' => [
            'id',
            'no_inv',
            'tanggal',
            'id_company',
            'status',
            'jumlah',
            'rns',
            'add_who',
            'add_date',
            'edit_who',
            'edit_date',
        ],
    ]) ?>

</div>
