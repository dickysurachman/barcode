<?php

use yii\widgets\DetailView;

/* @var $this yii\web\View */
/* @var $model app\models\Outletdet */
?>
<div class="outletdet-view">
 
    <?= DetailView::widget([
        'model' => $model,
        'attributes' => [
            'id',
            'id_bon',
            'id_barang',
            'hrg_satuan',
            'jumlah',
            'sub_total',
            'add_who',
            'add_date',
            'edit_who',
            'edit_date',
        ],
    ]) ?>

</div>
