
<?php
use app\models\Nobon;
$tracking=Nobon::find()->where(['id_guest'=>$model->id])->orderBy(['id' => SORT_ASC])->all();
if($tracking<>""){
            ?>
            <table class="table table-bordered">
                <tr>
                <th>No. </th>
                <th>No Folio</th>
                <th>Check In</th>
                <th>Check Out</th>
                <th>Total</th>
                </tr>
            <?php
            $i=1;
            foreach ($tracking as $key => $value) {
                echo "<tr>";
                echo "<td>$i</td>";
                echo "<td>".$value['no_bon']."</td>";
                echo "<td>".date('d-m-Y',strtotime($value['tiba']))."</td>";
                echo "<td>".date('d-m-Y',strtotime($value['cout']))."</td>";
                echo "<td>".number_format($value['total'])."</td>";
                echo "</tr>";
                $i++;
            }
            ?>
            </table>
        <?php }
?>