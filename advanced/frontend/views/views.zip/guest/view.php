<?php

use yii\widgets\DetailView;

/* @var $this yii\web\View */
/* @var $model app\models\Guest */
?>
<div class="guest-view">
 
    <?= DetailView::widget([
        'model' => $model,
        'attributes' => [
            'id',
            'nama',
            'no_identitas',
            'identitas',
            'jenis_kel',
            'tempat',
            'tgl_lahir',
            'kebangsaan',
            'alamat',
            'kontak',
        ],
        'template' => '<tr><th style="width:150px;">{label}</th><td>{value}</td></tr>',
    ]) ?>

</div>
