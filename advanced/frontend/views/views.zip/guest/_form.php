<?php
use yii\helpers\Html;
use yii\widgets\ActiveForm;
use yii\web\View;
use yii\helpers\Url;
use yii\jui\DatePicker;
use yii\helpers\ArrayHelper;
use yii\widgets\MaskedInput;
use app\models\Identitas;
use app\models\Negara;
/* @var $this yii\web\View */
/* @var $model app\models\Bibdistribusi */
/* @var $form yii\widgets\ActiveForm */
$negara=ArrayHelper::map(Negara::find()->orderBy('id')->all(),'country_name','country_name');
$countries=Identitas::find()->where(['id_perusahaan'=>Yii::$app->user->identity->id_perusahaan])->all();
//use yii\helpers\ArrayHelper;
$dataPost=ArrayHelper::map($countries,'id','Jenis');
//$propinsi=ArrayHelper::map(Propinsi::find()->orderBy('name')->all(),'name','name');
/* @var $this yii\web\View */
/* @var $model app\models\Guest */
/* @var $form yii\widgets\ActiveForm */

$kelamin=["Pria"=>"Pria",
"Wanita"=>"Wanita"
];

$script = <<< JS
$("#guest-tgl_lahir").datepicker({
    changeMonth: true, 
    changeYear: true, 
    dateFormat:'yy-mm-dd',
});
JS;
$position= View::POS_END;
$this->registerJs($script,$position);

?>

<div class="guest-form">

    <?php $form = ActiveForm::begin(); ?>

    <div class="col-md-6" style="padding-left: 0px"><?= $form->field($model, 'nama')->textInput(['maxlength' => true]) ?></div>
    <div class="col-md-6" style="padding-right: 0px"><?= $form->field($model, 'jenis_kel')->dropDownList($kelamin,['prompt'=>'Pilih']) ?></div>
    <div class="col-md-4" style="padding-left: 0px"><?= $form->field($model, 'id_jenis_identitas')->dropDownList($dataPost,['prompt'=>'Pilih']) ?></div>
    <div class="col-md-4"><?= $form->field($model, 'no_identitas')->textInput(['maxlength' => true]) ?></div>
    <div class="col-md-4"><?= $form->field($model, 'tempat')->textInput(['maxlength' => true]) ?></div>
    <div class="col-md-6" style="padding-left: 0px"><label class="control-label" for="bibdistribusi-tgl"><?php echo "Tanggal Lahir" ?> </label>
    <?php
    echo DatePicker::widget([
    'model'  => $model,
    'attribute'=>'tgl_lahir',
    'dateFormat'=>'yyyy-MM-dd',
    'options'=>['class'=>'form-control',
    ]
    ]); ?></div>
    <div class="col-md-6" style="padding-right: 0px">
    <?= $form->field($model, 'kebangsaan')->dropDownList($negara) ?>
    </div>
    <div class="col-md-6" style="padding-left: 0px"><?= $form->field($model, 'alamat')->textInput(['maxlength' => true]) ?></div>
    <div class="col-md-6" style="padding-right: 0px"><?= $form->field($model, 'kontak')->textInput(['maxlength' => true]) ?></div>
  
	<?php if (!Yii::$app->request->isAjax){ ?>
	  	<div class="form-group">
	        <?= Html::submitButton($model->isNewRecord ? 'Create' : 'Update', ['class' => $model->isNewRecord ? 'btn btn-success' : 'btn btn-primary']) ?>
	    </div>
	<?php } ?>

    <?php ActiveForm::end(); ?>
    
</div>
