<?php

use yii\helpers\Html;

/* @var $this yii\web\View */
/* @var $model app\models\Identitas */
?>
<div class="identitas-update">

    <?= $this->render('_form', [
        'model' => $model,
    ]) ?>

</div>
