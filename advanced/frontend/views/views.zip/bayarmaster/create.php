<?php

use yii\helpers\Html;


/* @var $this yii\web\View */
/* @var $model app\models\Bayarmaster */

?>
<div class="bayarmaster-create">
    <?= $this->render('_form', [
        'model' => $model,
    ]) ?>
</div>
