<?php

use yii\helpers\Html;


/* @var $this yii\web\View */
/* @var $model app\models\Padang */

?>
<div class="padang-create">
    <?= $this->render('_formpadang', [
        'model' => $model,
    ]) ?>
</div>
