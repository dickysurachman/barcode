<?php

use yii\helpers\Html;

/* @var $this yii\web\View */
/* @var $model app\models\Kandangbib */
?>
<div class="kandangbib-update">

    <?= $this->render('_form2bet', [
        'model' => $model,
    ]) ?>

</div>
