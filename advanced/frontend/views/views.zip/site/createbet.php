<?php

use yii\helpers\Html;


/* @var $this yii\web\View */
/* @var $model app\models\Kandang */

?>
<div class="kandang-create">
    <?= $this->render('_form2bet', [
        'model' => $model,
    ]) ?>
</div>
