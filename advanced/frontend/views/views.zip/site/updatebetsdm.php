<?php

use yii\helpers\Html;

/* @var $this yii\web\View */
/* @var $model app\models\Bibsdm */
?>
<div class="bibsdm-update">

    <?= $this->render('_formbetsdm', [
        'model' => $model,
    ]) ?>

</div>
