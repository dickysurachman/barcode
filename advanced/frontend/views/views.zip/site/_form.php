<?php

use yii\helpers\Html;
use yii\widgets\ActiveForm;

/* @var $this yii\web\View */
/* @var $model app\models\Profile */
/* @var $form yii\widgets\ActiveForm */
?>

<div class="profile-form">

    <?php $form = ActiveForm::begin(); ?>

    <?= $form->field($model, 'nama')->textInput(['maxlength' => true]) ?>

    <?= $form->field($model, 'alamat')->textarea(['rows' => 6]) ?>

    <div class="col-md-6" style="padding-left: 0px"><?= $form->field($model, 'telp')->textInput(['maxlength' => true]) ?></div>

    <div class="col-md-6" style="padding-right: 0px"><?= $form->field($model, 'fax')->textInput(['maxlength' => true]) ?></div>
    <div class="col-md-4" style="padding-left: 0px"><?= $form->field($model, 'jml_shelter')->textInput() ?></div>
    <div class="col-md-4"><?= $form->field($model, 'luas_shelter')->textInput() ?></div>
    <div class="col-md-4" style="padding-right: 0px"><?= $form->field($model, 'dt_shelter')->textInput() ?></div>

       <?= $form->field($model, 'map')->textInput(['onFocus'=>'geolocate()']) ?>

    <div class="form-group">
        <?= Html::submitButton($model->isNewRecord ? 'Create' : 'Update', ['class' => $model->isNewRecord ? 'btn btn-success' : 'btn btn-primary']) ?>
    </div>

    <?php ActiveForm::end(); ?>


<script>
      

    
      function initAutocomplete() {
        
        autocomplete = new google.maps.places.Autocomplete(
            /** @type {!HTMLInputElement} */(document.getElementById('profile-map')),
            {types: ['geocode']});

       
        autocomplete.addListener('place_changed', fillInAddress);
      }

      

      
      function geolocate() {
        if (navigator.geolocation) {
          navigator.geolocation.getCurrentPosition(function(position) {
            var geolocation = {
              lat: position.coords.latitude,
              lng: position.coords.longitude
            };
            var circle = new google.maps.Circle({
              center: geolocation,
              radius: position.coords.accuracy
            });
            autocomplete.setBounds(circle.getBounds());
          });
        }
      }
    </script>
    <script src="https://maps.googleapis.com/maps/api/js?key=AIzaSyC9dg-3ggoP6Hy6phhTBeho6yfkP-eBlpE&libraries=places&callback=initAutocomplete"
        async defer></script>

</div>
