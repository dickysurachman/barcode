<?php

use yii\helpers\Html;

/* @var $this yii\web\View */
/* @var $model app\models\Padang */
?>
<div class="padang-update">

    <?= $this->render('_formpadang', [
        'model' => $model,
    ]) ?>

</div>
