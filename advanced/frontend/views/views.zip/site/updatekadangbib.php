<?php

use yii\helpers\Html;

/* @var $this yii\web\View */
/* @var $model app\models\Kandangbib */
?>
<div class="kandangbib-update">

    <?= $this->render('_formkandangbib', [
        'model' => $model,
    ]) ?>

</div>
