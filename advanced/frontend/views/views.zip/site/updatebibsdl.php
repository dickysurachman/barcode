<?php

use yii\helpers\Html;

/* @var $this yii\web\View */
/* @var $model app\models\Bibsdl */
?>
<div class="bibsdl-update">

    <?= $this->render('_formbibsdl', [
        'model' => $model,
    ]) ?>

</div>
