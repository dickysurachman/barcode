<?php

use yii\helpers\Html;


/* @var $this yii\web\View */
/* @var $model app\models\Bibsdl */

?>
<div class="bibsdl-create">
    <?= $this->render('_formbetsdl', [
        'model' => $model,
    ]) ?>
</div>
