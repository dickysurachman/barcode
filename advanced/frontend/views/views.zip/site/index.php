<?php
use app\models\Profile;
use scotthuangzl\googlechart\GoogleChart;

/* @var $this yii\web\View */
$this->title = 'Sistem Online ';
?>
<div class="content body">
<div class="site-index" style="margin-top:-50px;text-align: center;">
    <div class="row">
        <h2>Selamat datang  <?php echo Yii::$app->user->identity->username?></h2>
        <p><a class="btn btn-lg btn-success" href="#">Get started </a></p>
   

    <?php
    if(Yii::$app->user->identity->tipe_user2<>1){ 
    $tgls=date('Y',time());
    $tglm=date('m-Y',time());
    $hari_ini = date("Y-m-d"); 
	$tgl_pertama = date('Y-m-01', strtotime($hari_ini));
	// Tanggal terakhir pada bulan ini
	$tgl_terakhir = date('Y-m-t', strtotime($hari_ini));
        $jumlahhari=(strtotime($tgl_terakhir)-strtotime($tgl_pertama))/86400;
        $j=0;
	    $itemy[$j][]="Tanggal";
		$itemy[$j][]="Room";
		$j=1;

        for($i=0;$i<=$jumlahhari;$i++){
            $tgljn=date('Y-m-d',strtotime($tgl_pertama)+(86400*$i));
            $detail=Yii::$app->db->createCommand("select sum(jumlah) as jml from reservasi where tgl_cekin='".$tgljn."' and id_perusahaan=".Yii::$app->user->identity->id_perusahaan)->queryScalar();
            if($detail==0 or $detail==""){
                $sumary1= '0';
            }else{
                $sumary1=$detail;
            }
        $itemy[$j][]=$j;
		$itemy[$j][]=(int)$sumary1;
	    $j++;
        }
    ?>
    <div class="col-md-12" style="padding: 5px;">
    <?php 
	echo GoogleChart::widget(array('visualization' => 'LineChart',
                'data' => $itemy,
                'options' => array('title' => 'Daily Forecast '.$tglm,'hAxis' => array('title' => 'Date'),))); 

    ?>        
    </div>
    </div>

    <div class="col-md-6">
    <?php
    $haa=Yii::$app->db->createCommand("Select nama,sum(rns) as rns,sum(revenue) as rev from report_market where year(tgl)=".$tgls. " and revenue>0 and id_perusahaan=".Yii::$app->user->identity->id_perusahaan. " group by nama")->queryAll();
    $i=0;
    $item[$i][]="Nama";
	$item[$i][]="Jumlah";
	$i=1;
    //$item=["Task","Hours per Day"];
    foreach ($haa as $keya) {
    	$item[$i][]=$keya['nama'];
		$item[$i][]=(int)$keya['rev'];
		//$item[]=[$keya['nama'],intval($keya['rev'])];
    	$i++;
    }
	echo GoogleChart::widget(array('visualization' => 'PieChart',
                'data' => $item,
                'options' => array('title' => 'Market Segment '.$tgls))); 

                    
      ?>
    </div>
    <div class="col-md-6">
    <?php 
    $haa=Yii::$app->db->createCommand("Select month(tgl) as nama,sum(actual) as rns,avg(actual) as rev, max(status) as status from night_cdr where year(tgl)=".$tgls. " and id_perusahaan=".Yii::$app->user->identity->id_perusahaan." and nama='TOTALROOMREVENUE' group by month(tgl) order by nama ")->queryAll();
    $i=0;
    $itemx[$i][]="Nama";
	$itemx[$i][]="Revenue";
	$i=1;
    //$item=["Task","Hours per Day"];
    foreach ($haa as $keya) {
    	$itemx[$i][]=$keya['nama'];
		$itemx[$i][]=(int)$keya['rns'];
		//$item[]=[$keya['nama'],intval($keya['rev'])];
    	$i++;
    }
	echo GoogleChart::widget(array('visualization' => 'LineChart',
                'data' => $itemx,
                'options' => array('title' => 'Room Revenue '.$tgls,'hAxis' => array('title' => 'Month'),))); 
	}
    ?>
    </div>


</div>
</div>
