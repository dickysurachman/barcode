<?php

use yii\helpers\Html;

/* @var $this yii\web\View */
/* @var $model app\models\Kandang */
?>
<div class="kandang-update">

    <?= $this->render('_form2', [
        'model' => $model,
    ]) ?>

</div>
