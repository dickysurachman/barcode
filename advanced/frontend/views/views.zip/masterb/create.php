<?php

use yii\helpers\Html;


/* @var $this yii\web\View */
/* @var $model app\models\Masterb */

?>
<div class="masterb-create">
    <?= $this->render('_form', [
        'model' => $model,
    ]) ?>
</div>
