<?php

use yii\widgets\DetailView;

/* @var $this yii\web\View */
/* @var $model app\models\Barang */
?>
<div class="barang-view">
 
    <?= DetailView::widget([
        'model' => $model,
        'attributes' => [
            'id',
            'nama',
            'harga',
            'status',
            'id_profile',
            'add_who',
            'add_date',
            'edit_who',
            'edit_date',
        ],
    ]) ?>

</div>
