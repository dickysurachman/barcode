<?php

use yii\helpers\Html;

/* @var $this yii\web\View */
/* @var $model app\models\Barang */
?>
<div class="barang-update">

    <?= $this->render('_formu', [
        'model' => $model,
    ]) ?>

</div>
