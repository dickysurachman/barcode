<?php
use yii\helpers\Html;
use yii\widgets\ActiveForm;
use kartik\money\MaskMoney;
use yii\helpers\ArrayHelper;
use app\models\Masterb;
$tipe=['Aktif','Tidak Aktif'];
/* @var $this yii\web\View */
/* @var $model app\models\Barang */
/* @var $form yii\widgets\ActiveForm */
$tipe=[
'Ya',
'Tidak'
];
?>

<div class="barang-form">

    <?php $form = ActiveForm::begin(); ?>

    <?= $form->field($model, 'nama')->textInput(['maxlength' => true]) ?>

     <?php   
        echo $form->field($model, 'harga')->widget(MaskMoney::classname());
    ?>  
    <?= $form->field($model, 'kunci')->dropDownList($tipe,['prompt'=>'Select']) ?>
    <?= $form->field($model, 'id_jenis')->dropDownList(ArrayHelper::map(Masterb::find()->where(['id_perusahaan'=>Yii::$app->user->identity->id_perusahaan])->all(), 'id', 'nama'),['prompt'=>'Select']) ?>

  
	<?php if (!Yii::$app->request->isAjax){ ?>
	  	<div class="form-group">
	        <?= Html::submitButton($model->isNewRecord ? 'Create' : 'Update', ['class' => $model->isNewRecord ? 'btn btn-success' : 'btn btn-primary']) ?>
	    </div>
	<?php } ?>

    <?php ActiveForm::end(); ?>
    
</div>
