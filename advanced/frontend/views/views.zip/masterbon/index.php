<?php

use yii\helpers\Html;
use yii\grid\GridView;
use yii\helpers\ArrayHelper;
use app\models\Company;
/* @var $this yii\web\View */
/* @var $searchModel app\models\BonmasterSearch */
/* @var $dataProvider yii\data\ActiveDataProvider */

$this->title = 'Bonmasters';
$this->params['breadcrumbs'][] = $this->title;
?>
<div class="bonmaster-index">

    <h1><?= Html::encode($this->title) ?></h1>
    <?php // echo $this->render('_search', ['model' => $searchModel]); ?>

    <p>
        <?= Html::a('Create Bonmaster', ['nobon/createmaster'], ['class' => 'btn btn-success']) ?>
        <?= Html::a('List Pembayaran Master', ['bayarmaster/index'], ['class' => 'btn btn-primary']) ?>

    </p>
    <div class="table-responsive">
    <?= GridView::widget([
        'dataProvider' => $dataProvider,
        'filterModel' => $searchModel,
        'columns' => [
            ['class' => 'yii\grid\SerialColumn'],

            //'id',
            'no_inv',
            //'tanggal',
            'tgl_cekin',
            'tgl_cekout',
            //'tanggal',
            //'id_company',
            [
            'attribute'=>'id_company',
            'filter'=>ArrayHelper::map(Company::find()->where(['id_perusahaan'=>Yii::$app->user->identity->id_perusahaan])->orderBy(['nama'=>SORT_ASC])->all(), 'kode', 'nama'),
            'value'=>'costumer',
            ],
            [
            'attribute'=>'jumlah',
            'value'=>function ($data) {
                        return number_format($data->jumlah);
                        }
            ],
            [
            'attribute'=>'bayar',
            'value'=>function ($data) {
                        return number_format($data->bayar);
                        }
            ],
            //'jumlah',
            //'bayar',
            //'status',
            [
                //'class' => 'yii\grid\ActionColumn',
                'header'=>'Print',
                'attribute' => 'img',
                'format' => 'raw',
                'label' => 'Status',
                'value'=>function ($data) {
                                return Html::a('<span class="glyphicon glyphicon-print" style="font-size:14pt;" title="Print"></span>',['cetak', 'id' => $data->id],
                                    ['target'=>'_blank', 'class' => 'linksWithTarget']) .' '. Html::a('<span class="glyphicon glyphicon-file" style="font-size:14pt;" title="Print"></span>',['cetak1', 'id' => $data->id],
                                    ['target'=>'_blank', 'class' => 'linksWithTarget']);
                                },
            ],  
            [
                'header'=>'Bayar',
                'attribute' => 'img',
                'format' => 'raw',
                'label' => 'Bayar',
                'value'=>function ($data) {
                                return Html::a('<span class="glyphicon glyphicon-usd" style="font-size:14pt;" title="Bayar"></span>',['bayardet', 'id' => $data->id],
                                ['class' => 'linksWithTarget']);
                                },
            ],
            // 'rns',
            // 'jumlah',
             'add_who',
            // 'add_date',
            // 'edit_who',
            // 'edit_date',

            [
            'template'=>'{update}{delete}',
            'class' => 'yii\grid\ActionColumn'],
        ],
    ]); ?>
</div>
</div>
