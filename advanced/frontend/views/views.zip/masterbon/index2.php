<?php

use yii\helpers\Html;
use yii\grid\GridView;
use yii\helpers\ArrayHelper;
use app\models\Company;
/* @var $this yii\web\View */
/* @var $searchModel app\models\BonmasterSearch */
/* @var $dataProvider yii\data\ActiveDataProvider */

$this->title = 'Bonmasters';
$this->params['breadcrumbs'][] = $this->title;
?>
<div class="bonmaster-index">

    <h1><?= Html::encode($this->title) ?></h1>
    <?php // echo $this->render('_search', ['model' => $searchModel]); ?>

    
    <p>
    </p>
     <div class="table-responsive">
    <?= GridView::widget([
        'dataProvider' => $dataProvider,
        'filterModel' => $searchModel,
        'columns' => [
            ['class' => 'yii\grid\SerialColumn'],

            //'id',
            'no_inv',
            //'tanggal',
            'tgl_cekin',
            'tgl_cekout',
            'tanggal',
            //'id_company',
            [
            'attribute'=>'id_company',
            'filter'=>ArrayHelper::map(Company::find()->where(['id_perusahaan'=>Yii::$app->user->identity->id_perusahaan])->orderBy(['nama'=>SORT_ASC])->all(), 'kode', 'nama'),
            //'filter'=>ArrayHelper::map(Company::find()->all(), 'kode', 'nama'),
            'value'=>'costumer',
            ],
            //'status',
             'add_who',
            [
                //'class' => 'yii\grid\ActionColumn',
                'header'=>'Print',
                'attribute' => 'img',
                'format' => 'raw',
                'label' => 'Status',
                'value'=>function ($data) {
                                return Html::a('<span class="glyphicon glyphicon-print" style="font-size:14pt;" title="Print"></span>',['cetak', 'id' => $data->id],
                                    ['target'=>'_blank', 'class' => 'linksWithTarget']) .' '. Html::a('<span class="glyphicon glyphicon-file" style="font-size:14pt;" title="Print"></span>',['cetak1', 'id' => $data->id],
                                    ['target'=>'_blank', 'class' => 'linksWithTarget']);
                                },
            ],  
            // 'rns',
            // 'jumlah',
            // 'add_date',
            // 'edit_who',
            // 'edit_date',
            ]                

    ]); ?>
</div>
</div>
