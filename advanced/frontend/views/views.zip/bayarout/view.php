<?php

use yii\widgets\DetailView;

/* @var $this yii\web\View */
/* @var $model app\models\Bayaroutlet */
?>
<div class="bayaroutlet-view">
 
    <?= DetailView::widget([
        'model' => $model,
        'attributes' => [
            'id',
            'kode_bayar',
            'tanggal',
            'id_bon',
            'id_terima',
            'jumlah',
            'status',
            'add_who',
            'add_date',
            'edit_who',
            'edit_date',
        ],
    ]) ?>

</div>
