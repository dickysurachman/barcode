<?php
use yii\helpers\Html;
use yii\widgets\ActiveForm;
use yii\jui\DatePicker;
use yii\web\View;
use app\models\Penerimaan;
use kartik\money\MaskMoney;
use yii\helpers\ArrayHelper;
use kartik\select2\Select2;
/* @var $this yii\web\View */
/* @var $model app\models\Bayarbon */
/* @var $form yii\widgets\ActiveForm */

$script = <<< JS
$("#bayarbon-tanggal").datepicker({
    changeMonth: true, 
    changeYear: true, 
    dateFormat:'yy-mm-dd',
});

JS;
$position= View::POS_END;
$this->registerJs($script,$position);
?>

<div class="bayarbon-form">

    <?php $form = ActiveForm::begin(); ?>

    

    <?= $form->field($model, 'kode_bayar')->textInput(['options'=>['readonly'=>'readonly']]) ?>

    <label class="control-label" for="semen-tgl"><?php echo "Tanggal" ?> </label>
    <?php
    echo DatePicker::widget([
    'model'  => $model,
    'attribute'=>'tanggal',
    'dateFormat' => 'yyyy-MM-dd',
    'options'=>['class'=>'form-control','autocomplete'=>'off','readonly'=>'readonly']
]);?>

    <?= $form->field($model, 'id_bon')->textInput() ?>

    

    <?php
        echo $form->field($model, 'id_terima')->widget(Select2::classname(), [
        'data' => ArrayHelper::map(Penerimaan::find()->where(['status'=>0])->all(), 'id', 'jenis'),
        'options' => ['placeholder' => 'Select '],
        'pluginOptions' => [
            'allowClear' => true
        ],
        ]);
    ?>
    <?php
    echo $form->field($model, 'jumlah')->widget(MaskMoney::classname());
    ?>
    

  
	<?php if (!Yii::$app->request->isAjax){ ?>
	  	<div class="form-group">
	        <?= Html::submitButton($model->isNewRecord ? 'Create' : 'Update', ['class' => $model->isNewRecord ? 'btn btn-success' : 'btn btn-primary']) ?>
	    </div>
	<?php } ?>

    <?php ActiveForm::end(); ?>
    
</div>
