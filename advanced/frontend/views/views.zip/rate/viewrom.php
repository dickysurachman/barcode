<?php

use yii\widgets\DetailView;

/* @var $this yii\web\View */
/* @var $model app\models\Rateroom */
?>
<div class="rateroom-view">
 
    <?= DetailView::widget([
        'model' => $model,
        'attributes' => [
            'id',
            'kode_rate',
            'id_kamar',
            'harga',
            'breakfast',
        ],
    ]) ?>

</div>
