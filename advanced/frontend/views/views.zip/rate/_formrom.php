<?php
use yii\helpers\Html;
use yii\widgets\ActiveForm;
use app\models\Kamar;
use yii\helpers\ArrayHelper;
use kartik\money\MaskMoney;
/* @var $this yii\web\View */
/* @var $model app\models\Rateroom */
/* @var $form yii\widgets\ActiveForm */
$countries=Kamar::find()->where(['id_perusahaan'=>Yii::$app->user->identity->id_perusahaan])->all();
//use yii\helpers\ArrayHelper;
$dataPost=ArrayHelper::map($countries,'id','tipe_kamar');
?>

<div class="rateroom-form">

    <?php $form = ActiveForm::begin(); ?>

    <?= $form->field($model, 'id_kamar')->dropDownList($dataPost,['prompt'=>'Pilih']) ?>
    <?php // = $form->field($model, 'harga')->textInput() ?>
     <?php    echo $form->field($model, 'harga')->widget(MaskMoney::classname()); ?>
     <?php    echo $form->field($model, 'breakfast')->widget(MaskMoney::classname()); ?>
    <?php //= $form->field($model, 'breakfast')->textInput() ?>

  
	<?php if (!Yii::$app->request->isAjax){ ?>
	  	<div class="form-group">
	        <?= Html::submitButton($model->isNewRecord ? 'Create' : 'Update', ['class' => $model->isNewRecord ? 'btn btn-success' : 'btn btn-primary']) ?>
	    </div>
	<?php } ?>

    <?php ActiveForm::end(); ?>
    
</div>
