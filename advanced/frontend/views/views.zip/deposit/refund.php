<?php


use yii\helpers\Html;
use yii\widgets\ActiveForm;
use kartik\money\MaskMoney;
use yii\widgets\DetailView;
use kartik\select2\Select2;
use app\models\Penerimaan;
use yii\helpers\ArrayHelper;
//use app\models\Guest;
//use yii\web\View;
/* @var $this yii\web\View */
/* @var $model app\models\Deposit */
/* @var $form yii\widgets\ActiveForm */
//$cityDesc = "Ketikkan Nama";//empty($model->city) ? '' : City::findOne($model->city)->description;

?>

<div class="deposit-form">

    <?php $form = ActiveForm::begin(); ?>
 <?= DetailView::widget([
        'model' => $model,
        'attributes' => [
            //'id',
            'grandtotal',
            //'edit_date',
        ],
    ]) ?>
  
  <div class="col-md-6" style="padding-left: 0px;">
    <?php
        echo $form->field($model, 'id_penerimaan2')->widget(Select2::classname(), [
        'data' => ArrayHelper::map(Penerimaan::find()->where(['status'=>0])->all(), 'id', 'jenis'),
        'options' => ['placeholder' => 'Select '],
        'pluginOptions' => [
            'allowClear' => true
        ],
        ]);
    ?>
    </div>
      <div class="col-md-6" style="padding-left: 0px;">
 
    <?php
    echo $form->field($model, 'refund')->widget(MaskMoney::classname());
    ?>
    </div>
    <div class="form-group">
        <?= Html::submitButton($model->isNewRecord ? 'Create' : 'Update', ['class' => $model->isNewRecord ? 'btn btn-success' : 'btn btn-primary']) ?>
    </div>

    <?php ActiveForm::end(); ?>

</div>
