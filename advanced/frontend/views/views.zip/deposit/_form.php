<?php


use yii\helpers\Html;
use yii\widgets\ActiveForm;
use kartik\money\MaskMoney;
use kartik\select2\Select2;
$url = \yii\helpers\Url::to(['reservasi/guest']);
use yii\web\JsExpression;
//use app\models\Guest;
use yii\jui\DatePicker;
use yii\web\View;
use app\models\Guest;
use app\models\Penerimaan;
use yii\helpers\ArrayHelper;
/* @var $this yii\web\View */
/* @var $model app\models\Deposit */
/* @var $form yii\widgets\ActiveForm */
$cityDesc =empty($model->id_guest) ? '' : Guest::findOne($model->id_guest)->nama;
//$cityDesc = "Ketikkan Nama";//empty($model->city) ? '' : City::findOne($model->city)->description;
$script = <<< JS
$("#deposit-tgl_chekin").datepicker({
    changeMonth: true, 
    changeYear: true, 
    dateFormat:'yy-mm-dd',
    minDate:'today',
  
    onSelect: function( selectedDate ) {
        var dateMin = $("#deposit-tgl_chekin").datepicker("getDate");
        var rMin = new Date(dateMin.getFullYear(), dateMin.getMonth(),dateMin.getDate() + 1); 

     $( "#deposit-tgl_chekout" ).datepicker( "option", "minDate", rMin );
    }
});
$("#deposit-tgl_chekout").datepicker({
    changeMonth: true, 
    changeYear: true, 
    dateFormat:'yy-mm-dd',
});
 
JS;
$position= View::POS_END;
$this->registerJs($script,$position);
?>

<div class="deposit-form">

<?= Html::a('Create Tamu', ['/guest/create'], ['class' => 'btn btn-success','target'=>'_blank']) ?><br/>

    <?php $form = ActiveForm::begin(); ?>

<?php 
    echo $form->field($model, 'id_guest')->widget(Select2::classname(), [
        'initValueText' => $cityDesc, 
        'options' => ['placeholder' => 'Search for Guest ...'],
        'pluginOptions' => [
            'allowClear' => true,
            'minimumInputLength' => 3,
            'language' => [
                'errorLoading' => new JsExpression("function () { return 'Waiting for results...'; }"),
            ],
            'ajax' => [
                'url' => $url,
                'dataType' => 'json',
                'data' => new JsExpression('function(params) { return {q:params.term}; }')
            ],
            'escapeMarkup' => new JsExpression('function (markup) { return markup; }'),
            'templateResult' => new JsExpression('function(id_guest) { return id_guest.text; }'),
            'templateSelection' => new JsExpression('function (id_guest) { return id_guest.text; }'),
        ],
    ]);
    ?>
    
 <div class="col-md-6" style="padding-left: 0px;"> <label class="control-label" for="semen-tgl"><?php echo "Tanggal Check In" ?> </label>
    <?php
    echo DatePicker::widget([
    'model'  => $model,
    'attribute'=>'tgl_chekin',
    'dateFormat' => 'yyyy-MM-dd',
    'options'=>['class'=>'form-control','autocomplete'=>'off','readonly'=>'readonly']
]);?></div>
<div class="col-md-6" style="padding-right: 0px">
   <label class="control-label" for="semen-tgl"><?php echo "Tanggal Check Out" ?> </label>
    <?php
    echo DatePicker::widget([
    'model'  => $model,
    'attribute'=>'tgl_chekout',
    'dateFormat' => 'yyyy-MM-dd',
    'options'=>['class'=>'form-control','autocomplete'=>'off','readonly'=>'readonly']
]);?></div>
   


    <?= $form->field($model, 'keterangan')->textarea(['rows' => 6]) ?>
 <div class="col-md-6" style="padding-left: 0px;">
    <?php
        echo $form->field($model, 'id_penerimaan')->widget(Select2::classname(), [
        'data' => ArrayHelper::map(Penerimaan::find()->where(['id_perusahaan'=>Yii::$app->user->identity->id_perusahaan])->all(), 'id', 'jenis'),
        'options' => ['placeholder' => 'Select '],
        'pluginOptions' => [
            'allowClear' => true
        ],
        ]);
    ?>
    </div>
    <div class="col-md-6" style="padding-right: 0px;">
    <?php
    echo $form->field($model, 'jumlah')->widget(MaskMoney::classname());
    ?>
    </div>

    <div class="form-group">
        <?= Html::submitButton($model->isNewRecord ? 'Create' : 'Update', ['class' => $model->isNewRecord ? 'btn btn-success' : 'btn btn-primary']) ?>
    </div>

    <?php ActiveForm::end(); ?>

</div>
