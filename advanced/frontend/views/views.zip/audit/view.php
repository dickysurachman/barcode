<?php

use yii\widgets\DetailView;

/* @var $this yii\web\View */
/* @var $model app\models\Nightaudit */
?>
<div class="nightaudit-view">
 
    <?= DetailView::widget([
        'model' => $model,
        'attributes' => [
            'id',
            'tanggal',
            'akun',
            'uraian',
            'debit',
            'kredit',
            'status',
        ],
    ]) ?>

</div>
