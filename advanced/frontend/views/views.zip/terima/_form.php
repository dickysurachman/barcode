<?php
use yii\helpers\Html;
use yii\widgets\ActiveForm;


$status=['Aktif','Non Aktif'];
$status2=['Tidak','Iya'];
/* @var $this yii\web\View */
/* @var $model app\models\Penerimaan */
/* @var $form yii\widgets\ActiveForm */
?>

<div class="penerimaan-form">

    <?php $form = ActiveForm::begin(); ?>

    <?= $form->field($model, 'jenis')->textInput(['maxlength' => true]) ?>

    <?= $form->field($model, 'keterangan')->textInput(['maxlength' => true]) ?>

    <?= $form->field($model, 'kode_akun')->textInput(['maxlength' => true]) ?>
    <?= $form->field($model, 'status')->dropDownList($status,['prompt'=>'Silahkan Pilih'])  ?>
    <?= $form->field($model, 'kred')->dropDownList($status2,['prompt'=>'Silahkan Pilih'])  ?>
    <?= $form->field($model, 'kred_akun')->textInput(['maxlength' => true])   ?>
    <?= $form->field($model, 'deposit1')->dropDownList($status2,['prompt'=>'Silahkan Pilih'])  ?>

  
	<?php if (!Yii::$app->request->isAjax){ ?>
	  	<div class="form-group">
	        <?= Html::submitButton($model->isNewRecord ? 'Create' : 'Update', ['class' => $model->isNewRecord ? 'btn btn-success' : 'btn btn-primary']) ?>
	    </div>
	<?php } ?>

    <?php ActiveForm::end(); ?>
    
</div>
