<?php
use yii\helpers\Url;

$hasil=['Tidak','Ya'];
return [
    [
        'class' => 'kartik\grid\CheckboxColumn',
        'width' => '20px',
    ],
    [
        'class' => 'kartik\grid\SerialColumn',
        'width' => '30px',
    ],
        // [
        // 'class'=>'\kartik\grid\DataColumn',
        // 'attribute'=>'id',
    // ],
    [
        'class'=>'\kartik\grid\DataColumn',
        'attribute'=>'jenis',
    ],
    [
        'class'=>'\kartik\grid\DataColumn',
        'attribute'=>'keterangan',
    ],
    [
        'class'=>'\kartik\grid\DataColumn',
        'attribute'=>'status',
        'value'=>'arti'
    ],
    [
        'class'=>'\kartik\grid\DataColumn',
        'attribute'=>'kode_akun',
    ],
    [
        'class'=>'\kartik\grid\DataColumn',
        'attribute'=>'kred',
        'filter'=>$hasil,
        'value'=>'kre',
    ],
    [
        'class'=>'\kartik\grid\DataColumn',
        'attribute'=>'kred_akun',
    ],
    [
        'class'=>'\kartik\grid\DataColumn',
        'attribute'=>'deposit1',
        'filter'=>$hasil,
        'value'=>'dep',
    ],
    [
        'class' => 'kartik\grid\ActionColumn',
        'dropdown' => false,
        'vAlign'=>'middle',
        'urlCreator' => function($action, $model, $key, $index) { 
                return Url::to([$action,'id'=>$key]);
        },
        'viewOptions'=>['role'=>'modal-remote','title'=>'View','data-toggle'=>'tooltip'],
        'updateOptions'=>['role'=>'modal-remote','title'=>'Update', 'data-toggle'=>'tooltip'],
        'deleteOptions'=>['role'=>'modal-remote','title'=>'Delete', 
                          'data-confirm'=>false, 'data-method'=>false,// for overide yii data api
                          'data-request-method'=>'post',
                          'data-toggle'=>'tooltip',
                          'data-confirm-title'=>'Are you sure?',
                          'data-confirm-message'=>'Are you sure want to delete this item'], 
    ],

];   